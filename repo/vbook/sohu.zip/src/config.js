var BASE_URL = "https://m.sohu.com";
try { if (DOMAIN) BASE_URL = String(DOMAIN).replace(/\/+$/, ""); } catch (e) {}
var G = {
 "tabs": {
  "Mới cập nhật": "/[?page={p}]"
 },
 "search": "/tim-kiem?keyword={q}[&page={p}]",
 "item": "section.f-list.f-new > div.f",
 "title": "a",
 "link": "a@href",
 "ch_list": "a.__none__",
 "d_title": "meta[property=og:title]@content || title",
 "d_cover": "meta[property=og:image]@content || img@img",
 "d_desc": "meta[property=og:description]@content || meta[name=description]@content",
 "content": "div.hidden-content, div.display-content",
 "ch_fallback_single": "正文"
};
