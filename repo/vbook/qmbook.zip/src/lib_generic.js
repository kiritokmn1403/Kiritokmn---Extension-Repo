// Selector-driven template. A site's config.js defines `var G = {...}` (see docs/SOURCE_SPEC.md).
// Selector syntax: "css" (text), "css@attr" (attribute), "css@html" (inner html), "css@img" (best image url),
// alternatives separated by " || ". URL patterns use {p} (page), {q} (query), {base}.
var X = {
  pick: function (root, spec) {
    if (!spec || !root) return '';
    var alts = String(spec).split(' || ');
    for (var i = 0; i < alts.length; i++) {
      var s = alts[i], at = 'text', k = s.lastIndexOf('@');
      if (k > 0 && !/\[[^\]]*@/.test(s.slice(k))) { at = s.slice(k + 1); s = s.slice(0, k); }
      var els = s === ':self' ? null : root.select(s);
      var el = s === ':self' ? root : (els.size() ? els.first() : null);
      if (!el) continue;
      var v = at === 'text' ? el.text() : at === 'html' ? el.html() : at === 'img' ? C.img(el.is('img') ? el : el.select('img').first()) : at === 'own' ? el.ownText() : el.attr(at);
      if (v) return String(v).trim();
    }
    return '';
  },
  url: function (pat, p, q) {
    var n = C.page(p);
    var u = String(pat);
    // {p} -> page number; [..{p}..] optional block removed on page 1
    u = u.replace(/\[([^\]]*)\]/g, function (m, inner) { return n > 1 ? inner : ''; });
    u = u.replace(/\{p\}/g, String(n)).replace(/\{p0\}/g, String(n - 1)).replace(/\{q\}/g, C.enc(q || '')).replace(/\{base\}/g, BASE_URL);
    return C.fix(u);
  },
  // `s` = 's_' when parsing a search result page whose cards differ from the list pages (G.s_item, G.s_title, ...)
  items: function (doc, s) {
    var k = function (n) { return (s && G[s + n]) || G[n]; };
    var els = doc.select(k('item')), out = [], seen = {};
    for (var i = 0; i < els.size(); i++) {
      var e = els.get(i);
      var link = X.pick(e, k('link') || 'a@href');
      if (!link || seen[link] || /^javascript|#$/.test(link)) continue;
      var name = X.pick(e, k('title') || 'h3 || h2 || a@title || img@alt');
      if (!name) continue;
      seen[link] = 1;
      out.push({ name: name, link: C.fix(link), cover: X.pick(e, k('cover') || 'img@img'), description: X.pick(e, k('desc') || ''), host: BASE_URL });
    }
    return out;
  },
  listPage: function (pat, p, q) {
    var doc = C.html(X.url(pat, p, q), G.req);
    var items = X.items(doc, q ? 's_' : '');
    var more = G.next ? doc.select(G.next).size() > 0 : items.length >= (G.pageSize || 10);
    return Response.success(items, C.next(more && items.length > 0, p));
  },
  browse: function (input, p) {
    var pat = (G.tabs && G.tabs[input]) || input;
    return X.listPage(pat, p, '');
  },
  search: function (key, p) {
    // q_cut: regex; sites whose search breaks on punctuation only get the text before it
    if (G.q_cut && !C.isUrl(key)) key = String(key).split(new RegExp(G.q_cut))[0].trim() || key;
    if (C.isUrl(key)) { var u = C.fix(key); return X.listPage(u + (u.indexOf('?') > 0 ? '&' : '?') + (G.pageParam || 'page') + '={p}', p, ''); }
    if (G.search_post) {
      // POST search form: { url, body } — body uses {q}; results are parsed like any list page
      var doc = C.html(X.url(G.search_post.url, p, key), { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: String(G.search_post.body).replace(/\{q\}/g, C.enc(key)) });
      var items = X.items(doc, 's_');
      return Response.success(items, null);
    }
    if (G.search_json) return X.jsonSearch(G.search_json, key, p);
    return X.listPage(G.search, p, key);
  },
  // JSON search API: { url, list: 'data.items' (dot path, '' = root array), title, link ('/truyen/{slug}' template or field), cover }
  jsonSearch: function (J, key, p) {
    var d = C.json(X.url(J.url, p, key), G.req);
    if (J.list) J.list.split('.').forEach(function (k) { d = d && d[k]; });
    var fill = function (o, t) { return String(t || '').indexOf('{') >= 0 ? String(t).replace(/\{(\w+)\}/g, function (m, k) { return o[k] == null ? '' : o[k]; }) : (o[t] == null ? '' : String(o[t])); };
    var out = [];
    (d || []).forEach(function (o) {
      var name = fill(o, J.title || 'title'), link = fill(o, J.link || 'url');
      if (name && link) out.push({ name: name, link: C.fix(link), cover: C.fix(fill(o, J.cover || 'cover')), description: J.desc ? fill(o, J.desc) : '', host: BASE_URL });
    });
    return Response.success(out, J.paged && out.length ? C.next(true, p) : null);
  },
  genre: function () {
    if (!G.genre) return Response.success([]);
    var doc = C.html(C.fix(G.genrePage || '/'));
    var out = doc.select(G.genre).map(function (a) { return { title: a.text(), input: C.fix(a.attr('href')), script: 'search.js' }; });
    return Response.success(out.filter(function (g) { return g.title; }));
  },
  detail: function (url) {
    var doc = C.html(url, G.req);
    var genres = G.d_genres ? doc.select(G.d_genres).map(function (a) { return { title: a.text(), input: C.fix(a.attr('href')), script: 'search.js' }; }) : [];
    var status = X.pick(doc, G.d_status);
    return Response.success({
      name: X.pick(doc, G.d_title || 'h1'), cover: C.fix(X.pick(doc, G.d_cover || 'meta[property=og:image]@content')),
      author: X.pick(doc, G.d_author), description: X.pick(doc, (G.d_desc || 'meta[name=description]@content').replace(/$/, '')),
      detail: status ? 'Tình trạng: ' + status : '', ongoing: C.ongoing(status), genres: genres, host: BASE_URL
    });
  },
  // resolve a page-relative href ("p-2.html") against the URL of the page it was found on
  rel: function (h, base) {
    h = String(h || '').trim();
    if (/^(https?:)?\/\//.test(h) || h.charAt(0) === '/') return C.fix(h);
    base = String(base || '').replace(/[?#].*$/, '');
    if (!/^https?:/.test(base)) return C.fix(h);
    // "?page=2" keeps the page path (index.html?page=2), "p-2.html" replaces its last segment
    return h.charAt(0) === '?' ? base + h : base.replace(/[^\/]*$/, '') + h;
  },
  toc: function (url) {
    if (G.ch_action) return X.actionToc(url);
    if (G.single) return Response.success([{ name: G.single === true ? 'Xem / Đọc' : G.single, url: url, host: BASE_URL }]);
    var pages = [url], list = [], seen = {};
    var doc = C.html(G.ch_rewrite ? url.replace(new RegExp(G.ch_rewrite[0]), G.ch_rewrite[1]) : url, G.req);
    if (G.ch_url) { var cu = X.pick(doc, G.ch_url); if (cu) { doc = C.html(C.fix(cu), G.req); } }
    // 0.0.4: chapter list served by an AJAX endpoint keyed by an id found in the detail page
    //   ch_from: { re: 'data-novel-id="([^"]+)"', url: '/ajax/chapter-archive?novelId=$1' }
    if (G.ch_from) { var cm = new RegExp(G.ch_from.re).exec(doc.html()); if (cm) doc = C.html(C.fix(G.ch_from.url.replace(/\$(\d)/g, function (m, i) { return encodeURIComponent(cm[+i] || ''); })), G.req); }
    for (var guard = 0; guard < (G.ch_maxPages || 60); guard++) {
      var els = doc.select(G.ch_list);
      for (var i = 0; i < els.size(); i++) {
        var a = els.get(i); var href = G.ch_attr ? a.attr(G.ch_attr) : (a.attr('href') || a.attr('data-href'));
        if (!href || href.charAt(0) === '#' || /^javascript:/i.test(href) || seen[href]) continue;
        seen[href] = 1; list.push({ name: (G.ch_name ? X.pick(a, G.ch_name) : a.text()) || a.attr('title'), url: X.rel(href, pages[pages.length - 1]), host: BASE_URL });
      }
      var nx = G.ch_next ? doc.select(G.ch_next).first() : null;
      if (!nx || !nx.attr('href')) break;
      var nu = X.rel(nx.attr('href'), pages[pages.length - 1]);
      if (pages.indexOf(nu) >= 0) break;
      pages.push(nu); if (G.ch_delay) sleep(G.ch_delay); doc = C.html(nu, G.req);
    }
    if (G.ch_reverse) list.reverse();
    // A movie page without an episode list is itself the one episode
    if (!list.length && G.ch_fallback_single) list.push({ name: G.ch_fallback_single === true ? 'Xem phim' : G.ch_fallback_single, url: url, host: BASE_URL });
    return Response.success(list);
  },
  pages: function (url) {
    // pages_suffix: the page list comes from an HTMX/AJAX fragment under the chapter URL (e.g. WeebCentral "/images?...")
    if (G.pages_suffix) url = String(url).replace(/[?#].*$/, '') + G.pages_suffix;
    var out = [], visited = [url], u = url;
    for (var guard = 0; guard < (G.pages_max || 40); guard++) {
      var doc;
      if (G.initmanga) {
        var rr = C.check(C.get(u, G.req), u), bb = rr.text() || '', dec = X.initManga(bb);
        doc = Html.parse(dec ? '<div id="imc-dec">' + dec + '</div>' : bb, u);
      } else doc = C.html(u, G.req);
      var imgs = doc.select(G.initmanga ? '#imc-dec img, ' + (G.pages || '#chapter-content img') : (G.pages || '.page-chapter img, .reading-content img, .chapter-content img'));
      if (G.initmanga) {
        // protected canvases: data-enc = base64 of the reversed image url
        var cv = doc.select('#imc-dec canvas[data-enc]');
        for (var ci = 0; ci < cv.size(); ci++) {
          var cu = CryptoJS.enc.Latin1.stringify(CryptoJS.enc.Base64.parse(cv.get(ci).attr('data-enc'))).split('').reverse().join('');
          if (cu && out.indexOf(cu) < 0) out.push(cu);
        }
      }
      for (var i = 0; i < imgs.size(); i++) { var s = C.img(imgs.get(i)); if (s && out.indexOf(s) < 0) out.push(s); }
      if (!G.pages_next) break;
      var nx = doc.select(G.pages_next).first();
      if (!nx) break;
      var nu = C.fix(nx.attr('href'));
      if (!nu || visited.indexOf(nu) >= 0) break;
      visited.push(nu); u = nu;
    }
    return Response.success(out);
  },
  text: function (url) {
    var r = C.check(C.get(url, G.req), url), body = r.text() || '';
    if (G.content_rsc) {
      var raw = X.rscText(body), locked = G.c_locked && new RegExp(G.c_locked, 'i').test(body);
      var lockMsg = locked ? '<p><i>🔒 Chương này bị khoá trên trang gốc — cần đăng nhập/mở khoá tại ' + BASE_URL + ' để đọc tiếp.</i></p>' : '';
      if (raw || locked) return Response.success(X.toParas(raw) + lockMsg, X.pick(Html.parse(body, url), G.c_title || 'h1 || title'));
    }
    if (G.initmanga) { var dc = X.initManga(body); if (dc) return Response.success(C.cleanContent(Html.parse('<div id="imc-dec">' + dc + '</div>', url).select('#imc-dec').first()), X.pick(Html.parse(body, url), G.c_title || 'h1 || h2')); }
    var doc = Html.parse(body, url);
    var el = doc.select(G.content || '#chapter-c, .chapter-c, #chapter-content, .chapter-content, .reading-content').first();
    if (!el) {
      if (/cf_chl|challenge-platform|cf-turnstile|Just a moment/i.test(body.slice(0, 20000))) throw new Error('CLOUDFLARE: trang ' + BASE_URL + ' yêu cầu xác minh. Mở chương bằng WebView trong ứng dụng, đợi qua bước kiểm tra rồi tải lại.');
      return Response.error('Không tìm thấy nội dung — trang nhận được: "' + (X.pick(doc, 'title') || '?').slice(0, 60) + '" (' + r.status + ', ' + body.length + ' ký tự)' + (body.length < 400 ? ': ' + body.replace(/\s+/g, ' ').slice(0, 200) : ''));
    }
    return Response.success(C.cleanContent(el), X.pick(doc, G.c_title || 'h1 || h2'));
  },
  // ---- WordPress "Init Manga" theme: chapter body is AES-256-CBC encrypted in the page
  // (key = PBKDF2-SHA512(passphrase from InitMangaData.decryption_key, salt, 999 iter, 32 bytes)); needs CryptoJS (load('crypto.js')).
  initManga: function (body) {
    var m = /InitMangaEncryptedChapter\s*=\s*(\{[\s\S]*?\})\s*;/.exec(body), k = /"decryption_key"\s*:\s*"([^"]+)"/.exec(body);
    if (!m || !k || typeof CryptoJS === 'undefined') return '';
    var o; try { o = JSON.parse(m[1]); } catch (e) { return ''; }
    if (!o || !o.ciphertext) return '';
    var pass = CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(k[1]));
    var key = CryptoJS.PBKDF2(pass, CryptoJS.enc.Hex.parse(o.salt), { hasher: CryptoJS.algo.SHA512, keySize: 8, iterations: 999 });
    try { return CryptoJS.AES.decrypt(o.ciphertext, key, { iv: CryptoJS.enc.Hex.parse(o.iv) }).toString(CryptoJS.enc.Utf8); } catch (e) { return ''; }
  },
  // ---- Next.js App Router helpers (sites whose TOC comes from a Server Action and whose text lives in the RSC stream)
  // Server Action ids change on every deploy: try the known id first, then look the id up by its exported name in the page's chunks.
  rscAction: function (html, name) {
    var srcs = [], m, re = /\/_next\/static\/chunks\/[0-9A-Za-z_.-]+\.js/g;
    while ((m = re.exec(html))) if (srcs.indexOf(m[0]) < 0) srcs.push(m[0]);
    var pat = new RegExp('"([0-9a-f]{40,44})"[^"]{0,200}?"' + name + '"');
    for (var i = 0; i < srcs.length && i < 60; i++) {
      var r = C.get(BASE_URL + srcs[i]); if (!r || !r.ok) continue;
      var mm = pat.exec(r.text() || ''); if (mm) return mm[1];
    }
    return '';
  },
  rscArray: function (body) {
    var lines = String(body || '').split('\n');
    for (var i = 0; i < lines.length; i++) {
      var mm = /^[0-9a-f]+:(\[.*)$/.exec(lines[i]);
      if (mm) { try { var a = JSON.parse(mm[1]); if (a && a.length) return a; } catch (e) { } }
    }
    return null;
  },
  actionToc: function (url) {
    var A = G.ch_action, html = C.check(C.get(url, G.req), url).text() || '';
    var am = new RegExp(A.arg).exec(html);
    if (!am) return Response.error('Không tìm thấy mã truyện trên trang ' + url);
    var payload = JSON.stringify([am[1]]);
    var post = function (id) {
      var r = C.get(url, { method: 'POST', headers: { 'Next-Action': id, 'Accept': 'text/x-component', 'Content-Type': 'text/plain;charset=UTF-8' }, body: payload });
      return r && r.ok ? X.rscArray(r.text()) : null;
    };
    var arr = A.id ? post(A.id) : null;
    if (!arr) { var id2 = X.rscAction(html, A.name); if (id2 && id2 !== A.id) arr = post(id2); }
    if (!arr) return Response.error('Không lấy được danh sách chương (Server Action "' + A.name + '")');
    var base = url.replace(/[?#].*$/, '').replace(/\/+$/, '');
    return Response.success(arr.map(function (c) {
      return { name: String(c[A.title || 'label'] || '') + (A.lock && c[A.lock] ? ' 🔒' : ''), url: base + '/' + c[A.slug || 'slugId'], host: BASE_URL };
    }));
  },
  // Join the self.__next_f.push([1,"..."]) chunks and return the longest text row ("<id>:T<hex byte length>,<text>").
  rscText: function (html) {
    var s = '', m, re = /self\.__next_f\.push\(\[1,("(?:[^"\\]|\\.)*")\]\)/g;
    while ((m = re.exec(html))) { try { s += JSON.parse(m[1]); } catch (e) { } }
    var best = '', tr = /([0-9a-f]+):T([0-9a-f]+),/g, t;
    while ((t = tr.exec(s))) {
      var n = parseInt(t[2], 16), i = tr.lastIndex, b = 0;
      while (i < s.length && b < n) { var c = s.charCodeAt(i); if (c < 0x80) b += 1; else if (c < 0x800) b += 2; else if (c >= 0xD800 && c <= 0xDBFF) { b += 4; i++; } else b += 3; i++; }
      var txt = s.slice(tr.lastIndex, i);
      if (txt.length > best.length) best = txt;
      tr.lastIndex = i;
    }
    return best;
  },
  toParas: function (txt) {
    if (/<p[\s>]|<br\s*\/?>/i.test(txt)) return txt;
    return txt.split(/\n+/).map(function (l) { l = l.trim(); return l ? '<p>' + l.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</p>' : ''; }).join('');
  },
  // Video: list servers on the episode page, then sniff a playable stream from each.
  servers: function (url) {
    if (!G.servers) return Response.success([{ title: 'Server', data: url }]);
    var doc = C.html(url, G.req);
    var out = doc.select(G.servers).map(function (e) {
      var d = X.pick(e, G.server_data || ':self@data-link || :self@data-src || :self@href');
      return { title: e.text() || 'Server', data: C.fix(d) };
    }).filter(function (s) { return s.data; });
    return Response.success(out.length ? out : [{ title: 'Server', data: url }]);
  },
  sniff: function (text) {
    text = String(text || '').replace(/\\\//g, '/');
    var m = text.match(/https?:[^"'\s<>\\]+?\.m3u8[^"'\s<>\\]*/i) || text.match(/https?:[^"'\s<>\\]+?\.mp4[^"'\s<>\\]*/i);
    return m ? m[0] : '';
  },
  track: function (data, depth) {
    depth = depth || 0;
    if (/\.(m3u8|mp4)(\?|$)/i.test(data)) return Response.success({ type: 'native', data: data, headers: { Referer: BASE_URL + '/' } });
    var r = C.get(data);
    var body = r.text();
    if (G.video && !depth) { var vv = X.pick(Html.parse(body, data), G.video); if (vv) return Response.success({ type: 'native', data: C.fix(vv), headers: { Referer: BASE_URL + '/' } }); }
    var s = X.sniff(body);
    if (s) return Response.success({ type: 'native', data: s, headers: { Referer: (depth ? data : BASE_URL + '/') } });
    var doc = Html.parse(body, data);
    var ifr = doc.select(G.iframe || 'iframe[src], iframe[data-src]').first();
    if (ifr && depth < 2) { var src = C.fix(ifr.attr('src') || ifr.attr('data-src')); if (src) return X.track(src, depth + 1); }
    return Response.success({ type: 'webview', data: data });
  }
};
