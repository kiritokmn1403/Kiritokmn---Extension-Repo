var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var e_1, _b;
var sa = Object.create;
var se = Object.defineProperty, ca = Object.defineProperties, oa = Object.getOwnPropertyDescriptor, la = Object.getOwnPropertyDescriptors, fa = Object.getOwnPropertyNames, Zu = Object.getOwnPropertySymbols, da = Object.getPrototypeOf, Yu = Object.prototype.hasOwnProperty, ha = Object.prototype.propertyIsEnumerable;
var Ku = function (t, e, a) { return e in t ? se(t, e, { enumerable: !0, configurable: !0, writable: !0, value: a }) : t[e] = a; }, wt = function (t, e) {
    var e_2, _b;
    for (var a in e || (e = {}))
        Yu.call(e, a) && Ku(t, a, e[a]);
    if (Zu)
        try {
            for (var _c = __values(Zu(e)), _d = _c.next(); !_d.done; _d = _c.next()) {
                var a = _d.value;
                ha.call(e, a) && Ku(t, a, e[a]);
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
            }
            finally { if (e_2) throw e_2.error; }
        }
    return t;
}, It = function (t, e) { return ca(t, la(e)); };
var pa = function (t, e) { return function () { return (e || t((e = { exports: {} }).exports, e), e.exports); }; }, Ye = function (t, e) { for (var a in e)
    se(t, a, { get: e[a], enumerable: !0 }); }, tr = function (t, e, a, n) {
    var e_3, _b;
    if (e && typeof e == "object" || typeof e == "function") {
        var _loop_1 = function (s) {
            !Yu.call(t, s) && s !== a && se(t, s, { get: function () { return e[s]; }, enumerable: !(n = oa(e, s)) || n.enumerable });
        };
        try {
            for (var _c = __values(fa(e)), _d = _c.next(); !_d.done; _d = _c.next()) {
                var s = _d.value;
                _loop_1(s);
            }
        }
        catch (e_3_1) { e_3 = { error: e_3_1 }; }
        finally {
            try {
                if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
            }
            finally { if (e_3) throw e_3.error; }
        }
    }
    return t;
};
var Vt = function (t, e, a) { return (a = t != null ? sa(da(t)) : {}, tr(e || !t || !t.__esModule ? se(a, "default", { value: t, enumerable: !0 }) : a, t)); }, ga = function (t) { return tr(se({}, "__esModule", { value: !0 }), t); };
var Pt = pa(function (gi, Lr) { Lr.exports = { trueFunc: function () { return !0; }, falseFunc: function () { return !1; } }; });
var Fn = {};
Ye(Fn, { default: function () { return Mn; } });
module.exports = ga(Fn);
var Se = new Uint16Array('ᵁ<Õıʊҝջאٵ۞ޢߖࠏ੊ઑඡ๭༉༦჊ረዡᐕᒝᓃᓟᔥ\0\0\0\0\0\0ᕫᛍᦍᰒᷝ὾⁠↰⊍⏀⏻⑂⠤⤒ⴈ⹈⿎〖㊺㘹㞬㣾㨨㩱㫠㬮ࠀEMabcfglmnoprstu\\bfms¦³¹ÈÏlig耻Æ䃆P耻&䀦cute耻Á䃁reve;䄂Āiyx}rc耻Â䃂;䐐r;쀀𝔄rave耻À䃀pha;䎑acr;䄀d;橓Āgp¡on;䄄f;쀀𝔸plyFunction;恡ing耻Å䃅Ācs¾Ãr;쀀𝒜ign;扔ilde耻Ã䃃ml耻Ä䃄ЀaceforsuåûþėĜĢħĪĀcrêòkslash;或Ŷöø;櫧ed;挆y;䐑ƀcrtąċĔause;戵noullis;愬a;䎒r;쀀𝔅pf;쀀𝔹eve;䋘còēmpeq;扎܀HOacdefhilorsuōőŖƀƞƢƵƷƺǜȕɳɸɾcy;䐧PY耻©䂩ƀcpyŝŢźute;䄆Ā;iŧŨ拒talDifferentialD;慅leys;愭ȀaeioƉƎƔƘron;䄌dil耻Ç䃇rc;䄈nint;戰ot;䄊ĀdnƧƭilla;䂸terDot;䂷òſi;䎧rcleȀDMPTǇǋǑǖot;抙inus;抖lus;投imes;抗oĀcsǢǸkwiseContourIntegral;戲eCurlyĀDQȃȏoubleQuote;思uote;怙ȀlnpuȞȨɇɕonĀ;eȥȦ户;橴ƀgitȯȶȺruent;扡nt;戯ourIntegral;戮ĀfrɌɎ;愂oduct;成nterClockwiseContourIntegral;戳oss;樯cr;쀀𝒞pĀ;Cʄʅ拓ap;才րDJSZacefiosʠʬʰʴʸˋ˗ˡ˦̳ҍĀ;oŹʥtrahd;椑cy;䐂cy;䐅cy;䐏ƀgrsʿ˄ˇger;怡r;憡hv;櫤Āayː˕ron;䄎;䐔lĀ;t˝˞戇a;䎔r;쀀𝔇Āaf˫̧Ācm˰̢riticalȀADGT̖̜̀̆cute;䂴oŴ̋̍;䋙bleAcute;䋝rave;䁠ilde;䋜ond;拄ferentialD;慆Ѱ̽\0\0\0͔͂\0Ѕf;쀀𝔻ƀ;DE͈͉͍䂨ot;惜qual;扐blèCDLRUVͣͲ΂ϏϢϸontourIntegraìȹoɴ͹\0\0ͻ»͉nArrow;懓Āeo·ΤftƀARTΐΖΡrrow;懐ightArrow;懔eåˊngĀLRΫτeftĀARγιrrow;柸ightArrow;柺ightArrow;柹ightĀATϘϞrrow;懒ee;抨pɁϩ\0\0ϯrrow;懑ownArrow;懕erticalBar;戥ǹABLRTaВЪаўѿͼrrowƀ;BUНОТ憓ar;椓pArrow;懵reve;䌑eft˒к\0ц\0ѐightVector;楐eeVector;楞ectorĀ;Bљњ憽ar;楖ightǔѧ\0ѱeeVector;楟ectorĀ;BѺѻ懁ar;楗eeĀ;A҆҇护rrow;憧ĀctҒҗr;쀀𝒟rok;䄐ࠀNTacdfglmopqstuxҽӀӄӋӞӢӧӮӵԡԯԶՒ՝ՠեG;䅊H耻Ð䃐cute耻É䃉ƀaiyӒӗӜron;䄚rc耻Ê䃊;䐭ot;䄖r;쀀𝔈rave耻È䃈ement;戈ĀapӺӾcr;䄒tyɓԆ\0\0ԒmallSquare;旻erySmallSquare;斫ĀgpԦԪon;䄘f;쀀𝔼silon;䎕uĀaiԼՉlĀ;TՂՃ橵ilde;扂librium;懌Āci՗՚r;愰m;橳a;䎗ml耻Ë䃋Āipժկsts;戃onentialE;慇ʀcfiosօֈ֍ֲ׌y;䐤r;쀀𝔉lledɓ֗\0\0֣mallSquare;旼erySmallSquare;斪Ͱֺ\0ֿ\0\0ׄf;쀀𝔽All;戀riertrf;愱cò׋؀JTabcdfgorstר׬ׯ׺؀ؒؖ؛؝أ٬ٲcy;䐃耻>䀾mmaĀ;d׷׸䎓;䏜reve;䄞ƀeiy؇،ؐdil;䄢rc;䄜;䐓ot;䄠r;쀀𝔊;拙pf;쀀𝔾eater̀EFGLSTصلَٖٛ٦qualĀ;Lؾؿ扥ess;招ullEqual;执reater;檢ess;扷lantEqual;橾ilde;扳cr;쀀𝒢;扫ЀAacfiosuڅڋږڛڞڪھۊRDcy;䐪Āctڐڔek;䋇;䁞irc;䄤r;愌lbertSpace;愋ǰگ\0ڲf;愍izontalLine;攀Āctۃۅòکrok;䄦mpńېۘownHumðįqual;扏܀EJOacdfgmnostuۺ۾܃܇܎ܚܞܡܨ݄ݸދޏޕcy;䐕lig;䄲cy;䐁cute耻Í䃍Āiyܓܘrc耻Î䃎;䐘ot;䄰r;愑rave耻Ì䃌ƀ;apܠܯܿĀcgܴܷr;䄪inaryI;慈lieóϝǴ݉\0ݢĀ;eݍݎ戬Āgrݓݘral;戫section;拂isibleĀCTݬݲomma;恣imes;恢ƀgptݿރވon;䄮f;쀀𝕀a;䎙cr;愐ilde;䄨ǫޚ\0ޞcy;䐆l耻Ï䃏ʀcfosuެ޷޼߂ߐĀiyޱ޵rc;䄴;䐙r;쀀𝔍pf;쀀𝕁ǣ߇\0ߌr;쀀𝒥rcy;䐈kcy;䐄΀HJacfosߤߨ߽߬߱ࠂࠈcy;䐥cy;䐌ppa;䎚Āey߶߻dil;䄶;䐚r;쀀𝔎pf;쀀𝕂cr;쀀𝒦րJTaceflmostࠥࠩࠬࡐࡣ঳সে্਷ੇcy;䐉耻<䀼ʀcmnpr࠷࠼ࡁࡄࡍute;䄹bda;䎛g;柪lacetrf;愒r;憞ƀaeyࡗ࡜ࡡron;䄽dil;䄻;䐛Āfsࡨ॰tԀACDFRTUVarࡾࢩࢱࣦ࣠ࣼयज़ΐ४Ānrࢃ࢏gleBracket;柨rowƀ;BR࢙࢚࢞憐ar;懤ightArrow;懆eiling;挈oǵࢷ\0ࣃbleBracket;柦nǔࣈ\0࣒eeVector;楡ectorĀ;Bࣛࣜ懃ar;楙loor;挊ightĀAV࣯ࣵrrow;憔ector;楎Āerँगeƀ;AVउऊऐ抣rrow;憤ector;楚iangleƀ;BEतथऩ抲ar;槏qual;抴pƀDTVषूौownVector;楑eeVector;楠ectorĀ;Bॖॗ憿ar;楘ectorĀ;B॥०憼ar;楒ightáΜs̀EFGLSTॾঋকঝঢভqualGreater;拚ullEqual;扦reater;扶ess;檡lantEqual;橽ilde;扲r;쀀𝔏Ā;eঽা拘ftarrow;懚idot;䄿ƀnpw৔ਖਛgȀLRlr৞৷ਂਐeftĀAR০৬rrow;柵ightArrow;柷ightArrow;柶eftĀarγਊightáοightáϊf;쀀𝕃erĀLRਢਬeftArrow;憙ightArrow;憘ƀchtਾੀੂòࡌ;憰rok;䅁;扪Ѐacefiosuਗ਼੝੠੷੼અઋ઎p;椅y;䐜Ādl੥੯iumSpace;恟lintrf;愳r;쀀𝔐nusPlus;戓pf;쀀𝕄cò੶;䎜ҀJacefostuણધભીଔଙඑ඗ඞcy;䐊cute;䅃ƀaey઴હાron;䅇dil;䅅;䐝ƀgswે૰଎ativeƀMTV૓૟૨ediumSpace;怋hiĀcn૦૘ë૙eryThiî૙tedĀGL૸ଆreaterGreateòٳessLesóੈLine;䀊r;쀀𝔑ȀBnptଢନଷ଺reak;恠BreakingSpace;䂠f;愕ڀ;CDEGHLNPRSTV୕ୖ୪୼஡௫ఄ౞಄ದ೘ൡඅ櫬Āou୛୤ngruent;扢pCap;扭oubleVerticalBar;戦ƀlqxஃஊ஛ement;戉ualĀ;Tஒஓ扠ilde;쀀≂̸ists;戄reater΀;EFGLSTஶஷ஽௉௓௘௥扯qual;扱ullEqual;쀀≧̸reater;쀀≫̸ess;批lantEqual;쀀⩾̸ilde;扵umpń௲௽ownHump;쀀≎̸qual;쀀≏̸eĀfsఊధtTriangleƀ;BEచఛడ拪ar;쀀⧏̸qual;括s̀;EGLSTవశ఼ౄోౘ扮qual;扰reater;扸ess;쀀≪̸lantEqual;쀀⩽̸ilde;扴estedĀGL౨౹reaterGreater;쀀⪢̸essLess;쀀⪡̸recedesƀ;ESಒಓಛ技qual;쀀⪯̸lantEqual;拠ĀeiಫಹverseElement;戌ghtTriangleƀ;BEೋೌ೒拫ar;쀀⧐̸qual;拭ĀquೝഌuareSuĀbp೨೹setĀ;E೰ೳ쀀⊏̸qual;拢ersetĀ;Eഃആ쀀⊐̸qual;拣ƀbcpഓതൎsetĀ;Eഛഞ쀀⊂⃒qual;抈ceedsȀ;ESTലള഻െ抁qual;쀀⪰̸lantEqual;拡ilde;쀀≿̸ersetĀ;E൘൛쀀⊃⃒qual;抉ildeȀ;EFT൮൯൵ൿ扁qual;扄ullEqual;扇ilde;扉erticalBar;戤cr;쀀𝒩ilde耻Ñ䃑;䎝܀Eacdfgmoprstuvලෂ෉෕ෛ෠෧෼ขภยา฿ไlig;䅒cute耻Ó䃓Āiy෎ීrc耻Ô䃔;䐞blac;䅐r;쀀𝔒rave耻Ò䃒ƀaei෮ෲ෶cr;䅌ga;䎩cron;䎟pf;쀀𝕆enCurlyĀDQฎบoubleQuote;怜uote;怘;橔Āclวฬr;쀀𝒪ash耻Ø䃘iŬื฼de耻Õ䃕es;樷ml耻Ö䃖erĀBP๋๠Āar๐๓r;怾acĀek๚๜;揞et;掴arenthesis;揜Ҁacfhilors๿ງຊຏຒດຝະ໼rtialD;戂y;䐟r;쀀𝔓i;䎦;䎠usMinus;䂱Āipຢອncareplanåڝf;愙Ȁ;eio຺ູ໠໤檻cedesȀ;EST່້໏໚扺qual;檯lantEqual;扼ilde;找me;怳Ādp໩໮uct;戏ortionĀ;aȥ໹l;戝Āci༁༆r;쀀𝒫;䎨ȀUfos༑༖༛༟OT耻"䀢r;쀀𝔔pf;愚cr;쀀𝒬؀BEacefhiorsu༾གྷཇའཱིྦྷྪྭ႖ႩႴႾarr;椐G耻®䂮ƀcnrཎནབute;䅔g;柫rĀ;tཛྷཝ憠l;椖ƀaeyཧཬཱron;䅘dil;䅖;䐠Ā;vླྀཹ愜erseĀEUྂྙĀlq྇ྎement;戋uilibrium;懋pEquilibrium;楯r»ཹo;䎡ghtЀACDFTUVa࿁࿫࿳ဢဨၛႇϘĀnr࿆࿒gleBracket;柩rowƀ;BL࿜࿝࿡憒ar;懥eftArrow;懄eiling;按oǵ࿹\0စbleBracket;柧nǔည\0နeeVector;楝ectorĀ;Bဝသ懂ar;楕loor;挋Āerိ၃eƀ;AVဵံြ抢rrow;憦ector;楛iangleƀ;BEၐၑၕ抳ar;槐qual;抵pƀDTVၣၮၸownVector;楏eeVector;楜ectorĀ;Bႂႃ憾ar;楔ectorĀ;B႑႒懀ar;楓Āpuႛ႞f;愝ndImplies;楰ightarrow;懛ĀchႹႼr;愛;憱leDelayed;槴ڀHOacfhimoqstuფჱჷჽᄙᄞᅑᅖᅡᅧᆵᆻᆿĀCcჩხHcy;䐩y;䐨FTcy;䐬cute;䅚ʀ;aeiyᄈᄉᄎᄓᄗ檼ron;䅠dil;䅞rc;䅜;䐡r;쀀𝔖ortȀDLRUᄪᄴᄾᅉownArrow»ОeftArrow»࢚ightArrow»࿝pArrow;憑gma;䎣allCircle;战pf;쀀𝕊ɲᅭ\0\0ᅰt;戚areȀ;ISUᅻᅼᆉᆯ斡ntersection;抓uĀbpᆏᆞsetĀ;Eᆗᆘ抏qual;抑ersetĀ;Eᆨᆩ抐qual;抒nion;抔cr;쀀𝒮ar;拆ȀbcmpᇈᇛሉላĀ;sᇍᇎ拐etĀ;Eᇍᇕqual;抆ĀchᇠህeedsȀ;ESTᇭᇮᇴᇿ扻qual;檰lantEqual;扽ilde;承Tháྌ;我ƀ;esሒሓሣ拑rsetĀ;Eሜም抃qual;抇et»ሓրHRSacfhiorsሾቄ቉ቕ቞ቱቶኟዂወዑORN耻Þ䃞ADE;愢ĀHc቎ቒcy;䐋y;䐦Ābuቚቜ;䀉;䎤ƀaeyብቪቯron;䅤dil;䅢;䐢r;쀀𝔗Āeiቻ኉ǲኀ\0ኇefore;戴a;䎘Ācn኎ኘkSpace;쀀  Space;怉ldeȀ;EFTካኬኲኼ戼qual;扃ullEqual;扅ilde;扈pf;쀀𝕋ipleDot;惛Āctዖዛr;쀀𝒯rok;䅦ૡዷጎጚጦ\0ጬጱ\0\0\0\0\0ጸጽ፷ᎅ\0᏿ᐄᐊᐐĀcrዻጁute耻Ú䃚rĀ;oጇገ憟cir;楉rǣጓ\0጖y;䐎ve;䅬Āiyጞጣrc耻Û䃛;䐣blac;䅰r;쀀𝔘rave耻Ù䃙acr;䅪Ādiፁ፩erĀBPፈ፝Āarፍፐr;䁟acĀekፗፙ;揟et;掵arenthesis;揝onĀ;P፰፱拃lus;抎Āgp፻፿on;䅲f;쀀𝕌ЀADETadps᎕ᎮᎸᏄϨᏒᏗᏳrrowƀ;BDᅐᎠᎤar;椒ownArrow;懅ownArrow;憕quilibrium;楮eeĀ;AᏋᏌ报rrow;憥ownáϳerĀLRᏞᏨeftArrow;憖ightArrow;憗iĀ;lᏹᏺ䏒on;䎥ing;䅮cr;쀀𝒰ilde;䅨ml耻Ü䃜ҀDbcdefosvᐧᐬᐰᐳᐾᒅᒊᒐᒖash;披ar;櫫y;䐒ashĀ;lᐻᐼ抩;櫦Āerᑃᑅ;拁ƀbtyᑌᑐᑺar;怖Ā;iᑏᑕcalȀBLSTᑡᑥᑪᑴar;戣ine;䁼eparator;杘ilde;所ThinSpace;怊r;쀀𝔙pf;쀀𝕍cr;쀀𝒱dash;抪ʀcefosᒧᒬᒱᒶᒼirc;䅴dge;拀r;쀀𝔚pf;쀀𝕎cr;쀀𝒲Ȁfiosᓋᓐᓒᓘr;쀀𝔛;䎞pf;쀀𝕏cr;쀀𝒳ҀAIUacfosuᓱᓵᓹᓽᔄᔏᔔᔚᔠcy;䐯cy;䐇cy;䐮cute耻Ý䃝Āiyᔉᔍrc;䅶;䐫r;쀀𝔜pf;쀀𝕐cr;쀀𝒴ml;䅸ЀHacdefosᔵᔹᔿᕋᕏᕝᕠᕤcy;䐖cute;䅹Āayᕄᕉron;䅽;䐗ot;䅻ǲᕔ\0ᕛoWidtè૙a;䎖r;愨pf;愤cr;쀀𝒵௡ᖃᖊᖐ\0ᖰᖶᖿ\0\0\0\0ᗆᗛᗫᙟ᙭\0ᚕ᚛ᚲᚹ\0ᚾcute耻á䃡reve;䄃̀;Ediuyᖜᖝᖡᖣᖨᖭ戾;쀀∾̳;房rc耻â䃢te肻´̆;䐰lig耻æ䃦Ā;r²ᖺ;쀀𝔞rave耻à䃠ĀepᗊᗖĀfpᗏᗔsym;愵èᗓha;䎱ĀapᗟcĀclᗤᗧr;䄁g;樿ɤᗰ\0\0ᘊʀ;adsvᗺᗻᗿᘁᘇ戧nd;橕;橜lope;橘;橚΀;elmrszᘘᘙᘛᘞᘿᙏᙙ戠;榤e»ᘙsdĀ;aᘥᘦ戡ѡᘰᘲᘴᘶᘸᘺᘼᘾ;榨;榩;榪;榫;榬;榭;榮;榯tĀ;vᙅᙆ戟bĀ;dᙌᙍ抾;榝Āptᙔᙗh;戢»¹arr;捼Āgpᙣᙧon;䄅f;쀀𝕒΀;Eaeiop዁ᙻᙽᚂᚄᚇᚊ;橰cir;橯;扊d;手s;䀧roxĀ;e዁ᚒñᚃing耻å䃥ƀctyᚡᚦᚨr;쀀𝒶;䀪mpĀ;e዁ᚯñʈilde耻ã䃣ml耻ä䃤Āciᛂᛈoninôɲnt;樑ࠀNabcdefiklnoprsu᛭ᛱᜰ᜼ᝃᝈ᝸᝽០៦ᠹᡐᜍ᤽᥈ᥰot;櫭Ācrᛶ᜞kȀcepsᜀᜅᜍᜓong;扌psilon;䏶rime;怵imĀ;e᜚᜛戽q;拍Ŷᜢᜦee;抽edĀ;gᜬᜭ挅e»ᜭrkĀ;t፜᜷brk;掶Āoyᜁᝁ;䐱quo;怞ʀcmprtᝓ᝛ᝡᝤᝨausĀ;eĊĉptyv;榰séᜌnoõēƀahwᝯ᝱ᝳ;䎲;愶een;扬r;쀀𝔟g΀costuvwឍឝឳេ៕៛៞ƀaiuបពរðݠrc;旯p»፱ƀdptឤឨឭot;樀lus;樁imes;樂ɱឹ\0\0ើcup;樆ar;昅riangleĀdu៍្own;施p;斳plus;樄eåᑄåᒭarow;植ƀako៭ᠦᠵĀcn៲ᠣkƀlst៺֫᠂ozenge;槫riangleȀ;dlr᠒᠓᠘᠝斴own;斾eft;旂ight;斸k;搣Ʊᠫ\0ᠳƲᠯ\0ᠱ;斒;斑4;斓ck;斈ĀeoᠾᡍĀ;qᡃᡆ쀀=⃥uiv;쀀≡⃥t;挐Ȁptwxᡙᡞᡧᡬf;쀀𝕓Ā;tᏋᡣom»Ꮜtie;拈؀DHUVbdhmptuvᢅᢖᢪᢻᣗᣛᣬ᣿ᤅᤊᤐᤡȀLRlrᢎᢐᢒᢔ;敗;敔;敖;敓ʀ;DUduᢡᢢᢤᢦᢨ敐;敦;敩;敤;敧ȀLRlrᢳᢵᢷᢹ;敝;敚;敜;教΀;HLRhlrᣊᣋᣍᣏᣑᣓᣕ救;敬;散;敠;敫;敢;敟ox;槉ȀLRlrᣤᣦᣨᣪ;敕;敒;攐;攌ʀ;DUduڽ᣷᣹᣻᣽;敥;敨;攬;攴inus;抟lus;択imes;抠ȀLRlrᤙᤛᤝ᤟;敛;敘;攘;攔΀;HLRhlrᤰᤱᤳᤵᤷ᤻᤹攂;敪;敡;敞;攼;攤;攜Āevģ᥂bar耻¦䂦Ȁceioᥑᥖᥚᥠr;쀀𝒷mi;恏mĀ;e᜚᜜lƀ;bhᥨᥩᥫ䁜;槅sub;柈Ŭᥴ᥾lĀ;e᥹᥺怢t»᥺pƀ;Eeįᦅᦇ;檮Ā;qۜۛೡᦧ\0᧨ᨑᨕᨲ\0ᨷᩐ\0\0᪴\0\0᫁\0\0ᬡᬮ᭍᭒\0᯽\0ᰌƀcpr᦭ᦲ᧝ute;䄇̀;abcdsᦿᧀᧄ᧊᧕᧙戩nd;橄rcup;橉Āau᧏᧒p;橋p;橇ot;橀;쀀∩︀Āeo᧢᧥t;恁îړȀaeiu᧰᧻ᨁᨅǰ᧵\0᧸s;橍on;䄍dil耻ç䃧rc;䄉psĀ;sᨌᨍ橌m;橐ot;䄋ƀdmnᨛᨠᨦil肻¸ƭptyv;榲t脀¢;eᨭᨮ䂢räƲr;쀀𝔠ƀceiᨽᩀᩍy;䑇ckĀ;mᩇᩈ朓ark»ᩈ;䏇r΀;Ecefms᩟᩠ᩢᩫ᪤᪪᪮旋;槃ƀ;elᩩᩪᩭ䋆q;扗eɡᩴ\0\0᪈rrowĀlr᩼᪁eft;憺ight;憻ʀRSacd᪒᪔᪖᪚᪟»ཇ;擈st;抛irc;抚ash;抝nint;樐id;櫯cir;槂ubsĀ;u᪻᪼晣it»᪼ˬ᫇᫔᫺\0ᬊonĀ;eᫍᫎ䀺Ā;qÇÆɭ᫙\0\0᫢aĀ;t᫞᫟䀬;䁀ƀ;fl᫨᫩᫫戁îᅠeĀmx᫱᫶ent»᫩eóɍǧ᫾\0ᬇĀ;dኻᬂot;橭nôɆƀfryᬐᬔᬗ;쀀𝕔oäɔ脀©;sŕᬝr;愗Āaoᬥᬩrr;憵ss;朗Ācuᬲᬷr;쀀𝒸Ābpᬼ᭄Ā;eᭁᭂ櫏;櫑Ā;eᭉᭊ櫐;櫒dot;拯΀delprvw᭠᭬᭷ᮂᮬᯔ᯹arrĀlr᭨᭪;椸;椵ɰ᭲\0\0᭵r;拞c;拟arrĀ;p᭿ᮀ憶;椽̀;bcdosᮏᮐᮖᮡᮥᮨ截rcap;橈Āauᮛᮞp;橆p;橊ot;抍r;橅;쀀∪︀Ȁalrv᮵ᮿᯞᯣrrĀ;mᮼᮽ憷;椼yƀevwᯇᯔᯘqɰᯎ\0\0ᯒreã᭳uã᭵ee;拎edge;拏en耻¤䂤earrowĀlrᯮ᯳eft»ᮀight»ᮽeäᯝĀciᰁᰇoninôǷnt;戱lcty;挭ঀAHabcdefhijlorstuwz᰸᰻᰿ᱝᱩᱵᲊᲞᲬᲷ᳻᳿ᴍᵻᶑᶫᶻ᷆᷍rò΁ar;楥Ȁglrs᱈ᱍ᱒᱔ger;怠eth;愸òᄳhĀ;vᱚᱛ怐»ऊūᱡᱧarow;椏aã̕Āayᱮᱳron;䄏;䐴ƀ;ao̲ᱼᲄĀgrʿᲁr;懊tseq;橷ƀglmᲑᲔᲘ耻°䂰ta;䎴ptyv;榱ĀirᲣᲨsht;楿;쀀𝔡arĀlrᲳᲵ»ࣜ»သʀaegsv᳂͸᳖᳜᳠mƀ;oș᳊᳔ndĀ;ș᳑uit;晦amma;䏝in;拲ƀ;io᳧᳨᳸䃷de脀÷;o᳧ᳰntimes;拇nø᳷cy;䑒cɯᴆ\0\0ᴊrn;挞op;挍ʀlptuwᴘᴝᴢᵉᵕlar;䀤f;쀀𝕕ʀ;emps̋ᴭᴷᴽᵂqĀ;d͒ᴳot;扑inus;戸lus;戔quare;抡blebarwedgåúnƀadhᄮᵝᵧownarrowóᲃarpoonĀlrᵲᵶefôᲴighôᲶŢᵿᶅkaro÷གɯᶊ\0\0ᶎrn;挟op;挌ƀcotᶘᶣᶦĀryᶝᶡ;쀀𝒹;䑕l;槶rok;䄑Ādrᶰᶴot;拱iĀ;fᶺ᠖斿Āah᷀᷃ròЩaòྦangle;榦Āci᷒ᷕy;䑟grarr;柿ऀDacdefglmnopqrstuxḁḉḙḸոḼṉṡṾấắẽỡἪἷὄ὎὚ĀDoḆᴴoôᲉĀcsḎḔute耻é䃩ter;橮ȀaioyḢḧḱḶron;䄛rĀ;cḭḮ扖耻ê䃪lon;払;䑍ot;䄗ĀDrṁṅot;扒;쀀𝔢ƀ;rsṐṑṗ檚ave耻è䃨Ā;dṜṝ檖ot;檘Ȁ;ilsṪṫṲṴ檙nters;揧;愓Ā;dṹṺ檕ot;檗ƀapsẅẉẗcr;䄓tyƀ;svẒẓẕ戅et»ẓpĀ1;ẝẤĳạả;怄;怅怃ĀgsẪẬ;䅋p;怂ĀgpẴẸon;䄙f;쀀𝕖ƀalsỄỎỒrĀ;sỊị拕l;槣us;橱iƀ;lvỚớở䎵on»ớ;䏵ȀcsuvỪỳἋἣĀioữḱrc»Ḯɩỹ\0\0ỻíՈantĀglἂἆtr»ṝess»Ṻƀaeiἒ἖Ἒls;䀽st;扟vĀ;DȵἠD;橸parsl;槥ĀDaἯἳot;打rr;楱ƀcdiἾὁỸr;愯oô͒ĀahὉὋ;䎷耻ð䃰Āmrὓὗl耻ë䃫o;悬ƀcipὡὤὧl;䀡sôծĀeoὬὴctatioîՙnentialåչৡᾒ\0ᾞ\0ᾡᾧ\0\0ῆῌ\0ΐ\0ῦῪ \0 ⁚llingdotseñṄy;䑄male;晀ƀilrᾭᾳ῁lig;耀ﬃɩᾹ\0\0᾽g;耀ﬀig;耀ﬄ;쀀𝔣lig;耀ﬁlig;쀀fjƀaltῙ῜ῡt;晭ig;耀ﬂns;斱of;䆒ǰ΅\0ῳf;쀀𝕗ĀakֿῷĀ;vῼ´拔;櫙artint;樍Āao‌⁕Ācs‑⁒α‚‰‸⁅⁈\0⁐β•‥‧‪‬\0‮耻½䂽;慓耻¼䂼;慕;慙;慛Ƴ‴\0‶;慔;慖ʴ‾⁁\0\0⁃耻¾䂾;慗;慜5;慘ƶ⁌\0⁎;慚;慝8;慞l;恄wn;挢cr;쀀𝒻ࢀEabcdefgijlnorstv₂₉₟₥₰₴⃰⃵⃺⃿℃ℒℸ̗ℾ⅒↞Ā;lٍ₇;檌ƀcmpₐₕ₝ute;䇵maĀ;dₜ᳚䎳;檆reve;䄟Āiy₪₮rc;䄝;䐳ot;䄡Ȁ;lqsؾق₽⃉ƀ;qsؾٌ⃄lanô٥Ȁ;cdl٥⃒⃥⃕c;檩otĀ;o⃜⃝檀Ā;l⃢⃣檂;檄Ā;e⃪⃭쀀⋛︀s;檔r;쀀𝔤Ā;gٳ؛mel;愷cy;䑓Ȁ;Eajٚℌℎℐ;檒;檥;檤ȀEaesℛℝ℩ℴ;扩pĀ;p℣ℤ檊rox»ℤĀ;q℮ℯ檈Ā;q℮ℛim;拧pf;쀀𝕘Āci⅃ⅆr;愊mƀ;el٫ⅎ⅐;檎;檐茀>;cdlqr׮ⅠⅪⅮⅳⅹĀciⅥⅧ;檧r;橺ot;拗Par;榕uest;橼ʀadelsↄⅪ←ٖ↛ǰ↉\0↎proø₞r;楸qĀlqؿ↖lesó₈ií٫Āen↣↭rtneqq;쀀≩︀Å↪ԀAabcefkosy⇄⇇⇱⇵⇺∘∝∯≨≽ròΠȀilmr⇐⇔⇗⇛rsðᒄf»․ilôکĀdr⇠⇤cy;䑊ƀ;cwࣴ⇫⇯ir;楈;憭ar;意irc;䄥ƀalr∁∎∓rtsĀ;u∉∊晥it»∊lip;怦con;抹r;쀀𝔥sĀew∣∩arow;椥arow;椦ʀamopr∺∾≃≞≣rr;懿tht;戻kĀlr≉≓eftarrow;憩ightarrow;憪f;쀀𝕙bar;怕ƀclt≯≴≸r;쀀𝒽asè⇴rok;䄧Ābp⊂⊇ull;恃hen»ᱛૡ⊣\0⊪\0⊸⋅⋎\0⋕⋳\0\0⋸⌢⍧⍢⍿\0⎆⎪⎴cute耻í䃭ƀ;iyݱ⊰⊵rc耻î䃮;䐸Ācx⊼⊿y;䐵cl耻¡䂡ĀfrΟ⋉;쀀𝔦rave耻ì䃬Ȁ;inoܾ⋝⋩⋮Āin⋢⋦nt;樌t;戭fin;槜ta;愩lig;䄳ƀaop⋾⌚⌝ƀcgt⌅⌈⌗r;䄫ƀelpܟ⌏⌓inåގarôܠh;䄱f;抷ed;䆵ʀ;cfotӴ⌬⌱⌽⍁are;愅inĀ;t⌸⌹戞ie;槝doô⌙ʀ;celpݗ⍌⍐⍛⍡al;抺Āgr⍕⍙eróᕣã⍍arhk;樗rod;樼Ȁcgpt⍯⍲⍶⍻y;䑑on;䄯f;쀀𝕚a;䎹uest耻¿䂿Āci⎊⎏r;쀀𝒾nʀ;EdsvӴ⎛⎝⎡ӳ;拹ot;拵Ā;v⎦⎧拴;拳Ā;iݷ⎮lde;䄩ǫ⎸\0⎼cy;䑖l耻ï䃯̀cfmosu⏌⏗⏜⏡⏧⏵Āiy⏑⏕rc;䄵;䐹r;쀀𝔧ath;䈷pf;쀀𝕛ǣ⏬\0⏱r;쀀𝒿rcy;䑘kcy;䑔Ѐacfghjos␋␖␢␧␭␱␵␻ppaĀ;v␓␔䎺;䏰Āey␛␠dil;䄷;䐺r;쀀𝔨reen;䄸cy;䑅cy;䑜pf;쀀𝕜cr;쀀𝓀஀ABEHabcdefghjlmnoprstuv⑰⒁⒆⒍⒑┎┽╚▀♎♞♥♹♽⚚⚲⛘❝❨➋⟀⠁⠒ƀart⑷⑺⑼rò৆òΕail;椛arr;椎Ā;gঔ⒋;檋ar;楢ॣ⒥\0⒪\0⒱\0\0\0\0\0⒵Ⓔ\0ⓆⓈⓍ\0⓹ute;䄺mptyv;榴raîࡌbda;䎻gƀ;dlࢎⓁⓃ;榑åࢎ;檅uo耻«䂫rЀ;bfhlpst࢙ⓞⓦⓩ⓫⓮⓱⓵Ā;f࢝ⓣs;椟s;椝ë≒p;憫l;椹im;楳l;憢ƀ;ae⓿─┄檫il;椙Ā;s┉┊檭;쀀⪭︀ƀabr┕┙┝rr;椌rk;杲Āak┢┬cĀek┨┪;䁻;䁛Āes┱┳;榋lĀdu┹┻;榏;榍Ȁaeuy╆╋╖╘ron;䄾Ādi═╔il;䄼ìࢰâ┩;䐻Ȁcqrs╣╦╭╽a;椶uoĀ;rนᝆĀdu╲╷har;楧shar;楋h;憲ʀ;fgqs▋▌উ◳◿扤tʀahlrt▘▤▷◂◨rrowĀ;t࢙□aé⓶arpoonĀdu▯▴own»њp»०eftarrows;懇ightƀahs◍◖◞rrowĀ;sࣴࢧarpoonó྘quigarro÷⇰hreetimes;拋ƀ;qs▋ও◺lanôবʀ;cdgsব☊☍☝☨c;檨otĀ;o☔☕橿Ā;r☚☛檁;檃Ā;e☢☥쀀⋚︀s;檓ʀadegs☳☹☽♉♋pproøⓆot;拖qĀgq♃♅ôউgtò⒌ôছiíলƀilr♕࣡♚sht;楼;쀀𝔩Ā;Eজ♣;檑š♩♶rĀdu▲♮Ā;l॥♳;楪lk;斄cy;䑙ʀ;achtੈ⚈⚋⚑⚖rò◁orneòᴈard;楫ri;旺Āio⚟⚤dot;䅀ustĀ;a⚬⚭掰che»⚭ȀEaes⚻⚽⛉⛔;扨pĀ;p⛃⛄檉rox»⛄Ā;q⛎⛏檇Ā;q⛎⚻im;拦Ѐabnoptwz⛩⛴⛷✚✯❁❇❐Ānr⛮⛱g;柬r;懽rëࣁgƀlmr⛿✍✔eftĀar০✇ightá৲apsto;柼ightá৽parrowĀlr✥✩efô⓭ight;憬ƀafl✶✹✽r;榅;쀀𝕝us;樭imes;樴š❋❏st;戗áፎƀ;ef❗❘᠀旊nge»❘arĀ;l❤❥䀨t;榓ʀachmt❳❶❼➅➇ròࢨorneòᶌarĀ;d྘➃;業;怎ri;抿̀achiqt➘➝ੀ➢➮➻quo;怹r;쀀𝓁mƀ;egল➪➬;檍;檏Ābu┪➳oĀ;rฟ➹;怚rok;䅂萀<;cdhilqrࠫ⟒☹⟜⟠⟥⟪⟰Āci⟗⟙;檦r;橹reå◲mes;拉arr;楶uest;橻ĀPi⟵⟹ar;榖ƀ;ef⠀भ᠛旃rĀdu⠇⠍shar;楊har;楦Āen⠗⠡rtneqq;쀀≨︀Å⠞܀Dacdefhilnopsu⡀⡅⢂⢎⢓⢠⢥⢨⣚⣢⣤ઃ⣳⤂Dot;戺Ȁclpr⡎⡒⡣⡽r耻¯䂯Āet⡗⡙;時Ā;e⡞⡟朠se»⡟Ā;sျ⡨toȀ;dluျ⡳⡷⡻owîҌefôएðᏑker;斮Āoy⢇⢌mma;権;䐼ash;怔asuredangle»ᘦr;쀀𝔪o;愧ƀcdn⢯⢴⣉ro耻µ䂵Ȁ;acdᑤ⢽⣀⣄sôᚧir;櫰ot肻·Ƶusƀ;bd⣒ᤃ⣓戒Ā;uᴼ⣘;横ţ⣞⣡p;櫛ò−ðઁĀdp⣩⣮els;抧f;쀀𝕞Āct⣸⣽r;쀀𝓂pos»ᖝƀ;lm⤉⤊⤍䎼timap;抸ఀGLRVabcdefghijlmoprstuvw⥂⥓⥾⦉⦘⧚⧩⨕⨚⩘⩝⪃⪕⪤⪨⬄⬇⭄⭿⮮ⰴⱧⱼ⳩Āgt⥇⥋;쀀⋙̸Ā;v⥐௏쀀≫⃒ƀelt⥚⥲⥶ftĀar⥡⥧rrow;懍ightarrow;懎;쀀⋘̸Ā;v⥻ే쀀≪⃒ightarrow;懏ĀDd⦎⦓ash;抯ash;抮ʀbcnpt⦣⦧⦬⦱⧌la»˞ute;䅄g;쀀∠⃒ʀ;Eiop඄⦼⧀⧅⧈;쀀⩰̸d;쀀≋̸s;䅉roø඄urĀ;a⧓⧔普lĀ;s⧓ସǳ⧟\0⧣p肻 ଷmpĀ;e௹ఀʀaeouy⧴⧾⨃⨐⨓ǰ⧹\0⧻;橃on;䅈dil;䅆ngĀ;dൾ⨊ot;쀀⩭̸p;橂;䐽ash;怓΀;Aadqsxஒ⨩⨭⨻⩁⩅⩐rr;懗rĀhr⨳⨶k;椤Ā;oᏲᏰot;쀀≐̸uiöୣĀei⩊⩎ar;椨í஘istĀ;s஠டr;쀀𝔫ȀEest௅⩦⩹⩼ƀ;qs஼⩭௡ƀ;qs஼௅⩴lanô௢ií௪Ā;rஶ⪁»ஷƀAap⪊⪍⪑rò⥱rr;憮ar;櫲ƀ;svྍ⪜ྌĀ;d⪡⪢拼;拺cy;䑚΀AEadest⪷⪺⪾⫂⫅⫶⫹rò⥦;쀀≦̸rr;憚r;急Ȁ;fqs఻⫎⫣⫯tĀar⫔⫙rro÷⫁ightarro÷⪐ƀ;qs఻⪺⫪lanôౕĀ;sౕ⫴»శiíౝĀ;rవ⫾iĀ;eచథiäඐĀpt⬌⬑f;쀀𝕟膀¬;in⬙⬚⬶䂬nȀ;Edvஉ⬤⬨⬮;쀀⋹̸ot;쀀⋵̸ǡஉ⬳⬵;拷;拶iĀ;vಸ⬼ǡಸ⭁⭃;拾;拽ƀaor⭋⭣⭩rȀ;ast୻⭕⭚⭟lleì୻l;쀀⫽⃥;쀀∂̸lint;樔ƀ;ceಒ⭰⭳uåಥĀ;cಘ⭸Ā;eಒ⭽ñಘȀAait⮈⮋⮝⮧rò⦈rrƀ;cw⮔⮕⮙憛;쀀⤳̸;쀀↝̸ghtarrow»⮕riĀ;eೋೖ΀chimpqu⮽⯍⯙⬄୸⯤⯯Ȁ;cerല⯆ഷ⯉uå൅;쀀𝓃ortɭ⬅\0\0⯖ará⭖mĀ;e൮⯟Ā;q൴൳suĀbp⯫⯭å೸åഋƀbcp⯶ⰑⰙȀ;Ees⯿ⰀഢⰄ抄;쀀⫅̸etĀ;eഛⰋqĀ;qണⰀcĀ;eലⰗñസȀ;EesⰢⰣൟⰧ抅;쀀⫆̸etĀ;e൘ⰮqĀ;qൠⰣȀgilrⰽⰿⱅⱇìௗlde耻ñ䃱çృiangleĀlrⱒⱜeftĀ;eచⱚñదightĀ;eೋⱥñ೗Ā;mⱬⱭ䎽ƀ;esⱴⱵⱹ䀣ro;愖p;怇ҀDHadgilrsⲏⲔⲙⲞⲣⲰⲶⳓⳣash;抭arr;椄p;쀀≍⃒ash;抬ĀetⲨⲬ;쀀≥⃒;쀀>⃒nfin;槞ƀAetⲽⳁⳅrr;椂;쀀≤⃒Ā;rⳊⳍ쀀<⃒ie;쀀⊴⃒ĀAtⳘⳜrr;椃rie;쀀⊵⃒im;쀀∼⃒ƀAan⳰⳴ⴂrr;懖rĀhr⳺⳽k;椣Ā;oᏧᏥear;椧ቓ᪕\0\0\0\0\0\0\0\0\0\0\0\0\0ⴭ\0ⴸⵈⵠⵥ⵲ⶄᬇ\0\0ⶍⶫ\0ⷈⷎ\0ⷜ⸙⸫⸾⹃Ācsⴱ᪗ute耻ó䃳ĀiyⴼⵅrĀ;c᪞ⵂ耻ô䃴;䐾ʀabios᪠ⵒⵗǈⵚlac;䅑v;樸old;榼lig;䅓Ācr⵩⵭ir;榿;쀀𝔬ͯ⵹\0\0⵼\0ⶂn;䋛ave耻ò䃲;槁Ābmⶈ෴ar;榵Ȁacitⶕ⶘ⶥⶨrò᪀Āir⶝ⶠr;榾oss;榻nå๒;槀ƀaeiⶱⶵⶹcr;䅍ga;䏉ƀcdnⷀⷅǍron;䎿;榶pf;쀀𝕠ƀaelⷔ⷗ǒr;榷rp;榹΀;adiosvⷪⷫⷮ⸈⸍⸐⸖戨rò᪆Ȁ;efmⷷⷸ⸂⸅橝rĀ;oⷾⷿ愴f»ⷿ耻ª䂪耻º䂺gof;抶r;橖lope;橗;橛ƀclo⸟⸡⸧ò⸁ash耻ø䃸l;折iŬⸯ⸴de耻õ䃵esĀ;aǛ⸺s;樶ml耻ö䃶bar;挽ૡ⹞\0⹽\0⺀⺝\0⺢⺹\0\0⻋ຜ\0⼓\0\0⼫⾼\0⿈rȀ;astЃ⹧⹲຅脀¶;l⹭⹮䂶leìЃɩ⹸\0\0⹻m;櫳;櫽y;䐿rʀcimpt⺋⺏⺓ᡥ⺗nt;䀥od;䀮il;怰enk;怱r;쀀𝔭ƀimo⺨⺰⺴Ā;v⺭⺮䏆;䏕maô੶ne;明ƀ;tv⺿⻀⻈䏀chfork»´;䏖Āau⻏⻟nĀck⻕⻝kĀ;h⇴⻛;愎ö⇴sҀ;abcdemst⻳⻴ᤈ⻹⻽⼄⼆⼊⼎䀫cir;樣ir;樢Āouᵀ⼂;樥;橲n肻±ຝim;樦wo;樧ƀipu⼙⼠⼥ntint;樕f;쀀𝕡nd耻£䂣Ԁ;Eaceinosu່⼿⽁⽄⽇⾁⾉⾒⽾⾶;檳p;檷uå໙Ā;c໎⽌̀;acens່⽙⽟⽦⽨⽾pproø⽃urlyeñ໙ñ໎ƀaes⽯⽶⽺pprox;檹qq;檵im;拨iíໟmeĀ;s⾈ຮ怲ƀEas⽸⾐⽺ð⽵ƀdfp໬⾙⾯ƀals⾠⾥⾪lar;挮ine;挒urf;挓Ā;t໻⾴ï໻rel;抰Āci⿀⿅r;쀀𝓅;䏈ncsp;怈̀fiopsu⿚⋢⿟⿥⿫⿱r;쀀𝔮pf;쀀𝕢rime;恗cr;쀀𝓆ƀaeo⿸〉〓tĀei⿾々rnionóڰnt;樖stĀ;e【】䀿ñἙô༔઀ABHabcdefhilmnoprstux぀けさすムㄎㄫㅇㅢㅲㆎ㈆㈕㈤㈩㉘㉮㉲㊐㊰㊷ƀartぇおがròႳòϝail;検aròᱥar;楤΀cdenqrtとふへみわゔヌĀeuねぱ;쀀∽̱te;䅕iãᅮmptyv;榳gȀ;del࿑らるろ;榒;榥å࿑uo耻»䂻rր;abcfhlpstw࿜ガクシスゼゾダッデナp;極Ā;f࿠ゴs;椠;椳s;椞ë≝ð✮l;楅im;楴l;憣;憝Āaiパフil;椚oĀ;nホボ戶aló༞ƀabrョリヮrò៥rk;杳ĀakンヽcĀekヹ・;䁽;䁝Āes㄂㄄;榌lĀduㄊㄌ;榎;榐Ȁaeuyㄗㄜㄧㄩron;䅙Ādiㄡㄥil;䅗ì࿲âヺ;䑀Ȁclqsㄴㄷㄽㅄa;椷dhar;楩uoĀ;rȎȍh;憳ƀacgㅎㅟངlȀ;ipsླྀㅘㅛႜnåႻarôྩt;断ƀilrㅩဣㅮsht;楽;쀀𝔯ĀaoㅷㆆrĀduㅽㅿ»ѻĀ;l႑ㆄ;楬Ā;vㆋㆌ䏁;䏱ƀgns㆕ㇹㇼht̀ahlrstㆤㆰ㇂㇘㇤㇮rrowĀ;t࿜ㆭaéトarpoonĀduㆻㆿowîㅾp»႒eftĀah㇊㇐rrowó࿪arpoonóՑightarrows;應quigarro÷ニhreetimes;拌g;䋚ingdotseñἲƀahm㈍㈐㈓rò࿪aòՑ;怏oustĀ;a㈞㈟掱che»㈟mid;櫮Ȁabpt㈲㈽㉀㉒Ānr㈷㈺g;柭r;懾rëဃƀafl㉇㉊㉎r;榆;쀀𝕣us;樮imes;樵Āap㉝㉧rĀ;g㉣㉤䀩t;榔olint;樒arò㇣Ȁachq㉻㊀Ⴜ㊅quo;怺r;쀀𝓇Ābu・㊊oĀ;rȔȓƀhir㊗㊛㊠reåㇸmes;拊iȀ;efl㊪ၙᠡ㊫方tri;槎luhar;楨;愞ൡ㋕㋛㋟㌬㌸㍱\0㍺㎤\0\0㏬㏰\0㐨㑈㑚㒭㒱㓊㓱\0㘖\0\0㘳cute;䅛quï➺Ԁ;Eaceinpsyᇭ㋳㋵㋿㌂㌋㌏㌟㌦㌩;檴ǰ㋺\0㋼;檸on;䅡uåᇾĀ;dᇳ㌇il;䅟rc;䅝ƀEas㌖㌘㌛;檶p;檺im;择olint;樓iíሄ;䑁otƀ;be㌴ᵇ㌵担;橦΀Aacmstx㍆㍊㍗㍛㍞㍣㍭rr;懘rĀhr㍐㍒ë∨Ā;oਸ਼਴t耻§䂧i;䀻war;椩mĀin㍩ðnuóñt;朶rĀ;o㍶⁕쀀𝔰Ȁacoy㎂㎆㎑㎠rp;景Āhy㎋㎏cy;䑉;䑈rtɭ㎙\0\0㎜iäᑤaraì⹯耻­䂭Āgm㎨㎴maƀ;fv㎱㎲㎲䏃;䏂Ѐ;deglnprካ㏅㏉㏎㏖㏞㏡㏦ot;橪Ā;q኱ኰĀ;E㏓㏔檞;檠Ā;E㏛㏜檝;檟e;扆lus;樤arr;楲aròᄽȀaeit㏸㐈㐏㐗Āls㏽㐄lsetmé㍪hp;樳parsl;槤Ādlᑣ㐔e;挣Ā;e㐜㐝檪Ā;s㐢㐣檬;쀀⪬︀ƀflp㐮㐳㑂tcy;䑌Ā;b㐸㐹䀯Ā;a㐾㐿槄r;挿f;쀀𝕤aĀdr㑍ЂesĀ;u㑔㑕晠it»㑕ƀcsu㑠㑹㒟Āau㑥㑯pĀ;sᆈ㑫;쀀⊓︀pĀ;sᆴ㑵;쀀⊔︀uĀbp㑿㒏ƀ;esᆗᆜ㒆etĀ;eᆗ㒍ñᆝƀ;esᆨᆭ㒖etĀ;eᆨ㒝ñᆮƀ;afᅻ㒦ְrť㒫ֱ»ᅼaròᅈȀcemt㒹㒾㓂㓅r;쀀𝓈tmîñiì㐕aræᆾĀar㓎㓕rĀ;f㓔ឿ昆Āan㓚㓭ightĀep㓣㓪psiloîỠhé⺯s»⡒ʀbcmnp㓻㕞ሉ㖋㖎Ҁ;Edemnprs㔎㔏㔑㔕㔞㔣㔬㔱㔶抂;櫅ot;檽Ā;dᇚ㔚ot;櫃ult;櫁ĀEe㔨㔪;櫋;把lus;檿arr;楹ƀeiu㔽㕒㕕tƀ;en㔎㕅㕋qĀ;qᇚ㔏eqĀ;q㔫㔨m;櫇Ābp㕚㕜;櫕;櫓c̀;acensᇭ㕬㕲㕹㕻㌦pproø㋺urlyeñᇾñᇳƀaes㖂㖈㌛pproø㌚qñ㌗g;晪ڀ123;Edehlmnps㖩㖬㖯ሜ㖲㖴㗀㗉㗕㗚㗟㗨㗭耻¹䂹耻²䂲耻³䂳;櫆Āos㖹㖼t;檾ub;櫘Ā;dሢ㗅ot;櫄sĀou㗏㗒l;柉b;櫗arr;楻ult;櫂ĀEe㗤㗦;櫌;抋lus;櫀ƀeiu㗴㘉㘌tƀ;enሜ㗼㘂qĀ;qሢ㖲eqĀ;q㗧㗤m;櫈Ābp㘑㘓;櫔;櫖ƀAan㘜㘠㘭rr;懙rĀhr㘦㘨ë∮Ā;oਫ਩war;椪lig耻ß䃟௡㙑㙝㙠ዎ㙳㙹\0㙾㛂\0\0\0\0\0㛛㜃\0㜉㝬\0\0\0㞇ɲ㙖\0\0㙛get;挖;䏄rë๟ƀaey㙦㙫㙰ron;䅥dil;䅣;䑂lrec;挕r;쀀𝔱Ȁeiko㚆㚝㚵㚼ǲ㚋\0㚑eĀ4fኄኁaƀ;sv㚘㚙㚛䎸ym;䏑Ācn㚢㚲kĀas㚨㚮pproø዁im»ኬsðኞĀas㚺㚮ð዁rn耻þ䃾Ǭ̟㛆⋧es膀×;bd㛏㛐㛘䃗Ā;aᤏ㛕r;樱;樰ƀeps㛡㛣㜀á⩍Ȁ;bcf҆㛬㛰㛴ot;挶ir;櫱Ā;o㛹㛼쀀𝕥rk;櫚á㍢rime;怴ƀaip㜏㜒㝤dåቈ΀adempst㜡㝍㝀㝑㝗㝜㝟ngleʀ;dlqr㜰㜱㜶㝀㝂斵own»ᶻeftĀ;e⠀㜾ñम;扜ightĀ;e㊪㝋ñၚot;旬inus;樺lus;樹b;槍ime;樻ezium;揢ƀcht㝲㝽㞁Āry㝷㝻;쀀𝓉;䑆cy;䑛rok;䅧Āio㞋㞎xô᝷headĀlr㞗㞠eftarro÷ࡏightarrow»ཝऀAHabcdfghlmoprstuw㟐㟓㟗㟤㟰㟼㠎㠜㠣㠴㡑㡝㡫㢩㣌㣒㣪㣶ròϭar;楣Ācr㟜㟢ute耻ú䃺òᅐrǣ㟪\0㟭y;䑞ve;䅭Āiy㟵㟺rc耻û䃻;䑃ƀabh㠃㠆㠋ròᎭlac;䅱aòᏃĀir㠓㠘sht;楾;쀀𝔲rave耻ù䃹š㠧㠱rĀlr㠬㠮»ॗ»ႃlk;斀Āct㠹㡍ɯ㠿\0\0㡊rnĀ;e㡅㡆挜r»㡆op;挏ri;旸Āal㡖㡚cr;䅫肻¨͉Āgp㡢㡦on;䅳f;쀀𝕦̀adhlsuᅋ㡸㡽፲㢑㢠ownáᎳarpoonĀlr㢈㢌efô㠭ighô㠯iƀ;hl㢙㢚㢜䏅»ᏺon»㢚parrows;懈ƀcit㢰㣄㣈ɯ㢶\0\0㣁rnĀ;e㢼㢽挝r»㢽op;挎ng;䅯ri;旹cr;쀀𝓊ƀdir㣙㣝㣢ot;拰lde;䅩iĀ;f㜰㣨»᠓Āam㣯㣲rò㢨l耻ü䃼angle;榧ހABDacdeflnoprsz㤜㤟㤩㤭㦵㦸㦽㧟㧤㧨㧳㧹㧽㨁㨠ròϷarĀ;v㤦㤧櫨;櫩asèϡĀnr㤲㤷grt;榜΀eknprst㓣㥆㥋㥒㥝㥤㦖appá␕othinçẖƀhir㓫⻈㥙opô⾵Ā;hᎷ㥢ïㆍĀiu㥩㥭gmá㎳Ābp㥲㦄setneqĀ;q㥽㦀쀀⊊︀;쀀⫋︀setneqĀ;q㦏㦒쀀⊋︀;쀀⫌︀Āhr㦛㦟etá㚜iangleĀlr㦪㦯eft»थight»ၑy;䐲ash»ံƀelr㧄㧒㧗ƀ;beⷪ㧋㧏ar;抻q;扚lip;拮Ābt㧜ᑨaòᑩr;쀀𝔳tré㦮suĀbp㧯㧱»ജ»൙pf;쀀𝕧roð໻tré㦴Ācu㨆㨋r;쀀𝓋Ābp㨐㨘nĀEe㦀㨖»㥾nĀEe㦒㨞»㦐igzag;榚΀cefoprs㨶㨻㩖㩛㩔㩡㩪irc;䅵Ādi㩀㩑Ābg㩅㩉ar;機eĀ;qᗺ㩏;扙erp;愘r;쀀𝔴pf;쀀𝕨Ā;eᑹ㩦atèᑹcr;쀀𝓌ૣណ㪇\0㪋\0㪐㪛\0\0㪝㪨㪫㪯\0\0㫃㫎\0㫘ៜ៟tré៑r;쀀𝔵ĀAa㪔㪗ròσrò৶;䎾ĀAa㪡㪤ròθrò৫að✓is;拻ƀdptឤ㪵㪾Āfl㪺ឩ;쀀𝕩imåឲĀAa㫇㫊ròώròਁĀcq㫒ីr;쀀𝓍Āpt៖㫜ré។Ѐacefiosu㫰㫽㬈㬌㬑㬕㬛㬡cĀuy㫶㫻te耻ý䃽;䑏Āiy㬂㬆rc;䅷;䑋n耻¥䂥r;쀀𝔶cy;䑗pf;쀀𝕪cr;쀀𝓎Ācm㬦㬩y;䑎l耻ÿ䃿Ԁacdefhiosw㭂㭈㭔㭘㭤㭩㭭㭴㭺㮀cute;䅺Āay㭍㭒ron;䅾;䐷ot;䅼Āet㭝㭡træᕟa;䎶r;쀀𝔷cy;䐶grarr;懝pf;쀀𝕫cr;쀀𝓏Ājn㮅㮇;怍j;怌'.split("").map(function (t) { return t.charCodeAt(0); }));
var Te = new Uint16Array("Ȁaglq	\x1Bɭ\0\0p;䀦os;䀧t;䀾t;䀼uot;䀢".split("").map(function (t) { return t.charCodeAt(0); }));
var tu, ba = new Map([[0, 65533], [128, 8364], [130, 8218], [131, 402], [132, 8222], [133, 8230], [134, 8224], [135, 8225], [136, 710], [137, 8240], [138, 352], [139, 8249], [140, 338], [142, 381], [145, 8216], [146, 8217], [147, 8220], [148, 8221], [149, 8226], [150, 8211], [151, 8212], [152, 732], [153, 8482], [154, 353], [155, 8250], [156, 339], [158, 382], [159, 376]]), Wt = (tu = String.fromCodePoint) !== null && tu !== void 0 ? tu : function (t) { var e = ""; return t > 65535 && (t -= 65536, e += String.fromCharCode(t >>> 10 & 1023 | 55296), t = 56320 | t & 1023), e += String.fromCharCode(t), e; };
function eu(t) { var e; return t >= 55296 && t <= 57343 || t > 1114111 ? 65533 : (e = ba.get(t)) !== null && e !== void 0 ? e : t; }
var et;
(function (t) { t[t.NUM = 35] = "NUM", t[t.SEMI = 59] = "SEMI", t[t.EQUALS = 61] = "EQUALS", t[t.ZERO = 48] = "ZERO", t[t.NINE = 57] = "NINE", t[t.LOWER_A = 97] = "LOWER_A", t[t.LOWER_F = 102] = "LOWER_F", t[t.LOWER_X = 120] = "LOWER_X", t[t.LOWER_Z = 122] = "LOWER_Z", t[t.UPPER_A = 65] = "UPPER_A", t[t.UPPER_F = 70] = "UPPER_F", t[t.UPPER_Z = 90] = "UPPER_Z"; })(et || (et = {}));
var ma = 32, Ot;
(function (t) { t[t.VALUE_LENGTH = 49152] = "VALUE_LENGTH", t[t.BRANCH_LENGTH = 16256] = "BRANCH_LENGTH", t[t.JUMP_TABLE = 127] = "JUMP_TABLE"; })(Ot || (Ot = {}));
function uu(t) { return t >= et.ZERO && t <= et.NINE; }
function xa(t) { return t >= et.UPPER_A && t <= et.UPPER_F || t >= et.LOWER_A && t <= et.LOWER_F; }
function ya(t) { return t >= et.UPPER_A && t <= et.UPPER_Z || t >= et.LOWER_A && t <= et.LOWER_Z || uu(t); }
function va(t) { return t === et.EQUALS || ya(t); }
var tt;
(function (t) { t[t.EntityStart = 0] = "EntityStart", t[t.NumericStart = 1] = "NumericStart", t[t.NumericDecimal = 2] = "NumericDecimal", t[t.NumericHex = 3] = "NumericHex", t[t.NamedEntity = 4] = "NamedEntity"; })(tt || (tt = {}));
var mt;
(function (t) { t[t.Legacy = 0] = "Legacy", t[t.Strict = 1] = "Strict", t[t.Attribute = 2] = "Attribute"; })(mt || (mt = {}));
var Xt = (function () {
    function Xt(e, a, n) {
        this.decodeTree = e, this.emitCodePoint = a, this.errors = n, this.state = tt.EntityStart, this.consumed = 1, this.result = 0, this.treeIndex = 0, this.excess = 1, this.decodeMode = mt.Strict;
    }
    Xt.prototype.startEntity = function (e) { this.decodeMode = e, this.state = tt.EntityStart, this.result = 0, this.treeIndex = 0, this.excess = 1, this.consumed = 1; };
    Xt.prototype.write = function (e, a) { switch (this.state) {
        case tt.EntityStart: return e.charCodeAt(a) === et.NUM ? (this.state = tt.NumericStart, this.consumed += 1, this.stateNumericStart(e, a + 1)) : (this.state = tt.NamedEntity, this.stateNamedEntity(e, a));
        case tt.NumericStart: return this.stateNumericStart(e, a);
        case tt.NumericDecimal: return this.stateNumericDecimal(e, a);
        case tt.NumericHex: return this.stateNumericHex(e, a);
        case tt.NamedEntity: return this.stateNamedEntity(e, a);
    } };
    Xt.prototype.stateNumericStart = function (e, a) { return a >= e.length ? -1 : (e.charCodeAt(a) | ma) === et.LOWER_X ? (this.state = tt.NumericHex, this.consumed += 1, this.stateNumericHex(e, a + 1)) : (this.state = tt.NumericDecimal, this.stateNumericDecimal(e, a)); };
    Xt.prototype.addToNumericResult = function (e, a, n, s) { if (a !== n) {
        var o = n - a;
        this.result = this.result * Math.pow(s, o) + parseInt(e.substr(a, o), s), this.consumed += o;
    } };
    Xt.prototype.stateNumericHex = function (e, a) { var n = a; for (; a < e.length;) {
        var s = e.charCodeAt(a);
        if (uu(s) || xa(s))
            a += 1;
        else
            return this.addToNumericResult(e, n, a, 16), this.emitNumericEntity(s, 3);
    } return this.addToNumericResult(e, n, a, 16), -1; };
    Xt.prototype.stateNumericDecimal = function (e, a) { var n = a; for (; a < e.length;) {
        var s = e.charCodeAt(a);
        if (uu(s))
            a += 1;
        else
            return this.addToNumericResult(e, n, a, 10), this.emitNumericEntity(s, 2);
    } return this.addToNumericResult(e, n, a, 10), -1; };
    Xt.prototype.emitNumericEntity = function (e, a) { var n; if (this.consumed <= a)
        return (n = this.errors) === null || n === void 0 || n.absenceOfDigitsInNumericCharacterReference(this.consumed), 0; if (e === et.SEMI)
        this.consumed += 1;
    else if (this.decodeMode === mt.Strict)
        return 0; return this.emitCodePoint(eu(this.result), this.consumed), this.errors && (e !== et.SEMI && this.errors.missingSemicolonAfterCharacterReference(), this.errors.validateNumericCharacterReference(this.result)), this.consumed; };
    Xt.prototype.stateNamedEntity = function (e, a) { var n = this.decodeTree, s = n[this.treeIndex], o = (s & Ot.VALUE_LENGTH) >> 14; for (; a < e.length; a++, this.excess++) {
        var f = e.charCodeAt(a);
        if (this.treeIndex = wa(n, s, this.treeIndex + Math.max(1, o), f), this.treeIndex < 0)
            return this.result === 0 || this.decodeMode === mt.Attribute && (o === 0 || va(f)) ? 0 : this.emitNotTerminatedNamedEntity();
        if (s = n[this.treeIndex], o = (s & Ot.VALUE_LENGTH) >> 14, o !== 0) {
            if (f === et.SEMI)
                return this.emitNamedEntityData(this.treeIndex, o, this.consumed + this.excess);
            this.decodeMode !== mt.Strict && (this.result = this.treeIndex, this.consumed += this.excess, this.excess = 0);
        }
    } return -1; };
    Xt.prototype.emitNotTerminatedNamedEntity = function () { var e; var _b = this, a = _b.result, n = _b.decodeTree, s = (n[a] & Ot.VALUE_LENGTH) >> 14; return this.emitNamedEntityData(a, s, this.consumed), (e = this.errors) === null || e === void 0 || e.missingSemicolonAfterCharacterReference(), this.consumed; };
    Xt.prototype.emitNamedEntityData = function (e, a, n) { var s = this.decodeTree; return this.emitCodePoint(a === 1 ? s[e] & ~Ot.VALUE_LENGTH : s[e + 1], n), a === 3 && this.emitCodePoint(s[e + 2], n), n; };
    Xt.prototype.end = function () { var e; switch (this.state) {
        case tt.NamedEntity: return this.result !== 0 && (this.decodeMode !== mt.Attribute || this.result === this.treeIndex) ? this.emitNotTerminatedNamedEntity() : 0;
        case tt.NumericDecimal: return this.emitNumericEntity(0, 2);
        case tt.NumericHex: return this.emitNumericEntity(0, 3);
        case tt.NumericStart: return (e = this.errors) === null || e === void 0 || e.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
        case tt.EntityStart: return 0;
    } };
    return Xt;
}());
function er(t) { var e = "", a = new Xt(t, function (n) { return e += Wt(n); }); return function (s, o) { var f = 0, h = 0; for (; (h = s.indexOf("&", h)) >= 0;) {
    e += s.slice(f, h), a.startEntity(o);
    var m = a.write(s, h + 1);
    if (m < 0) {
        f = h + a.end();
        break;
    }
    f = h + m, h = m === 0 ? f + 1 : f;
} var p = e + s.slice(f); return e = "", p; }; }
function wa(t, e, a, n) { var s = (e & Ot.BRANCH_LENGTH) >> 7, o = e & Ot.JUMP_TABLE; if (s === 0)
    return o !== 0 && n === o ? a : -1; if (o) {
    var p = n - o;
    return p < 0 || p >= s ? -1 : t[a + p] - 1;
} var f = a, h = f + s - 1; for (; f <= h;) {
    var p = f + h >>> 1, m = t[p];
    if (m < n)
        f = p + 1;
    else if (m > n)
        h = p - 1;
    else
        return t[p + s];
} return -1; }
var Xn = er(Se), Jn = er(Te);
var N;
(function (t) { t[t.Tab = 9] = "Tab", t[t.NewLine = 10] = "NewLine", t[t.FormFeed = 12] = "FormFeed", t[t.CarriageReturn = 13] = "CarriageReturn", t[t.Space = 32] = "Space", t[t.ExclamationMark = 33] = "ExclamationMark", t[t.Number = 35] = "Number", t[t.Amp = 38] = "Amp", t[t.SingleQuote = 39] = "SingleQuote", t[t.DoubleQuote = 34] = "DoubleQuote", t[t.Dash = 45] = "Dash", t[t.Slash = 47] = "Slash", t[t.Zero = 48] = "Zero", t[t.Nine = 57] = "Nine", t[t.Semi = 59] = "Semi", t[t.Lt = 60] = "Lt", t[t.Eq = 61] = "Eq", t[t.Gt = 62] = "Gt", t[t.Questionmark = 63] = "Questionmark", t[t.UpperA = 65] = "UpperA", t[t.LowerA = 97] = "LowerA", t[t.UpperF = 70] = "UpperF", t[t.LowerF = 102] = "LowerF", t[t.UpperZ = 90] = "UpperZ", t[t.LowerZ = 122] = "LowerZ", t[t.LowerX = 120] = "LowerX", t[t.OpeningSquareBracket = 91] = "OpeningSquareBracket"; })(N || (N = {}));
var y;
(function (t) { t[t.Text = 1] = "Text", t[t.BeforeTagName = 2] = "BeforeTagName", t[t.InTagName = 3] = "InTagName", t[t.InSelfClosingTag = 4] = "InSelfClosingTag", t[t.BeforeClosingTagName = 5] = "BeforeClosingTagName", t[t.InClosingTagName = 6] = "InClosingTagName", t[t.AfterClosingTagName = 7] = "AfterClosingTagName", t[t.BeforeAttributeName = 8] = "BeforeAttributeName", t[t.InAttributeName = 9] = "InAttributeName", t[t.AfterAttributeName = 10] = "AfterAttributeName", t[t.BeforeAttributeValue = 11] = "BeforeAttributeValue", t[t.InAttributeValueDq = 12] = "InAttributeValueDq", t[t.InAttributeValueSq = 13] = "InAttributeValueSq", t[t.InAttributeValueNq = 14] = "InAttributeValueNq", t[t.BeforeDeclaration = 15] = "BeforeDeclaration", t[t.InDeclaration = 16] = "InDeclaration", t[t.InProcessingInstruction = 17] = "InProcessingInstruction", t[t.BeforeComment = 18] = "BeforeComment", t[t.CDATASequence = 19] = "CDATASequence", t[t.InSpecialComment = 20] = "InSpecialComment", t[t.InCommentLike = 21] = "InCommentLike", t[t.BeforeSpecialS = 22] = "BeforeSpecialS", t[t.BeforeSpecialT = 23] = "BeforeSpecialT", t[t.SpecialStartSequence = 24] = "SpecialStartSequence", t[t.InSpecialTag = 25] = "InSpecialTag", t[t.InEntity = 26] = "InEntity"; })(y || (y = {}));
function Et(t) { return t === N.Space || t === N.NewLine || t === N.Tab || t === N.FormFeed || t === N.CarriageReturn; }
function Ae(t) { return t === N.Slash || t === N.Gt || Et(t); }
function Sa(t) { return t >= N.LowerA && t <= N.LowerZ || t >= N.UpperA && t <= N.UpperZ; }
var xt;
(function (t) { t[t.NoValue = 0] = "NoValue", t[t.Unquoted = 1] = "Unquoted", t[t.Single = 2] = "Single", t[t.Double = 3] = "Double"; })(xt || (xt = {}));
var at = { Cdata: new Uint8Array([67, 68, 65, 84, 65, 91]), CdataEnd: new Uint8Array([93, 93, 62]), CommentEnd: new Uint8Array([45, 45, 62]), ScriptEnd: new Uint8Array([60, 47, 115, 99, 114, 105, 112, 116]), StyleEnd: new Uint8Array([60, 47, 115, 116, 121, 108, 101]), TitleEnd: new Uint8Array([60, 47, 116, 105, 116, 108, 101]), TextareaEnd: new Uint8Array([60, 47, 116, 101, 120, 116, 97, 114, 101, 97]) }, Jt = (function () {
    function Jt(_b, n) {
        var _c = _b.xmlMode, e = _c === void 0 ? !1 : _c, _d = _b.decodeEntities, a = _d === void 0 ? !0 : _d;
        var _this = this;
        this.cbs = n, this.state = y.Text, this.buffer = "", this.sectionStart = 0, this.index = 0, this.entityStart = 0, this.baseState = y.Text, this.isSpecial = !1, this.running = !0, this.offset = 0, this.currentSequence = void 0, this.sequenceIndex = 0, this.xmlMode = e, this.decodeEntities = a, this.entityDecoder = new Xt(e ? Te : Se, function (s, o) { return _this.emitCodePoint(s, o); });
    }
    Jt.prototype.reset = function () { this.state = y.Text, this.buffer = "", this.sectionStart = 0, this.index = 0, this.baseState = y.Text, this.currentSequence = void 0, this.running = !0, this.offset = 0; };
    Jt.prototype.write = function (e) { this.offset += this.buffer.length, this.buffer = e, this.parse(); };
    Jt.prototype.end = function () { this.running && this.finish(); };
    Jt.prototype.pause = function () { this.running = !1; };
    Jt.prototype.resume = function () { this.running = !0, this.index < this.buffer.length + this.offset && this.parse(); };
    Jt.prototype.stateText = function (e) { e === N.Lt || !this.decodeEntities && this.fastForwardTo(N.Lt) ? (this.index > this.sectionStart && this.cbs.ontext(this.sectionStart, this.index), this.state = y.BeforeTagName, this.sectionStart = this.index) : this.decodeEntities && e === N.Amp && this.startEntity(); };
    Jt.prototype.stateSpecialStartSequence = function (e) { var a = this.sequenceIndex === this.currentSequence.length; if (!(a ? Ae(e) : (e | 32) === this.currentSequence[this.sequenceIndex]))
        this.isSpecial = !1;
    else if (!a) {
        this.sequenceIndex++;
        return;
    } this.sequenceIndex = 0, this.state = y.InTagName, this.stateInTagName(e); };
    Jt.prototype.stateInSpecialTag = function (e) { if (this.sequenceIndex === this.currentSequence.length) {
        if (e === N.Gt || Et(e)) {
            var a = this.index - this.currentSequence.length;
            if (this.sectionStart < a) {
                var n = this.index;
                this.index = a, this.cbs.ontext(this.sectionStart, a), this.index = n;
            }
            this.isSpecial = !1, this.sectionStart = a + 2, this.stateInClosingTagName(e);
            return;
        }
        this.sequenceIndex = 0;
    } (e | 32) === this.currentSequence[this.sequenceIndex] ? this.sequenceIndex += 1 : this.sequenceIndex === 0 ? this.currentSequence === at.TitleEnd ? this.decodeEntities && e === N.Amp && this.startEntity() : this.fastForwardTo(N.Lt) && (this.sequenceIndex = 1) : this.sequenceIndex = +(e === N.Lt); };
    Jt.prototype.stateCDATASequence = function (e) { e === at.Cdata[this.sequenceIndex] ? ++this.sequenceIndex === at.Cdata.length && (this.state = y.InCommentLike, this.currentSequence = at.CdataEnd, this.sequenceIndex = 0, this.sectionStart = this.index + 1) : (this.sequenceIndex = 0, this.state = y.InDeclaration, this.stateInDeclaration(e)); };
    Jt.prototype.fastForwardTo = function (e) { for (; ++this.index < this.buffer.length + this.offset;)
        if (this.buffer.charCodeAt(this.index - this.offset) === e)
            return !0; return this.index = this.buffer.length + this.offset - 1, !1; };
    Jt.prototype.stateInCommentLike = function (e) { e === this.currentSequence[this.sequenceIndex] ? ++this.sequenceIndex === this.currentSequence.length && (this.currentSequence === at.CdataEnd ? this.cbs.oncdata(this.sectionStart, this.index, 2) : this.cbs.oncomment(this.sectionStart, this.index, 2), this.sequenceIndex = 0, this.sectionStart = this.index + 1, this.state = y.Text) : this.sequenceIndex === 0 ? this.fastForwardTo(this.currentSequence[0]) && (this.sequenceIndex = 1) : e !== this.currentSequence[this.sequenceIndex - 1] && (this.sequenceIndex = 0); };
    Jt.prototype.isTagStartChar = function (e) { return this.xmlMode ? !Ae(e) : Sa(e); };
    Jt.prototype.startSpecial = function (e, a) { this.isSpecial = !0, this.currentSequence = e, this.sequenceIndex = a, this.state = y.SpecialStartSequence; };
    Jt.prototype.stateBeforeTagName = function (e) { if (e === N.ExclamationMark)
        this.state = y.BeforeDeclaration, this.sectionStart = this.index + 1;
    else if (e === N.Questionmark)
        this.state = y.InProcessingInstruction, this.sectionStart = this.index + 1;
    else if (this.isTagStartChar(e)) {
        var a = e | 32;
        this.sectionStart = this.index, this.xmlMode ? this.state = y.InTagName : a === at.ScriptEnd[2] ? this.state = y.BeforeSpecialS : a === at.TitleEnd[2] ? this.state = y.BeforeSpecialT : this.state = y.InTagName;
    }
    else
        e === N.Slash ? this.state = y.BeforeClosingTagName : (this.state = y.Text, this.stateText(e)); };
    Jt.prototype.stateInTagName = function (e) { Ae(e) && (this.cbs.onopentagname(this.sectionStart, this.index), this.sectionStart = -1, this.state = y.BeforeAttributeName, this.stateBeforeAttributeName(e)); };
    Jt.prototype.stateBeforeClosingTagName = function (e) { Et(e) || (e === N.Gt ? this.state = y.Text : (this.state = this.isTagStartChar(e) ? y.InClosingTagName : y.InSpecialComment, this.sectionStart = this.index)); };
    Jt.prototype.stateInClosingTagName = function (e) { (e === N.Gt || Et(e)) && (this.cbs.onclosetag(this.sectionStart, this.index), this.sectionStart = -1, this.state = y.AfterClosingTagName, this.stateAfterClosingTagName(e)); };
    Jt.prototype.stateAfterClosingTagName = function (e) { (e === N.Gt || this.fastForwardTo(N.Gt)) && (this.state = y.Text, this.sectionStart = this.index + 1); };
    Jt.prototype.stateBeforeAttributeName = function (e) { e === N.Gt ? (this.cbs.onopentagend(this.index), this.isSpecial ? (this.state = y.InSpecialTag, this.sequenceIndex = 0) : this.state = y.Text, this.sectionStart = this.index + 1) : e === N.Slash ? this.state = y.InSelfClosingTag : Et(e) || (this.state = y.InAttributeName, this.sectionStart = this.index); };
    Jt.prototype.stateInSelfClosingTag = function (e) { e === N.Gt ? (this.cbs.onselfclosingtag(this.index), this.state = y.Text, this.sectionStart = this.index + 1, this.isSpecial = !1) : Et(e) || (this.state = y.BeforeAttributeName, this.stateBeforeAttributeName(e)); };
    Jt.prototype.stateInAttributeName = function (e) { (e === N.Eq || Ae(e)) && (this.cbs.onattribname(this.sectionStart, this.index), this.sectionStart = this.index, this.state = y.AfterAttributeName, this.stateAfterAttributeName(e)); };
    Jt.prototype.stateAfterAttributeName = function (e) { e === N.Eq ? this.state = y.BeforeAttributeValue : e === N.Slash || e === N.Gt ? (this.cbs.onattribend(xt.NoValue, this.sectionStart), this.sectionStart = -1, this.state = y.BeforeAttributeName, this.stateBeforeAttributeName(e)) : Et(e) || (this.cbs.onattribend(xt.NoValue, this.sectionStart), this.state = y.InAttributeName, this.sectionStart = this.index); };
    Jt.prototype.stateBeforeAttributeValue = function (e) { e === N.DoubleQuote ? (this.state = y.InAttributeValueDq, this.sectionStart = this.index + 1) : e === N.SingleQuote ? (this.state = y.InAttributeValueSq, this.sectionStart = this.index + 1) : Et(e) || (this.sectionStart = this.index, this.state = y.InAttributeValueNq, this.stateInAttributeValueNoQuotes(e)); };
    Jt.prototype.handleInAttributeValue = function (e, a) { e === a || !this.decodeEntities && this.fastForwardTo(a) ? (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(a === N.DoubleQuote ? xt.Double : xt.Single, this.index + 1), this.state = y.BeforeAttributeName) : this.decodeEntities && e === N.Amp && this.startEntity(); };
    Jt.prototype.stateInAttributeValueDoubleQuotes = function (e) { this.handleInAttributeValue(e, N.DoubleQuote); };
    Jt.prototype.stateInAttributeValueSingleQuotes = function (e) { this.handleInAttributeValue(e, N.SingleQuote); };
    Jt.prototype.stateInAttributeValueNoQuotes = function (e) { Et(e) || e === N.Gt ? (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(xt.Unquoted, this.index), this.state = y.BeforeAttributeName, this.stateBeforeAttributeName(e)) : this.decodeEntities && e === N.Amp && this.startEntity(); };
    Jt.prototype.stateBeforeDeclaration = function (e) { e === N.OpeningSquareBracket ? (this.state = y.CDATASequence, this.sequenceIndex = 0) : this.state = e === N.Dash ? y.BeforeComment : y.InDeclaration; };
    Jt.prototype.stateInDeclaration = function (e) { (e === N.Gt || this.fastForwardTo(N.Gt)) && (this.cbs.ondeclaration(this.sectionStart, this.index), this.state = y.Text, this.sectionStart = this.index + 1); };
    Jt.prototype.stateInProcessingInstruction = function (e) { (e === N.Gt || this.fastForwardTo(N.Gt)) && (this.cbs.onprocessinginstruction(this.sectionStart, this.index), this.state = y.Text, this.sectionStart = this.index + 1); };
    Jt.prototype.stateBeforeComment = function (e) { e === N.Dash ? (this.state = y.InCommentLike, this.currentSequence = at.CommentEnd, this.sequenceIndex = 2, this.sectionStart = this.index + 1) : this.state = y.InDeclaration; };
    Jt.prototype.stateInSpecialComment = function (e) { (e === N.Gt || this.fastForwardTo(N.Gt)) && (this.cbs.oncomment(this.sectionStart, this.index, 0), this.state = y.Text, this.sectionStart = this.index + 1); };
    Jt.prototype.stateBeforeSpecialS = function (e) { var a = e | 32; a === at.ScriptEnd[3] ? this.startSpecial(at.ScriptEnd, 4) : a === at.StyleEnd[3] ? this.startSpecial(at.StyleEnd, 4) : (this.state = y.InTagName, this.stateInTagName(e)); };
    Jt.prototype.stateBeforeSpecialT = function (e) { var a = e | 32; a === at.TitleEnd[3] ? this.startSpecial(at.TitleEnd, 4) : a === at.TextareaEnd[3] ? this.startSpecial(at.TextareaEnd, 4) : (this.state = y.InTagName, this.stateInTagName(e)); };
    Jt.prototype.startEntity = function () { this.baseState = this.state, this.state = y.InEntity, this.entityStart = this.index, this.entityDecoder.startEntity(this.xmlMode ? mt.Strict : this.baseState === y.Text || this.baseState === y.InSpecialTag ? mt.Legacy : mt.Attribute); };
    Jt.prototype.stateInEntity = function () { var e = this.entityDecoder.write(this.buffer, this.index - this.offset); e >= 0 ? (this.state = this.baseState, e === 0 && (this.index = this.entityStart)) : this.index = this.offset + this.buffer.length - 1; };
    Jt.prototype.cleanup = function () { this.running && this.sectionStart !== this.index && (this.state === y.Text || this.state === y.InSpecialTag && this.sequenceIndex === 0 ? (this.cbs.ontext(this.sectionStart, this.index), this.sectionStart = this.index) : (this.state === y.InAttributeValueDq || this.state === y.InAttributeValueSq || this.state === y.InAttributeValueNq) && (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = this.index)); };
    Jt.prototype.shouldContinue = function () { return this.index < this.buffer.length + this.offset && this.running; };
    Jt.prototype.parse = function () { for (; this.shouldContinue();) {
        var e = this.buffer.charCodeAt(this.index - this.offset);
        switch (this.state) {
            case y.Text: {
                this.stateText(e);
                break;
            }
            case y.SpecialStartSequence: {
                this.stateSpecialStartSequence(e);
                break;
            }
            case y.InSpecialTag: {
                this.stateInSpecialTag(e);
                break;
            }
            case y.CDATASequence: {
                this.stateCDATASequence(e);
                break;
            }
            case y.InAttributeValueDq: {
                this.stateInAttributeValueDoubleQuotes(e);
                break;
            }
            case y.InAttributeName: {
                this.stateInAttributeName(e);
                break;
            }
            case y.InCommentLike: {
                this.stateInCommentLike(e);
                break;
            }
            case y.InSpecialComment: {
                this.stateInSpecialComment(e);
                break;
            }
            case y.BeforeAttributeName: {
                this.stateBeforeAttributeName(e);
                break;
            }
            case y.InTagName: {
                this.stateInTagName(e);
                break;
            }
            case y.InClosingTagName: {
                this.stateInClosingTagName(e);
                break;
            }
            case y.BeforeTagName: {
                this.stateBeforeTagName(e);
                break;
            }
            case y.AfterAttributeName: {
                this.stateAfterAttributeName(e);
                break;
            }
            case y.InAttributeValueSq: {
                this.stateInAttributeValueSingleQuotes(e);
                break;
            }
            case y.BeforeAttributeValue: {
                this.stateBeforeAttributeValue(e);
                break;
            }
            case y.BeforeClosingTagName: {
                this.stateBeforeClosingTagName(e);
                break;
            }
            case y.AfterClosingTagName: {
                this.stateAfterClosingTagName(e);
                break;
            }
            case y.BeforeSpecialS: {
                this.stateBeforeSpecialS(e);
                break;
            }
            case y.BeforeSpecialT: {
                this.stateBeforeSpecialT(e);
                break;
            }
            case y.InAttributeValueNq: {
                this.stateInAttributeValueNoQuotes(e);
                break;
            }
            case y.InSelfClosingTag: {
                this.stateInSelfClosingTag(e);
                break;
            }
            case y.InDeclaration: {
                this.stateInDeclaration(e);
                break;
            }
            case y.BeforeDeclaration: {
                this.stateBeforeDeclaration(e);
                break;
            }
            case y.BeforeComment: {
                this.stateBeforeComment(e);
                break;
            }
            case y.InProcessingInstruction: {
                this.stateInProcessingInstruction(e);
                break;
            }
            case y.InEntity: {
                this.stateInEntity();
                break;
            }
        }
        this.index++;
    } this.cleanup(); };
    Jt.prototype.finish = function () { this.state === y.InEntity && (this.entityDecoder.end(), this.state = this.baseState), this.handleTrailingData(), this.cbs.onend(); };
    Jt.prototype.handleTrailingData = function () { var e = this.buffer.length + this.offset; this.sectionStart >= e || (this.state === y.InCommentLike ? this.currentSequence === at.CdataEnd ? this.cbs.oncdata(this.sectionStart, e, 0) : this.cbs.oncomment(this.sectionStart, e, 0) : this.state === y.InTagName || this.state === y.BeforeAttributeName || this.state === y.BeforeAttributeValue || this.state === y.AfterAttributeName || this.state === y.InAttributeName || this.state === y.InAttributeValueSq || this.state === y.InAttributeValueDq || this.state === y.InAttributeValueNq || this.state === y.InClosingTagName || this.cbs.ontext(this.sectionStart, e)); };
    Jt.prototype.emitCodePoint = function (e, a) { this.baseState !== y.Text && this.baseState !== y.InSpecialTag ? (this.sectionStart < this.entityStart && this.cbs.onattribdata(this.sectionStart, this.entityStart), this.sectionStart = this.entityStart + a, this.index = this.sectionStart - 1, this.cbs.onattribentity(e)) : (this.sectionStart < this.entityStart && this.cbs.ontext(this.sectionStart, this.entityStart), this.sectionStart = this.entityStart + a, this.index = this.sectionStart - 1, this.cbs.ontextentity(e, this.sectionStart)); };
    return Jt;
}());
var Zt = new Set(["input", "option", "optgroup", "select", "button", "datalist", "textarea"]), B = new Set(["p"]), ur = new Set(["thead", "tbody"]), rr = new Set(["dd", "dt"]), ar = new Set(["rt", "rp"]), Ta = new Map([["tr", new Set(["tr", "th", "td"])], ["th", new Set(["th"])], ["td", new Set(["thead", "th", "td"])], ["body", new Set(["head", "link", "script"])], ["li", new Set(["li"])], ["p", B], ["h1", B], ["h2", B], ["h3", B], ["h4", B], ["h5", B], ["h6", B], ["select", Zt], ["input", Zt], ["output", Zt], ["button", Zt], ["datalist", Zt], ["textarea", Zt], ["option", new Set(["option"])], ["optgroup", new Set(["optgroup", "option"])], ["dd", rr], ["dt", rr], ["address", B], ["article", B], ["aside", B], ["blockquote", B], ["details", B], ["div", B], ["dl", B], ["fieldset", B], ["figcaption", B], ["figure", B], ["footer", B], ["form", B], ["header", B], ["hr", B], ["main", B], ["nav", B], ["ol", B], ["pre", B], ["section", B], ["table", B], ["ul", B], ["rt", ar], ["rp", ar], ["tbody", ur], ["tfoot", ur]]), Aa = new Set(["area", "base", "basefont", "br", "col", "command", "embed", "frame", "hr", "img", "input", "isindex", "keygen", "link", "meta", "param", "source", "track", "wbr"]), nr = new Set(["math", "svg"]), ir = new Set(["mi", "mo", "mn", "ms", "mtext", "annotation-xml", "foreignobject", "desc", "title"]), Ea = /\s|\//, ce = (function () {
    function ce(e, a) {
        if (a === void 0) { a = {}; }
        var n, s, o, f, h, p;
        this.options = a, this.startIndex = 0, this.endIndex = 0, this.openTagStart = 0, this.tagname = "", this.attribname = "", this.attribvalue = "", this.attribs = null, this.stack = [], this.buffers = [], this.bufferOffset = 0, this.writeIndex = 0, this.ended = !1, this.cbs = e != null ? e : {}, this.htmlMode = !this.options.xmlMode, this.lowerCaseTagNames = (n = a.lowerCaseTags) !== null && n !== void 0 ? n : this.htmlMode, this.lowerCaseAttributeNames = (s = a.lowerCaseAttributeNames) !== null && s !== void 0 ? s : this.htmlMode, this.recognizeSelfClosing = (o = a.recognizeSelfClosing) !== null && o !== void 0 ? o : !this.htmlMode, this.tokenizer = new ((f = a.Tokenizer) !== null && f !== void 0 ? f : Jt)(this.options, this), this.foreignContext = [!this.htmlMode], (p = (h = this.cbs).onparserinit) === null || p === void 0 || p.call(h, this);
    }
    ce.prototype.ontext = function (e, a) { var n, s; var o = this.getSlice(e, a); this.endIndex = a - 1, (s = (n = this.cbs).ontext) === null || s === void 0 || s.call(n, o), this.startIndex = a; };
    ce.prototype.ontextentity = function (e, a) { var n, s; this.endIndex = a - 1, (s = (n = this.cbs).ontext) === null || s === void 0 || s.call(n, Wt(e)), this.startIndex = a; };
    ce.prototype.isVoidElement = function (e) { return this.htmlMode && Aa.has(e); };
    ce.prototype.onopentagname = function (e, a) { this.endIndex = a; var n = this.getSlice(e, a); this.lowerCaseTagNames && (n = n.toLowerCase()), this.emitOpenTag(n); };
    ce.prototype.emitOpenTag = function (e) { var a, n, s, o; this.openTagStart = this.startIndex, this.tagname = e; var f = this.htmlMode && Ta.get(e); if (f)
        for (; this.stack.length > 0 && f.has(this.stack[0]);) {
            var h = this.stack.shift();
            (n = (a = this.cbs).onclosetag) === null || n === void 0 || n.call(a, h, !0);
        } this.isVoidElement(e) || (this.stack.unshift(e), this.htmlMode && (nr.has(e) ? this.foreignContext.unshift(!0) : ir.has(e) && this.foreignContext.unshift(!1))), (o = (s = this.cbs).onopentagname) === null || o === void 0 || o.call(s, e), this.cbs.onopentag && (this.attribs = {}); };
    ce.prototype.endOpenTag = function (e) { var a, n; this.startIndex = this.openTagStart, this.attribs && ((n = (a = this.cbs).onopentag) === null || n === void 0 || n.call(a, this.tagname, this.attribs, e), this.attribs = null), this.cbs.onclosetag && this.isVoidElement(this.tagname) && this.cbs.onclosetag(this.tagname, !0), this.tagname = ""; };
    ce.prototype.onopentagend = function (e) { this.endIndex = e, this.endOpenTag(!1), this.startIndex = e + 1; };
    ce.prototype.onclosetag = function (e, a) { var n, s, o, f, h, p, m, v; this.endIndex = a; var k = this.getSlice(e, a); if (this.lowerCaseTagNames && (k = k.toLowerCase()), this.htmlMode && (nr.has(k) || ir.has(k)) && this.foreignContext.shift(), this.isVoidElement(k))
        this.htmlMode && k === "br" && ((f = (o = this.cbs).onopentagname) === null || f === void 0 || f.call(o, "br"), (p = (h = this.cbs).onopentag) === null || p === void 0 || p.call(h, "br", {}, !0), (v = (m = this.cbs).onclosetag) === null || v === void 0 || v.call(m, "br", !1));
    else {
        var T = this.stack.indexOf(k);
        if (T !== -1)
            for (var A = 0; A <= T; A++) {
                var L = this.stack.shift();
                (s = (n = this.cbs).onclosetag) === null || s === void 0 || s.call(n, L, A !== T);
            }
        else
            this.htmlMode && k === "p" && (this.emitOpenTag("p"), this.closeCurrentTag(!0));
    } this.startIndex = a + 1; };
    ce.prototype.onselfclosingtag = function (e) { this.endIndex = e, this.recognizeSelfClosing || this.foreignContext[0] ? (this.closeCurrentTag(!1), this.startIndex = e + 1) : this.onopentagend(e); };
    ce.prototype.closeCurrentTag = function (e) { var a, n; var s = this.tagname; this.endOpenTag(e), this.stack[0] === s && ((n = (a = this.cbs).onclosetag) === null || n === void 0 || n.call(a, s, !e), this.stack.shift()); };
    ce.prototype.onattribname = function (e, a) { this.startIndex = e; var n = this.getSlice(e, a); this.attribname = this.lowerCaseAttributeNames ? n.toLowerCase() : n; };
    ce.prototype.onattribdata = function (e, a) { this.attribvalue += this.getSlice(e, a); };
    ce.prototype.onattribentity = function (e) { this.attribvalue += Wt(e); };
    ce.prototype.onattribend = function (e, a) { var n, s; this.endIndex = a, (s = (n = this.cbs).onattribute) === null || s === void 0 || s.call(n, this.attribname, this.attribvalue, e === xt.Double ? '"' : e === xt.Single ? "'" : e === xt.NoValue ? void 0 : null), this.attribs && !Object.prototype.hasOwnProperty.call(this.attribs, this.attribname) && (this.attribs[this.attribname] = this.attribvalue), this.attribvalue = ""; };
    ce.prototype.getInstructionName = function (e) { var a = e.search(Ea), n = a < 0 ? e : e.substr(0, a); return this.lowerCaseTagNames && (n = n.toLowerCase()), n; };
    ce.prototype.ondeclaration = function (e, a) { this.endIndex = a; var n = this.getSlice(e, a); if (this.cbs.onprocessinginstruction) {
        var s = this.getInstructionName(n);
        this.cbs.onprocessinginstruction("!".concat(s), "!".concat(n));
    } this.startIndex = a + 1; };
    ce.prototype.onprocessinginstruction = function (e, a) { this.endIndex = a; var n = this.getSlice(e, a); if (this.cbs.onprocessinginstruction) {
        var s = this.getInstructionName(n);
        this.cbs.onprocessinginstruction("?".concat(s), "?".concat(n));
    } this.startIndex = a + 1; };
    ce.prototype.oncomment = function (e, a, n) { var s, o, f, h; this.endIndex = a, (o = (s = this.cbs).oncomment) === null || o === void 0 || o.call(s, this.getSlice(e, a - n)), (h = (f = this.cbs).oncommentend) === null || h === void 0 || h.call(f), this.startIndex = a + 1; };
    ce.prototype.oncdata = function (e, a, n) { var s, o, f, h, p, m, v, k, T, A; this.endIndex = a; var L = this.getSlice(e, a - n); !this.htmlMode || this.options.recognizeCDATA ? ((o = (s = this.cbs).oncdatastart) === null || o === void 0 || o.call(s), (h = (f = this.cbs).ontext) === null || h === void 0 || h.call(f, L), (m = (p = this.cbs).oncdataend) === null || m === void 0 || m.call(p)) : ((k = (v = this.cbs).oncomment) === null || k === void 0 || k.call(v, "[CDATA[".concat(L, "]]")), (A = (T = this.cbs).oncommentend) === null || A === void 0 || A.call(T)), this.startIndex = a + 1; };
    ce.prototype.onend = function () { var e, a; if (this.cbs.onclosetag) {
        this.endIndex = this.startIndex;
        for (var n = 0; n < this.stack.length; n++)
            this.cbs.onclosetag(this.stack[n], !0);
    } (a = (e = this.cbs).onend) === null || a === void 0 || a.call(e); };
    ce.prototype.reset = function () { var e, a, n, s; (a = (e = this.cbs).onreset) === null || a === void 0 || a.call(e), this.tokenizer.reset(), this.tagname = "", this.attribname = "", this.attribs = null, this.stack.length = 0, this.startIndex = 0, this.endIndex = 0, (s = (n = this.cbs).onparserinit) === null || s === void 0 || s.call(n, this), this.buffers.length = 0, this.foreignContext.length = 0, this.foreignContext.unshift(!this.htmlMode), this.bufferOffset = 0, this.writeIndex = 0, this.ended = !1; };
    ce.prototype.parseComplete = function (e) { this.reset(), this.end(e); };
    ce.prototype.getSlice = function (e, a) { for (; e - this.bufferOffset >= this.buffers[0].length;)
        this.shiftBuffer(); var n = this.buffers[0].slice(e - this.bufferOffset, a - this.bufferOffset); for (; a - this.bufferOffset > this.buffers[0].length;)
        this.shiftBuffer(), n += this.buffers[0].slice(0, a - this.bufferOffset); return n; };
    ce.prototype.shiftBuffer = function () { this.bufferOffset += this.buffers[0].length, this.writeIndex--, this.buffers.shift(); };
    ce.prototype.write = function (e) { var a, n; if (this.ended) {
        (n = (a = this.cbs).onerror) === null || n === void 0 || n.call(a, new Error(".write() after done!"));
        return;
    } this.buffers.push(e), this.tokenizer.running && (this.tokenizer.write(e), this.writeIndex++); };
    ce.prototype.end = function (e) { var a, n; if (this.ended) {
        (n = (a = this.cbs).onerror) === null || n === void 0 || n.call(a, new Error(".end() after done!"));
        return;
    } e && this.write(e), this.ended = !0, this.tokenizer.end(); };
    ce.prototype.pause = function () { this.tokenizer.pause(); };
    ce.prototype.resume = function () { for (this.tokenizer.resume(); this.tokenizer.running && this.writeIndex < this.buffers.length;)
        this.tokenizer.write(this.buffers[this.writeIndex++]); this.ended && this.tokenizer.end(); };
    ce.prototype.parseChunk = function (e) { this.write(e); };
    ce.prototype.done = function (e) { this.end(e); };
    return ce;
}());
var Ee = {};
Ye(Ee, { CDATA: function () { return fu; }, Comment: function () { return su; }, Directive: function () { return iu; }, Doctype: function () { return du; }, ElementType: function () { return U; }, Root: function () { return au; }, Script: function () { return cu; }, Style: function () { return ou; }, Tag: function () { return lu; }, Text: function () { return nu; }, isTag: function () { return ru; } });
var U;
(function (t) { t.Root = "root", t.Text = "text", t.Directive = "directive", t.Comment = "comment", t.Script = "script", t.Style = "style", t.Tag = "tag", t.CDATA = "cdata", t.Doctype = "doctype"; })(U || (U = {}));
function ru(t) { return t.type === U.Tag || t.type === U.Script || t.type === U.Style; }
var au = U.Root, nu = U.Text, iu = U.Directive, su = U.Comment, cu = U.Script, ou = U.Style, lu = U.Tag, fu = U.CDATA, du = U.Doctype;
var Ce = (function () {
    function Ce() {
        this.parent = null, this.prev = null, this.next = null, this.startIndex = null, this.endIndex = null;
    }
    Object.defineProperty(Ce.prototype, "parentNode", {
        get: function () { return this.parent; },
        set: function (e) { this.parent = e; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Ce.prototype, "previousSibling", {
        get: function () { return this.prev; },
        set: function (e) { this.prev = e; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Ce.prototype, "nextSibling", {
        get: function () { return this.next; },
        set: function (e) { this.next = e; },
        enumerable: false,
        configurable: true
    });
    Ce.prototype.cloneNode = function (e) {
        if (e === void 0) { e = !1; }
        return sr(this, e);
    };
    return Ce;
}()), oe = (function (_super) {
    __extends(oe, _super);
    function oe(e) {
        var _this = this;
        _this = _super.call(this) || this, _this.data = e;
        return _this;
    }
    Object.defineProperty(oe.prototype, "nodeValue", {
        get: function () { return this.data; },
        set: function (e) { this.data = e; },
        enumerable: false,
        configurable: true
    });
    return oe;
}(Ce)), Kt = (function (_super) {
    __extends(Kt, _super);
    function Kt() {
        var _this = this;
        _this = _super.apply(this, __spreadArray([], __read(arguments), false)) || this, _this.type = U.Text;
        return _this;
    }
    Object.defineProperty(Kt.prototype, "nodeType", {
        get: function () { return 3; },
        enumerable: false,
        configurable: true
    });
    return Kt;
}(oe)), le = (function (_super) {
    __extends(le, _super);
    function le() {
        var _this = this;
        _this = _super.apply(this, __spreadArray([], __read(arguments), false)) || this, _this.type = U.Comment;
        return _this;
    }
    Object.defineProperty(le.prototype, "nodeType", {
        get: function () { return 8; },
        enumerable: false,
        configurable: true
    });
    return le;
}(oe)), fe = (function (_super) {
    __extends(fe, _super);
    function fe(e, a) {
        var _this = this;
        _this = _super.call(this, a) || this, _this.name = e, _this.type = U.Directive;
        return _this;
    }
    Object.defineProperty(fe.prototype, "nodeType", {
        get: function () { return 1; },
        enumerable: false,
        configurable: true
    });
    return fe;
}(oe)), de = (function (_super) {
    __extends(de, _super);
    function de(e) {
        var _this = this;
        _this = _super.call(this) || this, _this.children = e;
        return _this;
    }
    Object.defineProperty(de.prototype, "firstChild", {
        get: function () { var e; return (e = this.children[0]) !== null && e !== void 0 ? e : null; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(de.prototype, "lastChild", {
        get: function () { return this.children.length > 0 ? this.children[this.children.length - 1] : null; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(de.prototype, "childNodes", {
        get: function () { return this.children; },
        set: function (e) { this.children = e; },
        enumerable: false,
        configurable: true
    });
    return de;
}(Ce)), he = (function (_super) {
    __extends(he, _super);
    function he() {
        var _this = this;
        _this = _super.apply(this, __spreadArray([], __read(arguments), false)) || this, _this.type = U.CDATA;
        return _this;
    }
    Object.defineProperty(he.prototype, "nodeType", {
        get: function () { return 4; },
        enumerable: false,
        configurable: true
    });
    return he;
}(de)), Yt = (function (_super) {
    __extends(Yt, _super);
    function Yt() {
        var _this = this;
        _this = _super.apply(this, __spreadArray([], __read(arguments), false)) || this, _this.type = U.Root;
        return _this;
    }
    Object.defineProperty(Yt.prototype, "nodeType", {
        get: function () { return 9; },
        enumerable: false,
        configurable: true
    });
    return Yt;
}(de)), pe = (function (_super) {
    __extends(pe, _super);
    function pe(e, a, n, s) {
        if (n === void 0) { n = []; }
        if (s === void 0) { s = e === "script" ? U.Script : e === "style" ? U.Style : U.Tag; }
        var _this = this;
        _this = _super.call(this, n) || this, _this.name = e, _this.attribs = a, _this.type = s;
        return _this;
    }
    Object.defineProperty(pe.prototype, "nodeType", {
        get: function () { return 1; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(pe.prototype, "tagName", {
        get: function () { return this.name; },
        set: function (e) { this.name = e; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(pe.prototype, "attributes", {
        get: function () {
            var _this = this;
            return Object.keys(this.attribs).map(function (e) { var a, n; return { name: e, value: _this.attribs[e], namespace: (a = _this["x-attribsNamespace"]) === null || a === void 0 ? void 0 : a[e], prefix: (n = _this["x-attribsPrefix"]) === null || n === void 0 ? void 0 : n[e] }; });
        },
        enumerable: false,
        configurable: true
    });
    return pe;
}(de));
function P(t) { return ru(t); }
function te(t) { return t.type === U.CDATA; }
function St(t) { return t.type === U.Text; }
function ge(t) { return t.type === U.Comment; }
function Ca(t) { return t.type === U.Directive; }
function pu(t) { return t.type === U.Root; }
function nt(t) { return Object.prototype.hasOwnProperty.call(t, "children"); }
function sr(t, e) {
    if (e === void 0) { e = !1; }
    var a;
    if (St(t))
        a = new Kt(t.data);
    else if (ge(t))
        a = new le(t.data);
    else if (P(t)) {
        var n = e ? hu(t.children) : [], s_1 = new pe(t.name, wt({}, t.attribs), n);
        n.forEach(function (o) { return o.parent = s_1; }), t.namespace != null && (s_1.namespace = t.namespace), t["x-attribsNamespace"] && (s_1["x-attribsNamespace"] = wt({}, t["x-attribsNamespace"])), t["x-attribsPrefix"] && (s_1["x-attribsPrefix"] = wt({}, t["x-attribsPrefix"])), a = s_1;
    }
    else if (te(t)) {
        var n = e ? hu(t.children) : [], s_2 = new he(n);
        n.forEach(function (o) { return o.parent = s_2; }), a = s_2;
    }
    else if (pu(t)) {
        var n = e ? hu(t.children) : [], s_3 = new Yt(n);
        n.forEach(function (o) { return o.parent = s_3; }), t["x-mode"] && (s_3["x-mode"] = t["x-mode"]), a = s_3;
    }
    else if (Ca(t)) {
        var n = new fe(t.name, t.data);
        t["x-name"] != null && (n["x-name"] = t["x-name"], n["x-publicId"] = t["x-publicId"], n["x-systemId"] = t["x-systemId"]), a = n;
    }
    else
        throw new Error("Not implemented yet: ".concat(t.type));
    return a.startIndex = t.startIndex, a.endIndex = t.endIndex, t.sourceCodeLocation != null && (a.sourceCodeLocation = t.sourceCodeLocation), a;
}
function hu(t) { var e = t.map(function (a) { return sr(a, !0); }); for (var a = 1; a < e.length; a++)
    e[a].prev = e[a - 1], e[a - 1].next = e[a]; return e; }
var cr = { withStartIndices: !1, withEndIndices: !1, xmlMode: !1 }, ee = (function () {
    function ee(e, a, n) {
        this.dom = [], this.root = new Yt(this.dom), this.done = !1, this.tagStack = [this.root], this.lastNode = null, this.parser = null, typeof a == "function" && (n = a, a = cr), typeof e == "object" && (a = e, e = void 0), this.callback = e != null ? e : null, this.options = a != null ? a : cr, this.elementCB = n != null ? n : null;
    }
    ee.prototype.onparserinit = function (e) { this.parser = e; };
    ee.prototype.onreset = function () { this.dom = [], this.root = new Yt(this.dom), this.done = !1, this.tagStack = [this.root], this.lastNode = null, this.parser = null; };
    ee.prototype.onend = function () { this.done || (this.done = !0, this.parser = null, this.handleCallback(null)); };
    ee.prototype.onerror = function (e) { this.handleCallback(e); };
    ee.prototype.onclosetag = function () { this.lastNode = null; var e = this.tagStack.pop(); this.options.withEndIndices && (e.endIndex = this.parser.endIndex), this.elementCB && this.elementCB(e); };
    ee.prototype.onopentag = function (e, a) { var n = this.options.xmlMode ? U.Tag : void 0, s = new pe(e, a, void 0, n); this.addNode(s), this.tagStack.push(s); };
    ee.prototype.ontext = function (e) { var a = this.lastNode; if (a && a.type === U.Text)
        a.data += e, this.options.withEndIndices && (a.endIndex = this.parser.endIndex);
    else {
        var n = new Kt(e);
        this.addNode(n), this.lastNode = n;
    } };
    ee.prototype.oncomment = function (e) { if (this.lastNode && this.lastNode.type === U.Comment) {
        this.lastNode.data += e;
        return;
    } var a = new le(e); this.addNode(a), this.lastNode = a; };
    ee.prototype.oncommentend = function () { this.lastNode = null; };
    ee.prototype.oncdatastart = function () { var e = new Kt(""), a = new he([e]); this.addNode(a), e.parent = a, this.lastNode = e; };
    ee.prototype.oncdataend = function () { this.lastNode = null; };
    ee.prototype.onprocessinginstruction = function (e, a) { var n = new fe(e, a); this.addNode(n); };
    ee.prototype.handleCallback = function (e) { if (typeof this.callback == "function")
        this.callback(e, this.dom);
    else if (e)
        throw e; };
    ee.prototype.addNode = function (e) { var a = this.tagStack[this.tagStack.length - 1], n = a.children[a.children.length - 1]; this.options.withStartIndices && (e.startIndex = this.parser.startIndex), this.options.withEndIndices && (e.endIndex = this.parser.endIndex), a.children.push(e), n && (e.prev = n, n.next = e), e.parent = a, this.lastNode = null; };
    return ee;
}());
var Tt = {};
Ye(Tt, { DocumentPosition: function () { return yt; }, append: function () { return $a; }, appendChild: function () { return za; }, compareDocumentPosition: function () { return Tr; }, existsOne: function () { return wr; }, filter: function () { return re; }, find: function () { return Ue; }, findAll: function () { return Xa; }, findOne: function () { return Re; }, findOneChild: function () { return Wa; }, getAttributeValue: function () { return Ia; }, getChildren: function () { return Oe; }, getElementById: function () { return Ya; }, getElements: function () { return Ka; }, getElementsByClassName: function () { return tn; }, getElementsByTagName: function () { return Gt; }, getElementsByTagType: function () { return en; }, getFeed: function () { return Cu; }, getInnerHTML: function () { return Fa; }, getName: function () { return Ga; }, getOuterHTML: function () { return yr; }, getParent: function () { return vr; }, getSiblings: function () { return De; }, getText: function () { return qe; }, hasAttrib: function () { return Va; }, hasChildren: function () { return nt; }, innerText: function () { return vu; }, isCDATA: function () { return te; }, isComment: function () { return ge; }, isDocument: function () { return pu; }, isTag: function () { return P; }, isText: function () { return St; }, nextElementSibling: function () { return wu; }, prepend: function () { return Tu; }, prependChild: function () { return Qa; }, prevElementSibling: function () { return Su; }, removeElement: function () { return Ct; }, removeSubsets: function () { return un; }, replaceElement: function () { return ja; }, testElement: function () { return Za; }, textContent: function () { return Dt; }, uniqueSort: function () { return Eu; } });
function Ne(t) { for (var e = 1; e < t.length; e++)
    t[e][0] += t[e - 1][0] + 1; return t; }
var Na = new Map(Ne([[9, "&Tab;"], [0, "&NewLine;"], [22, "&excl;"], [0, "&quot;"], [0, "&num;"], [0, "&dollar;"], [0, "&percnt;"], [0, "&amp;"], [0, "&apos;"], [0, "&lpar;"], [0, "&rpar;"], [0, "&ast;"], [0, "&plus;"], [0, "&comma;"], [1, "&period;"], [0, "&sol;"], [10, "&colon;"], [0, "&semi;"], [0, { v: "&lt;", n: 8402, o: "&nvlt;" }], [0, { v: "&equals;", n: 8421, o: "&bne;" }], [0, { v: "&gt;", n: 8402, o: "&nvgt;" }], [0, "&quest;"], [0, "&commat;"], [26, "&lbrack;"], [0, "&bsol;"], [0, "&rbrack;"], [0, "&Hat;"], [0, "&lowbar;"], [0, "&DiacriticalGrave;"], [5, { n: 106, o: "&fjlig;" }], [20, "&lbrace;"], [0, "&verbar;"], [0, "&rbrace;"], [34, "&nbsp;"], [0, "&iexcl;"], [0, "&cent;"], [0, "&pound;"], [0, "&curren;"], [0, "&yen;"], [0, "&brvbar;"], [0, "&sect;"], [0, "&die;"], [0, "&copy;"], [0, "&ordf;"], [0, "&laquo;"], [0, "&not;"], [0, "&shy;"], [0, "&circledR;"], [0, "&macr;"], [0, "&deg;"], [0, "&PlusMinus;"], [0, "&sup2;"], [0, "&sup3;"], [0, "&acute;"], [0, "&micro;"], [0, "&para;"], [0, "&centerdot;"], [0, "&cedil;"], [0, "&sup1;"], [0, "&ordm;"], [0, "&raquo;"], [0, "&frac14;"], [0, "&frac12;"], [0, "&frac34;"], [0, "&iquest;"], [0, "&Agrave;"], [0, "&Aacute;"], [0, "&Acirc;"], [0, "&Atilde;"], [0, "&Auml;"], [0, "&angst;"], [0, "&AElig;"], [0, "&Ccedil;"], [0, "&Egrave;"], [0, "&Eacute;"], [0, "&Ecirc;"], [0, "&Euml;"], [0, "&Igrave;"], [0, "&Iacute;"], [0, "&Icirc;"], [0, "&Iuml;"], [0, "&ETH;"], [0, "&Ntilde;"], [0, "&Ograve;"], [0, "&Oacute;"], [0, "&Ocirc;"], [0, "&Otilde;"], [0, "&Ouml;"], [0, "&times;"], [0, "&Oslash;"], [0, "&Ugrave;"], [0, "&Uacute;"], [0, "&Ucirc;"], [0, "&Uuml;"], [0, "&Yacute;"], [0, "&THORN;"], [0, "&szlig;"], [0, "&agrave;"], [0, "&aacute;"], [0, "&acirc;"], [0, "&atilde;"], [0, "&auml;"], [0, "&aring;"], [0, "&aelig;"], [0, "&ccedil;"], [0, "&egrave;"], [0, "&eacute;"], [0, "&ecirc;"], [0, "&euml;"], [0, "&igrave;"], [0, "&iacute;"], [0, "&icirc;"], [0, "&iuml;"], [0, "&eth;"], [0, "&ntilde;"], [0, "&ograve;"], [0, "&oacute;"], [0, "&ocirc;"], [0, "&otilde;"], [0, "&ouml;"], [0, "&div;"], [0, "&oslash;"], [0, "&ugrave;"], [0, "&uacute;"], [0, "&ucirc;"], [0, "&uuml;"], [0, "&yacute;"], [0, "&thorn;"], [0, "&yuml;"], [0, "&Amacr;"], [0, "&amacr;"], [0, "&Abreve;"], [0, "&abreve;"], [0, "&Aogon;"], [0, "&aogon;"], [0, "&Cacute;"], [0, "&cacute;"], [0, "&Ccirc;"], [0, "&ccirc;"], [0, "&Cdot;"], [0, "&cdot;"], [0, "&Ccaron;"], [0, "&ccaron;"], [0, "&Dcaron;"], [0, "&dcaron;"], [0, "&Dstrok;"], [0, "&dstrok;"], [0, "&Emacr;"], [0, "&emacr;"], [2, "&Edot;"], [0, "&edot;"], [0, "&Eogon;"], [0, "&eogon;"], [0, "&Ecaron;"], [0, "&ecaron;"], [0, "&Gcirc;"], [0, "&gcirc;"], [0, "&Gbreve;"], [0, "&gbreve;"], [0, "&Gdot;"], [0, "&gdot;"], [0, "&Gcedil;"], [1, "&Hcirc;"], [0, "&hcirc;"], [0, "&Hstrok;"], [0, "&hstrok;"], [0, "&Itilde;"], [0, "&itilde;"], [0, "&Imacr;"], [0, "&imacr;"], [2, "&Iogon;"], [0, "&iogon;"], [0, "&Idot;"], [0, "&imath;"], [0, "&IJlig;"], [0, "&ijlig;"], [0, "&Jcirc;"], [0, "&jcirc;"], [0, "&Kcedil;"], [0, "&kcedil;"], [0, "&kgreen;"], [0, "&Lacute;"], [0, "&lacute;"], [0, "&Lcedil;"], [0, "&lcedil;"], [0, "&Lcaron;"], [0, "&lcaron;"], [0, "&Lmidot;"], [0, "&lmidot;"], [0, "&Lstrok;"], [0, "&lstrok;"], [0, "&Nacute;"], [0, "&nacute;"], [0, "&Ncedil;"], [0, "&ncedil;"], [0, "&Ncaron;"], [0, "&ncaron;"], [0, "&napos;"], [0, "&ENG;"], [0, "&eng;"], [0, "&Omacr;"], [0, "&omacr;"], [2, "&Odblac;"], [0, "&odblac;"], [0, "&OElig;"], [0, "&oelig;"], [0, "&Racute;"], [0, "&racute;"], [0, "&Rcedil;"], [0, "&rcedil;"], [0, "&Rcaron;"], [0, "&rcaron;"], [0, "&Sacute;"], [0, "&sacute;"], [0, "&Scirc;"], [0, "&scirc;"], [0, "&Scedil;"], [0, "&scedil;"], [0, "&Scaron;"], [0, "&scaron;"], [0, "&Tcedil;"], [0, "&tcedil;"], [0, "&Tcaron;"], [0, "&tcaron;"], [0, "&Tstrok;"], [0, "&tstrok;"], [0, "&Utilde;"], [0, "&utilde;"], [0, "&Umacr;"], [0, "&umacr;"], [0, "&Ubreve;"], [0, "&ubreve;"], [0, "&Uring;"], [0, "&uring;"], [0, "&Udblac;"], [0, "&udblac;"], [0, "&Uogon;"], [0, "&uogon;"], [0, "&Wcirc;"], [0, "&wcirc;"], [0, "&Ycirc;"], [0, "&ycirc;"], [0, "&Yuml;"], [0, "&Zacute;"], [0, "&zacute;"], [0, "&Zdot;"], [0, "&zdot;"], [0, "&Zcaron;"], [0, "&zcaron;"], [19, "&fnof;"], [34, "&imped;"], [63, "&gacute;"], [65, "&jmath;"], [142, "&circ;"], [0, "&caron;"], [16, "&breve;"], [0, "&DiacriticalDot;"], [0, "&ring;"], [0, "&ogon;"], [0, "&DiacriticalTilde;"], [0, "&dblac;"], [51, "&DownBreve;"], [127, "&Alpha;"], [0, "&Beta;"], [0, "&Gamma;"], [0, "&Delta;"], [0, "&Epsilon;"], [0, "&Zeta;"], [0, "&Eta;"], [0, "&Theta;"], [0, "&Iota;"], [0, "&Kappa;"], [0, "&Lambda;"], [0, "&Mu;"], [0, "&Nu;"], [0, "&Xi;"], [0, "&Omicron;"], [0, "&Pi;"], [0, "&Rho;"], [1, "&Sigma;"], [0, "&Tau;"], [0, "&Upsilon;"], [0, "&Phi;"], [0, "&Chi;"], [0, "&Psi;"], [0, "&ohm;"], [7, "&alpha;"], [0, "&beta;"], [0, "&gamma;"], [0, "&delta;"], [0, "&epsi;"], [0, "&zeta;"], [0, "&eta;"], [0, "&theta;"], [0, "&iota;"], [0, "&kappa;"], [0, "&lambda;"], [0, "&mu;"], [0, "&nu;"], [0, "&xi;"], [0, "&omicron;"], [0, "&pi;"], [0, "&rho;"], [0, "&sigmaf;"], [0, "&sigma;"], [0, "&tau;"], [0, "&upsi;"], [0, "&phi;"], [0, "&chi;"], [0, "&psi;"], [0, "&omega;"], [7, "&thetasym;"], [0, "&Upsi;"], [2, "&phiv;"], [0, "&piv;"], [5, "&Gammad;"], [0, "&digamma;"], [18, "&kappav;"], [0, "&rhov;"], [3, "&epsiv;"], [0, "&backepsilon;"], [10, "&IOcy;"], [0, "&DJcy;"], [0, "&GJcy;"], [0, "&Jukcy;"], [0, "&DScy;"], [0, "&Iukcy;"], [0, "&YIcy;"], [0, "&Jsercy;"], [0, "&LJcy;"], [0, "&NJcy;"], [0, "&TSHcy;"], [0, "&KJcy;"], [1, "&Ubrcy;"], [0, "&DZcy;"], [0, "&Acy;"], [0, "&Bcy;"], [0, "&Vcy;"], [0, "&Gcy;"], [0, "&Dcy;"], [0, "&IEcy;"], [0, "&ZHcy;"], [0, "&Zcy;"], [0, "&Icy;"], [0, "&Jcy;"], [0, "&Kcy;"], [0, "&Lcy;"], [0, "&Mcy;"], [0, "&Ncy;"], [0, "&Ocy;"], [0, "&Pcy;"], [0, "&Rcy;"], [0, "&Scy;"], [0, "&Tcy;"], [0, "&Ucy;"], [0, "&Fcy;"], [0, "&KHcy;"], [0, "&TScy;"], [0, "&CHcy;"], [0, "&SHcy;"], [0, "&SHCHcy;"], [0, "&HARDcy;"], [0, "&Ycy;"], [0, "&SOFTcy;"], [0, "&Ecy;"], [0, "&YUcy;"], [0, "&YAcy;"], [0, "&acy;"], [0, "&bcy;"], [0, "&vcy;"], [0, "&gcy;"], [0, "&dcy;"], [0, "&iecy;"], [0, "&zhcy;"], [0, "&zcy;"], [0, "&icy;"], [0, "&jcy;"], [0, "&kcy;"], [0, "&lcy;"], [0, "&mcy;"], [0, "&ncy;"], [0, "&ocy;"], [0, "&pcy;"], [0, "&rcy;"], [0, "&scy;"], [0, "&tcy;"], [0, "&ucy;"], [0, "&fcy;"], [0, "&khcy;"], [0, "&tscy;"], [0, "&chcy;"], [0, "&shcy;"], [0, "&shchcy;"], [0, "&hardcy;"], [0, "&ycy;"], [0, "&softcy;"], [0, "&ecy;"], [0, "&yucy;"], [0, "&yacy;"], [1, "&iocy;"], [0, "&djcy;"], [0, "&gjcy;"], [0, "&jukcy;"], [0, "&dscy;"], [0, "&iukcy;"], [0, "&yicy;"], [0, "&jsercy;"], [0, "&ljcy;"], [0, "&njcy;"], [0, "&tshcy;"], [0, "&kjcy;"], [1, "&ubrcy;"], [0, "&dzcy;"], [7074, "&ensp;"], [0, "&emsp;"], [0, "&emsp13;"], [0, "&emsp14;"], [1, "&numsp;"], [0, "&puncsp;"], [0, "&ThinSpace;"], [0, "&hairsp;"], [0, "&NegativeMediumSpace;"], [0, "&zwnj;"], [0, "&zwj;"], [0, "&lrm;"], [0, "&rlm;"], [0, "&dash;"], [2, "&ndash;"], [0, "&mdash;"], [0, "&horbar;"], [0, "&Verbar;"], [1, "&lsquo;"], [0, "&CloseCurlyQuote;"], [0, "&lsquor;"], [1, "&ldquo;"], [0, "&CloseCurlyDoubleQuote;"], [0, "&bdquo;"], [1, "&dagger;"], [0, "&Dagger;"], [0, "&bull;"], [2, "&nldr;"], [0, "&hellip;"], [9, "&permil;"], [0, "&pertenk;"], [0, "&prime;"], [0, "&Prime;"], [0, "&tprime;"], [0, "&backprime;"], [3, "&lsaquo;"], [0, "&rsaquo;"], [3, "&oline;"], [2, "&caret;"], [1, "&hybull;"], [0, "&frasl;"], [10, "&bsemi;"], [7, "&qprime;"], [7, { v: "&MediumSpace;", n: 8202, o: "&ThickSpace;" }], [0, "&NoBreak;"], [0, "&af;"], [0, "&InvisibleTimes;"], [0, "&ic;"], [72, "&euro;"], [46, "&tdot;"], [0, "&DotDot;"], [37, "&complexes;"], [2, "&incare;"], [4, "&gscr;"], [0, "&hamilt;"], [0, "&Hfr;"], [0, "&Hopf;"], [0, "&planckh;"], [0, "&hbar;"], [0, "&imagline;"], [0, "&Ifr;"], [0, "&lagran;"], [0, "&ell;"], [1, "&naturals;"], [0, "&numero;"], [0, "&copysr;"], [0, "&weierp;"], [0, "&Popf;"], [0, "&Qopf;"], [0, "&realine;"], [0, "&real;"], [0, "&reals;"], [0, "&rx;"], [3, "&trade;"], [1, "&integers;"], [2, "&mho;"], [0, "&zeetrf;"], [0, "&iiota;"], [2, "&bernou;"], [0, "&Cayleys;"], [1, "&escr;"], [0, "&Escr;"], [0, "&Fouriertrf;"], [1, "&Mellintrf;"], [0, "&order;"], [0, "&alefsym;"], [0, "&beth;"], [0, "&gimel;"], [0, "&daleth;"], [12, "&CapitalDifferentialD;"], [0, "&dd;"], [0, "&ee;"], [0, "&ii;"], [10, "&frac13;"], [0, "&frac23;"], [0, "&frac15;"], [0, "&frac25;"], [0, "&frac35;"], [0, "&frac45;"], [0, "&frac16;"], [0, "&frac56;"], [0, "&frac18;"], [0, "&frac38;"], [0, "&frac58;"], [0, "&frac78;"], [49, "&larr;"], [0, "&ShortUpArrow;"], [0, "&rarr;"], [0, "&darr;"], [0, "&harr;"], [0, "&updownarrow;"], [0, "&nwarr;"], [0, "&nearr;"], [0, "&LowerRightArrow;"], [0, "&LowerLeftArrow;"], [0, "&nlarr;"], [0, "&nrarr;"], [1, { v: "&rarrw;", n: 824, o: "&nrarrw;" }], [0, "&Larr;"], [0, "&Uarr;"], [0, "&Rarr;"], [0, "&Darr;"], [0, "&larrtl;"], [0, "&rarrtl;"], [0, "&LeftTeeArrow;"], [0, "&mapstoup;"], [0, "&map;"], [0, "&DownTeeArrow;"], [1, "&hookleftarrow;"], [0, "&hookrightarrow;"], [0, "&larrlp;"], [0, "&looparrowright;"], [0, "&harrw;"], [0, "&nharr;"], [1, "&lsh;"], [0, "&rsh;"], [0, "&ldsh;"], [0, "&rdsh;"], [1, "&crarr;"], [0, "&cularr;"], [0, "&curarr;"], [2, "&circlearrowleft;"], [0, "&circlearrowright;"], [0, "&leftharpoonup;"], [0, "&DownLeftVector;"], [0, "&RightUpVector;"], [0, "&LeftUpVector;"], [0, "&rharu;"], [0, "&DownRightVector;"], [0, "&dharr;"], [0, "&dharl;"], [0, "&RightArrowLeftArrow;"], [0, "&udarr;"], [0, "&LeftArrowRightArrow;"], [0, "&leftleftarrows;"], [0, "&upuparrows;"], [0, "&rightrightarrows;"], [0, "&ddarr;"], [0, "&leftrightharpoons;"], [0, "&Equilibrium;"], [0, "&nlArr;"], [0, "&nhArr;"], [0, "&nrArr;"], [0, "&DoubleLeftArrow;"], [0, "&DoubleUpArrow;"], [0, "&DoubleRightArrow;"], [0, "&dArr;"], [0, "&DoubleLeftRightArrow;"], [0, "&DoubleUpDownArrow;"], [0, "&nwArr;"], [0, "&neArr;"], [0, "&seArr;"], [0, "&swArr;"], [0, "&lAarr;"], [0, "&rAarr;"], [1, "&zigrarr;"], [6, "&larrb;"], [0, "&rarrb;"], [15, "&DownArrowUpArrow;"], [7, "&loarr;"], [0, "&roarr;"], [0, "&hoarr;"], [0, "&forall;"], [0, "&comp;"], [0, { v: "&part;", n: 824, o: "&npart;" }], [0, "&exist;"], [0, "&nexist;"], [0, "&empty;"], [1, "&Del;"], [0, "&Element;"], [0, "&NotElement;"], [1, "&ni;"], [0, "&notni;"], [2, "&prod;"], [0, "&coprod;"], [0, "&sum;"], [0, "&minus;"], [0, "&MinusPlus;"], [0, "&dotplus;"], [1, "&Backslash;"], [0, "&lowast;"], [0, "&compfn;"], [1, "&radic;"], [2, "&prop;"], [0, "&infin;"], [0, "&angrt;"], [0, { v: "&ang;", n: 8402, o: "&nang;" }], [0, "&angmsd;"], [0, "&angsph;"], [0, "&mid;"], [0, "&nmid;"], [0, "&DoubleVerticalBar;"], [0, "&NotDoubleVerticalBar;"], [0, "&and;"], [0, "&or;"], [0, { v: "&cap;", n: 65024, o: "&caps;" }], [0, { v: "&cup;", n: 65024, o: "&cups;" }], [0, "&int;"], [0, "&Int;"], [0, "&iiint;"], [0, "&conint;"], [0, "&Conint;"], [0, "&Cconint;"], [0, "&cwint;"], [0, "&ClockwiseContourIntegral;"], [0, "&awconint;"], [0, "&there4;"], [0, "&becaus;"], [0, "&ratio;"], [0, "&Colon;"], [0, "&dotminus;"], [1, "&mDDot;"], [0, "&homtht;"], [0, { v: "&sim;", n: 8402, o: "&nvsim;" }], [0, { v: "&backsim;", n: 817, o: "&race;" }], [0, { v: "&ac;", n: 819, o: "&acE;" }], [0, "&acd;"], [0, "&VerticalTilde;"], [0, "&NotTilde;"], [0, { v: "&eqsim;", n: 824, o: "&nesim;" }], [0, "&sime;"], [0, "&NotTildeEqual;"], [0, "&cong;"], [0, "&simne;"], [0, "&ncong;"], [0, "&ap;"], [0, "&nap;"], [0, "&ape;"], [0, { v: "&apid;", n: 824, o: "&napid;" }], [0, "&backcong;"], [0, { v: "&asympeq;", n: 8402, o: "&nvap;" }], [0, { v: "&bump;", n: 824, o: "&nbump;" }], [0, { v: "&bumpe;", n: 824, o: "&nbumpe;" }], [0, { v: "&doteq;", n: 824, o: "&nedot;" }], [0, "&doteqdot;"], [0, "&efDot;"], [0, "&erDot;"], [0, "&Assign;"], [0, "&ecolon;"], [0, "&ecir;"], [0, "&circeq;"], [1, "&wedgeq;"], [0, "&veeeq;"], [1, "&triangleq;"], [2, "&equest;"], [0, "&ne;"], [0, { v: "&Congruent;", n: 8421, o: "&bnequiv;" }], [0, "&nequiv;"], [1, { v: "&le;", n: 8402, o: "&nvle;" }], [0, { v: "&ge;", n: 8402, o: "&nvge;" }], [0, { v: "&lE;", n: 824, o: "&nlE;" }], [0, { v: "&gE;", n: 824, o: "&ngE;" }], [0, { v: "&lnE;", n: 65024, o: "&lvertneqq;" }], [0, { v: "&gnE;", n: 65024, o: "&gvertneqq;" }], [0, { v: "&ll;", n: new Map(Ne([[824, "&nLtv;"], [7577, "&nLt;"]])) }], [0, { v: "&gg;", n: new Map(Ne([[824, "&nGtv;"], [7577, "&nGt;"]])) }], [0, "&between;"], [0, "&NotCupCap;"], [0, "&nless;"], [0, "&ngt;"], [0, "&nle;"], [0, "&nge;"], [0, "&lesssim;"], [0, "&GreaterTilde;"], [0, "&nlsim;"], [0, "&ngsim;"], [0, "&LessGreater;"], [0, "&gl;"], [0, "&NotLessGreater;"], [0, "&NotGreaterLess;"], [0, "&pr;"], [0, "&sc;"], [0, "&prcue;"], [0, "&sccue;"], [0, "&PrecedesTilde;"], [0, { v: "&scsim;", n: 824, o: "&NotSucceedsTilde;" }], [0, "&NotPrecedes;"], [0, "&NotSucceeds;"], [0, { v: "&sub;", n: 8402, o: "&NotSubset;" }], [0, { v: "&sup;", n: 8402, o: "&NotSuperset;" }], [0, "&nsub;"], [0, "&nsup;"], [0, "&sube;"], [0, "&supe;"], [0, "&NotSubsetEqual;"], [0, "&NotSupersetEqual;"], [0, { v: "&subne;", n: 65024, o: "&varsubsetneq;" }], [0, { v: "&supne;", n: 65024, o: "&varsupsetneq;" }], [1, "&cupdot;"], [0, "&UnionPlus;"], [0, { v: "&sqsub;", n: 824, o: "&NotSquareSubset;" }], [0, { v: "&sqsup;", n: 824, o: "&NotSquareSuperset;" }], [0, "&sqsube;"], [0, "&sqsupe;"], [0, { v: "&sqcap;", n: 65024, o: "&sqcaps;" }], [0, { v: "&sqcup;", n: 65024, o: "&sqcups;" }], [0, "&CirclePlus;"], [0, "&CircleMinus;"], [0, "&CircleTimes;"], [0, "&osol;"], [0, "&CircleDot;"], [0, "&circledcirc;"], [0, "&circledast;"], [1, "&circleddash;"], [0, "&boxplus;"], [0, "&boxminus;"], [0, "&boxtimes;"], [0, "&dotsquare;"], [0, "&RightTee;"], [0, "&dashv;"], [0, "&DownTee;"], [0, "&bot;"], [1, "&models;"], [0, "&DoubleRightTee;"], [0, "&Vdash;"], [0, "&Vvdash;"], [0, "&VDash;"], [0, "&nvdash;"], [0, "&nvDash;"], [0, "&nVdash;"], [0, "&nVDash;"], [0, "&prurel;"], [1, "&LeftTriangle;"], [0, "&RightTriangle;"], [0, { v: "&LeftTriangleEqual;", n: 8402, o: "&nvltrie;" }], [0, { v: "&RightTriangleEqual;", n: 8402, o: "&nvrtrie;" }], [0, "&origof;"], [0, "&imof;"], [0, "&multimap;"], [0, "&hercon;"], [0, "&intcal;"], [0, "&veebar;"], [1, "&barvee;"], [0, "&angrtvb;"], [0, "&lrtri;"], [0, "&bigwedge;"], [0, "&bigvee;"], [0, "&bigcap;"], [0, "&bigcup;"], [0, "&diam;"], [0, "&sdot;"], [0, "&sstarf;"], [0, "&divideontimes;"], [0, "&bowtie;"], [0, "&ltimes;"], [0, "&rtimes;"], [0, "&leftthreetimes;"], [0, "&rightthreetimes;"], [0, "&backsimeq;"], [0, "&curlyvee;"], [0, "&curlywedge;"], [0, "&Sub;"], [0, "&Sup;"], [0, "&Cap;"], [0, "&Cup;"], [0, "&fork;"], [0, "&epar;"], [0, "&lessdot;"], [0, "&gtdot;"], [0, { v: "&Ll;", n: 824, o: "&nLl;" }], [0, { v: "&Gg;", n: 824, o: "&nGg;" }], [0, { v: "&leg;", n: 65024, o: "&lesg;" }], [0, { v: "&gel;", n: 65024, o: "&gesl;" }], [2, "&cuepr;"], [0, "&cuesc;"], [0, "&NotPrecedesSlantEqual;"], [0, "&NotSucceedsSlantEqual;"], [0, "&NotSquareSubsetEqual;"], [0, "&NotSquareSupersetEqual;"], [2, "&lnsim;"], [0, "&gnsim;"], [0, "&precnsim;"], [0, "&scnsim;"], [0, "&nltri;"], [0, "&NotRightTriangle;"], [0, "&nltrie;"], [0, "&NotRightTriangleEqual;"], [0, "&vellip;"], [0, "&ctdot;"], [0, "&utdot;"], [0, "&dtdot;"], [0, "&disin;"], [0, "&isinsv;"], [0, "&isins;"], [0, { v: "&isindot;", n: 824, o: "&notindot;" }], [0, "&notinvc;"], [0, "&notinvb;"], [1, { v: "&isinE;", n: 824, o: "&notinE;" }], [0, "&nisd;"], [0, "&xnis;"], [0, "&nis;"], [0, "&notnivc;"], [0, "&notnivb;"], [6, "&barwed;"], [0, "&Barwed;"], [1, "&lceil;"], [0, "&rceil;"], [0, "&LeftFloor;"], [0, "&rfloor;"], [0, "&drcrop;"], [0, "&dlcrop;"], [0, "&urcrop;"], [0, "&ulcrop;"], [0, "&bnot;"], [1, "&profline;"], [0, "&profsurf;"], [1, "&telrec;"], [0, "&target;"], [5, "&ulcorn;"], [0, "&urcorn;"], [0, "&dlcorn;"], [0, "&drcorn;"], [2, "&frown;"], [0, "&smile;"], [9, "&cylcty;"], [0, "&profalar;"], [7, "&topbot;"], [6, "&ovbar;"], [1, "&solbar;"], [60, "&angzarr;"], [51, "&lmoustache;"], [0, "&rmoustache;"], [2, "&OverBracket;"], [0, "&bbrk;"], [0, "&bbrktbrk;"], [37, "&OverParenthesis;"], [0, "&UnderParenthesis;"], [0, "&OverBrace;"], [0, "&UnderBrace;"], [2, "&trpezium;"], [4, "&elinters;"], [59, "&blank;"], [164, "&circledS;"], [55, "&boxh;"], [1, "&boxv;"], [9, "&boxdr;"], [3, "&boxdl;"], [3, "&boxur;"], [3, "&boxul;"], [3, "&boxvr;"], [7, "&boxvl;"], [7, "&boxhd;"], [7, "&boxhu;"], [7, "&boxvh;"], [19, "&boxH;"], [0, "&boxV;"], [0, "&boxdR;"], [0, "&boxDr;"], [0, "&boxDR;"], [0, "&boxdL;"], [0, "&boxDl;"], [0, "&boxDL;"], [0, "&boxuR;"], [0, "&boxUr;"], [0, "&boxUR;"], [0, "&boxuL;"], [0, "&boxUl;"], [0, "&boxUL;"], [0, "&boxvR;"], [0, "&boxVr;"], [0, "&boxVR;"], [0, "&boxvL;"], [0, "&boxVl;"], [0, "&boxVL;"], [0, "&boxHd;"], [0, "&boxhD;"], [0, "&boxHD;"], [0, "&boxHu;"], [0, "&boxhU;"], [0, "&boxHU;"], [0, "&boxvH;"], [0, "&boxVh;"], [0, "&boxVH;"], [19, "&uhblk;"], [3, "&lhblk;"], [3, "&block;"], [8, "&blk14;"], [0, "&blk12;"], [0, "&blk34;"], [13, "&square;"], [8, "&blacksquare;"], [0, "&EmptyVerySmallSquare;"], [1, "&rect;"], [0, "&marker;"], [2, "&fltns;"], [1, "&bigtriangleup;"], [0, "&blacktriangle;"], [0, "&triangle;"], [2, "&blacktriangleright;"], [0, "&rtri;"], [3, "&bigtriangledown;"], [0, "&blacktriangledown;"], [0, "&dtri;"], [2, "&blacktriangleleft;"], [0, "&ltri;"], [6, "&loz;"], [0, "&cir;"], [32, "&tridot;"], [2, "&bigcirc;"], [8, "&ultri;"], [0, "&urtri;"], [0, "&lltri;"], [0, "&EmptySmallSquare;"], [0, "&FilledSmallSquare;"], [8, "&bigstar;"], [0, "&star;"], [7, "&phone;"], [49, "&female;"], [1, "&male;"], [29, "&spades;"], [2, "&clubs;"], [1, "&hearts;"], [0, "&diamondsuit;"], [3, "&sung;"], [2, "&flat;"], [0, "&natural;"], [0, "&sharp;"], [163, "&check;"], [3, "&cross;"], [8, "&malt;"], [21, "&sext;"], [33, "&VerticalSeparator;"], [25, "&lbbrk;"], [0, "&rbbrk;"], [84, "&bsolhsub;"], [0, "&suphsol;"], [28, "&LeftDoubleBracket;"], [0, "&RightDoubleBracket;"], [0, "&lang;"], [0, "&rang;"], [0, "&Lang;"], [0, "&Rang;"], [0, "&loang;"], [0, "&roang;"], [7, "&longleftarrow;"], [0, "&longrightarrow;"], [0, "&longleftrightarrow;"], [0, "&DoubleLongLeftArrow;"], [0, "&DoubleLongRightArrow;"], [0, "&DoubleLongLeftRightArrow;"], [1, "&longmapsto;"], [2, "&dzigrarr;"], [258, "&nvlArr;"], [0, "&nvrArr;"], [0, "&nvHarr;"], [0, "&Map;"], [6, "&lbarr;"], [0, "&bkarow;"], [0, "&lBarr;"], [0, "&dbkarow;"], [0, "&drbkarow;"], [0, "&DDotrahd;"], [0, "&UpArrowBar;"], [0, "&DownArrowBar;"], [2, "&Rarrtl;"], [2, "&latail;"], [0, "&ratail;"], [0, "&lAtail;"], [0, "&rAtail;"], [0, "&larrfs;"], [0, "&rarrfs;"], [0, "&larrbfs;"], [0, "&rarrbfs;"], [2, "&nwarhk;"], [0, "&nearhk;"], [0, "&hksearow;"], [0, "&hkswarow;"], [0, "&nwnear;"], [0, "&nesear;"], [0, "&seswar;"], [0, "&swnwar;"], [8, { v: "&rarrc;", n: 824, o: "&nrarrc;" }], [1, "&cudarrr;"], [0, "&ldca;"], [0, "&rdca;"], [0, "&cudarrl;"], [0, "&larrpl;"], [2, "&curarrm;"], [0, "&cularrp;"], [7, "&rarrpl;"], [2, "&harrcir;"], [0, "&Uarrocir;"], [0, "&lurdshar;"], [0, "&ldrushar;"], [2, "&LeftRightVector;"], [0, "&RightUpDownVector;"], [0, "&DownLeftRightVector;"], [0, "&LeftUpDownVector;"], [0, "&LeftVectorBar;"], [0, "&RightVectorBar;"], [0, "&RightUpVectorBar;"], [0, "&RightDownVectorBar;"], [0, "&DownLeftVectorBar;"], [0, "&DownRightVectorBar;"], [0, "&LeftUpVectorBar;"], [0, "&LeftDownVectorBar;"], [0, "&LeftTeeVector;"], [0, "&RightTeeVector;"], [0, "&RightUpTeeVector;"], [0, "&RightDownTeeVector;"], [0, "&DownLeftTeeVector;"], [0, "&DownRightTeeVector;"], [0, "&LeftUpTeeVector;"], [0, "&LeftDownTeeVector;"], [0, "&lHar;"], [0, "&uHar;"], [0, "&rHar;"], [0, "&dHar;"], [0, "&luruhar;"], [0, "&ldrdhar;"], [0, "&ruluhar;"], [0, "&rdldhar;"], [0, "&lharul;"], [0, "&llhard;"], [0, "&rharul;"], [0, "&lrhard;"], [0, "&udhar;"], [0, "&duhar;"], [0, "&RoundImplies;"], [0, "&erarr;"], [0, "&simrarr;"], [0, "&larrsim;"], [0, "&rarrsim;"], [0, "&rarrap;"], [0, "&ltlarr;"], [1, "&gtrarr;"], [0, "&subrarr;"], [1, "&suplarr;"], [0, "&lfisht;"], [0, "&rfisht;"], [0, "&ufisht;"], [0, "&dfisht;"], [5, "&lopar;"], [0, "&ropar;"], [4, "&lbrke;"], [0, "&rbrke;"], [0, "&lbrkslu;"], [0, "&rbrksld;"], [0, "&lbrksld;"], [0, "&rbrkslu;"], [0, "&langd;"], [0, "&rangd;"], [0, "&lparlt;"], [0, "&rpargt;"], [0, "&gtlPar;"], [0, "&ltrPar;"], [3, "&vzigzag;"], [1, "&vangrt;"], [0, "&angrtvbd;"], [6, "&ange;"], [0, "&range;"], [0, "&dwangle;"], [0, "&uwangle;"], [0, "&angmsdaa;"], [0, "&angmsdab;"], [0, "&angmsdac;"], [0, "&angmsdad;"], [0, "&angmsdae;"], [0, "&angmsdaf;"], [0, "&angmsdag;"], [0, "&angmsdah;"], [0, "&bemptyv;"], [0, "&demptyv;"], [0, "&cemptyv;"], [0, "&raemptyv;"], [0, "&laemptyv;"], [0, "&ohbar;"], [0, "&omid;"], [0, "&opar;"], [1, "&operp;"], [1, "&olcross;"], [0, "&odsold;"], [1, "&olcir;"], [0, "&ofcir;"], [0, "&olt;"], [0, "&ogt;"], [0, "&cirscir;"], [0, "&cirE;"], [0, "&solb;"], [0, "&bsolb;"], [3, "&boxbox;"], [3, "&trisb;"], [0, "&rtriltri;"], [0, { v: "&LeftTriangleBar;", n: 824, o: "&NotLeftTriangleBar;" }], [0, { v: "&RightTriangleBar;", n: 824, o: "&NotRightTriangleBar;" }], [11, "&iinfin;"], [0, "&infintie;"], [0, "&nvinfin;"], [4, "&eparsl;"], [0, "&smeparsl;"], [0, "&eqvparsl;"], [5, "&blacklozenge;"], [8, "&RuleDelayed;"], [1, "&dsol;"], [9, "&bigodot;"], [0, "&bigoplus;"], [0, "&bigotimes;"], [1, "&biguplus;"], [1, "&bigsqcup;"], [5, "&iiiint;"], [0, "&fpartint;"], [2, "&cirfnint;"], [0, "&awint;"], [0, "&rppolint;"], [0, "&scpolint;"], [0, "&npolint;"], [0, "&pointint;"], [0, "&quatint;"], [0, "&intlarhk;"], [10, "&pluscir;"], [0, "&plusacir;"], [0, "&simplus;"], [0, "&plusdu;"], [0, "&plussim;"], [0, "&plustwo;"], [1, "&mcomma;"], [0, "&minusdu;"], [2, "&loplus;"], [0, "&roplus;"], [0, "&Cross;"], [0, "&timesd;"], [0, "&timesbar;"], [1, "&smashp;"], [0, "&lotimes;"], [0, "&rotimes;"], [0, "&otimesas;"], [0, "&Otimes;"], [0, "&odiv;"], [0, "&triplus;"], [0, "&triminus;"], [0, "&tritime;"], [0, "&intprod;"], [2, "&amalg;"], [0, "&capdot;"], [1, "&ncup;"], [0, "&ncap;"], [0, "&capand;"], [0, "&cupor;"], [0, "&cupcap;"], [0, "&capcup;"], [0, "&cupbrcap;"], [0, "&capbrcup;"], [0, "&cupcup;"], [0, "&capcap;"], [0, "&ccups;"], [0, "&ccaps;"], [2, "&ccupssm;"], [2, "&And;"], [0, "&Or;"], [0, "&andand;"], [0, "&oror;"], [0, "&orslope;"], [0, "&andslope;"], [1, "&andv;"], [0, "&orv;"], [0, "&andd;"], [0, "&ord;"], [1, "&wedbar;"], [6, "&sdote;"], [3, "&simdot;"], [2, { v: "&congdot;", n: 824, o: "&ncongdot;" }], [0, "&easter;"], [0, "&apacir;"], [0, { v: "&apE;", n: 824, o: "&napE;" }], [0, "&eplus;"], [0, "&pluse;"], [0, "&Esim;"], [0, "&Colone;"], [0, "&Equal;"], [1, "&ddotseq;"], [0, "&equivDD;"], [0, "&ltcir;"], [0, "&gtcir;"], [0, "&ltquest;"], [0, "&gtquest;"], [0, { v: "&leqslant;", n: 824, o: "&nleqslant;" }], [0, { v: "&geqslant;", n: 824, o: "&ngeqslant;" }], [0, "&lesdot;"], [0, "&gesdot;"], [0, "&lesdoto;"], [0, "&gesdoto;"], [0, "&lesdotor;"], [0, "&gesdotol;"], [0, "&lap;"], [0, "&gap;"], [0, "&lne;"], [0, "&gne;"], [0, "&lnap;"], [0, "&gnap;"], [0, "&lEg;"], [0, "&gEl;"], [0, "&lsime;"], [0, "&gsime;"], [0, "&lsimg;"], [0, "&gsiml;"], [0, "&lgE;"], [0, "&glE;"], [0, "&lesges;"], [0, "&gesles;"], [0, "&els;"], [0, "&egs;"], [0, "&elsdot;"], [0, "&egsdot;"], [0, "&el;"], [0, "&eg;"], [2, "&siml;"], [0, "&simg;"], [0, "&simlE;"], [0, "&simgE;"], [0, { v: "&LessLess;", n: 824, o: "&NotNestedLessLess;" }], [0, { v: "&GreaterGreater;", n: 824, o: "&NotNestedGreaterGreater;" }], [1, "&glj;"], [0, "&gla;"], [0, "&ltcc;"], [0, "&gtcc;"], [0, "&lescc;"], [0, "&gescc;"], [0, "&smt;"], [0, "&lat;"], [0, { v: "&smte;", n: 65024, o: "&smtes;" }], [0, { v: "&late;", n: 65024, o: "&lates;" }], [0, "&bumpE;"], [0, { v: "&PrecedesEqual;", n: 824, o: "&NotPrecedesEqual;" }], [0, { v: "&sce;", n: 824, o: "&NotSucceedsEqual;" }], [2, "&prE;"], [0, "&scE;"], [0, "&precneqq;"], [0, "&scnE;"], [0, "&prap;"], [0, "&scap;"], [0, "&precnapprox;"], [0, "&scnap;"], [0, "&Pr;"], [0, "&Sc;"], [0, "&subdot;"], [0, "&supdot;"], [0, "&subplus;"], [0, "&supplus;"], [0, "&submult;"], [0, "&supmult;"], [0, "&subedot;"], [0, "&supedot;"], [0, { v: "&subE;", n: 824, o: "&nsubE;" }], [0, { v: "&supE;", n: 824, o: "&nsupE;" }], [0, "&subsim;"], [0, "&supsim;"], [2, { v: "&subnE;", n: 65024, o: "&varsubsetneqq;" }], [0, { v: "&supnE;", n: 65024, o: "&varsupsetneqq;" }], [2, "&csub;"], [0, "&csup;"], [0, "&csube;"], [0, "&csupe;"], [0, "&subsup;"], [0, "&supsub;"], [0, "&subsub;"], [0, "&supsup;"], [0, "&suphsub;"], [0, "&supdsub;"], [0, "&forkv;"], [0, "&topfork;"], [0, "&mlcp;"], [8, "&Dashv;"], [1, "&Vdashl;"], [0, "&Barv;"], [0, "&vBar;"], [0, "&vBarv;"], [1, "&Vbar;"], [0, "&Not;"], [0, "&bNot;"], [0, "&rnmid;"], [0, "&cirmid;"], [0, "&midcir;"], [0, "&topcir;"], [0, "&nhpar;"], [0, "&parsim;"], [9, { v: "&parsl;", n: 8421, o: "&nparsl;" }], [44343, { n: new Map(Ne([[56476, "&Ascr;"], [1, "&Cscr;"], [0, "&Dscr;"], [2, "&Gscr;"], [2, "&Jscr;"], [0, "&Kscr;"], [2, "&Nscr;"], [0, "&Oscr;"], [0, "&Pscr;"], [0, "&Qscr;"], [1, "&Sscr;"], [0, "&Tscr;"], [0, "&Uscr;"], [0, "&Vscr;"], [0, "&Wscr;"], [0, "&Xscr;"], [0, "&Yscr;"], [0, "&Zscr;"], [0, "&ascr;"], [0, "&bscr;"], [0, "&cscr;"], [0, "&dscr;"], [1, "&fscr;"], [1, "&hscr;"], [0, "&iscr;"], [0, "&jscr;"], [0, "&kscr;"], [0, "&lscr;"], [0, "&mscr;"], [0, "&nscr;"], [1, "&pscr;"], [0, "&qscr;"], [0, "&rscr;"], [0, "&sscr;"], [0, "&tscr;"], [0, "&uscr;"], [0, "&vscr;"], [0, "&wscr;"], [0, "&xscr;"], [0, "&yscr;"], [0, "&zscr;"], [52, "&Afr;"], [0, "&Bfr;"], [1, "&Dfr;"], [0, "&Efr;"], [0, "&Ffr;"], [0, "&Gfr;"], [2, "&Jfr;"], [0, "&Kfr;"], [0, "&Lfr;"], [0, "&Mfr;"], [0, "&Nfr;"], [0, "&Ofr;"], [0, "&Pfr;"], [0, "&Qfr;"], [1, "&Sfr;"], [0, "&Tfr;"], [0, "&Ufr;"], [0, "&Vfr;"], [0, "&Wfr;"], [0, "&Xfr;"], [0, "&Yfr;"], [1, "&afr;"], [0, "&bfr;"], [0, "&cfr;"], [0, "&dfr;"], [0, "&efr;"], [0, "&ffr;"], [0, "&gfr;"], [0, "&hfr;"], [0, "&ifr;"], [0, "&jfr;"], [0, "&kfr;"], [0, "&lfr;"], [0, "&mfr;"], [0, "&nfr;"], [0, "&ofr;"], [0, "&pfr;"], [0, "&qfr;"], [0, "&rfr;"], [0, "&sfr;"], [0, "&tfr;"], [0, "&ufr;"], [0, "&vfr;"], [0, "&wfr;"], [0, "&xfr;"], [0, "&yfr;"], [0, "&zfr;"], [0, "&Aopf;"], [0, "&Bopf;"], [1, "&Dopf;"], [0, "&Eopf;"], [0, "&Fopf;"], [0, "&Gopf;"], [1, "&Iopf;"], [0, "&Jopf;"], [0, "&Kopf;"], [0, "&Lopf;"], [0, "&Mopf;"], [1, "&Oopf;"], [3, "&Sopf;"], [0, "&Topf;"], [0, "&Uopf;"], [0, "&Vopf;"], [0, "&Wopf;"], [0, "&Xopf;"], [0, "&Yopf;"], [1, "&aopf;"], [0, "&bopf;"], [0, "&copf;"], [0, "&dopf;"], [0, "&eopf;"], [0, "&fopf;"], [0, "&gopf;"], [0, "&hopf;"], [0, "&iopf;"], [0, "&jopf;"], [0, "&kopf;"], [0, "&lopf;"], [0, "&mopf;"], [0, "&nopf;"], [0, "&oopf;"], [0, "&popf;"], [0, "&qopf;"], [0, "&ropf;"], [0, "&sopf;"], [0, "&topf;"], [0, "&uopf;"], [0, "&vopf;"], [0, "&wopf;"], [0, "&xopf;"], [0, "&yopf;"], [0, "&zopf;"]])) }], [8906, "&fflig;"], [0, "&filig;"], [0, "&fllig;"], [0, "&ffilig;"], [0, "&ffllig;"]]));
var gu = /["&'<>$\x80-\uFFFF]/g, or = new Map([[34, "&quot;"], [38, "&amp;"], [39, "&apos;"], [60, "&lt;"], [62, "&gt;"]]), lr = String.prototype.codePointAt != null ? function (t, e) { return t.codePointAt(e); } : function (t, e) { return (t.charCodeAt(e) & 64512) === 55296 ? (t.charCodeAt(e) - 55296) * 1024 + t.charCodeAt(e + 1) - 56320 + 65536 : t.charCodeAt(e); };
function be(t) { var e = "", a = 0, n; for (; (n = gu.exec(t)) !== null;) {
    var s = n.index, o = t.charCodeAt(s), f = or.get(o);
    f !== void 0 ? (e += t.substring(a, s) + f, a = s + 1) : (e += "".concat(t.substring(a, s), "&#x").concat(lr(t, s).toString(16), ";"), a = gu.lastIndex += +((o & 64512) === 55296));
} return e + t.substr(a); }
function bu(t, e) { return function (n) { var s, o = 0, f = ""; for (; s = t.exec(n);)
    o !== s.index && (f += n.substring(o, s.index)), f += e.get(s[0].charCodeAt(0)), o = s.index + 1; return f + n.substring(o); }; }
var fr = bu(/[&<>'"]/g, or), ke = bu(/["&\u00A0]/g, new Map([[34, "&quot;"], [38, "&amp;"], [160, "&nbsp;"]])), Le = bu(/[&<>\u00A0]/g, new Map([[38, "&amp;"], [60, "&lt;"], [62, "&gt;"], [160, "&nbsp;"]]));
var dr;
(function (t) { t[t.XML = 0] = "XML", t[t.HTML = 1] = "HTML"; })(dr || (dr = {}));
var hr;
(function (t) { t[t.UTF8 = 0] = "UTF8", t[t.ASCII = 1] = "ASCII", t[t.Extensive = 2] = "Extensive", t[t.Attribute = 3] = "Attribute", t[t.Text = 4] = "Text"; })(hr || (hr = {}));
var br = new Map(["altGlyph", "altGlyphDef", "altGlyphItem", "animateColor", "animateMotion", "animateTransform", "clipPath", "feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence", "foreignObject", "glyphRef", "linearGradient", "radialGradient", "textPath"].map(function (t) { return [t.toLowerCase(), t]; })), mr = new Map(["definitionURL", "attributeName", "attributeType", "baseFrequency", "baseProfile", "calcMode", "clipPathUnits", "diffuseConstant", "edgeMode", "filterUnits", "glyphRef", "gradientTransform", "gradientUnits", "kernelMatrix", "kernelUnitLength", "keyPoints", "keySplines", "keyTimes", "lengthAdjust", "limitingConeAngle", "markerHeight", "markerUnits", "markerWidth", "maskContentUnits", "maskUnits", "numOctaves", "pathLength", "patternContentUnits", "patternTransform", "patternUnits", "pointsAtX", "pointsAtY", "pointsAtZ", "preserveAlpha", "preserveAspectRatio", "primitiveUnits", "refX", "refY", "repeatCount", "repeatDur", "requiredExtensions", "requiredFeatures", "specularConstant", "specularExponent", "spreadMethod", "startOffset", "stdDeviation", "stitchTiles", "surfaceScale", "systemLanguage", "tableValues", "targetX", "targetY", "textLength", "viewBox", "viewTarget", "xChannelSelector", "yChannelSelector", "zoomAndPan"].map(function (t) { return [t.toLowerCase(), t]; }));
var La = new Set(["style", "script", "xmp", "iframe", "noembed", "noframes", "plaintext", "noscript"]);
function qa(t) { return t.replace(/"/g, "&quot;"); }
function Oa(t, e) { var a; if (!t)
    return; var n = ((a = e.encodeEntities) !== null && a !== void 0 ? a : e.decodeEntities) === !1 ? qa : e.xmlMode || e.encodeEntities !== "utf8" ? be : ke; return Object.keys(t).map(function (s) { var o, f; var h = (o = t[s]) !== null && o !== void 0 ? o : ""; return e.xmlMode === "foreign" && (s = (f = mr.get(s)) !== null && f !== void 0 ? f : s), !e.emptyAttrs && !e.xmlMode && h === "" ? s : "".concat(s, "=\"").concat(n(h), "\""); }).join(" "); }
var xr = new Set(["area", "base", "basefont", "br", "col", "command", "embed", "frame", "hr", "img", "input", "isindex", "keygen", "link", "meta", "param", "source", "track", "wbr"]);
function yu(t, e) {
    if (e === void 0) { e = {}; }
    var a = "length" in t ? t : [t], n = "";
    for (var s = 0; s < a.length; s++)
        n += Da(a[s], e);
    return n;
}
var ue = yu;
function Da(t, e) { switch (t.type) {
    case au: return yu(t.children, e);
    case du:
    case iu: return Ba(t);
    case su: return Ma(t);
    case fu: return _a(t);
    case cu:
    case ou:
    case lu: return Pa(t, e);
    case nu: return Ha(t, e);
} }
var Ua = new Set(["mi", "mo", "mn", "ms", "mtext", "annotation-xml", "foreignObject", "desc", "title"]), Ra = new Set(["svg", "math"]);
function Pa(t, e) { var a; e.xmlMode === "foreign" && (t.name = (a = br.get(t.name)) !== null && a !== void 0 ? a : t.name, t.parent && Ua.has(t.parent.name) && (e = It(wt({}, e), { xmlMode: !1 }))), !e.xmlMode && Ra.has(t.name) && (e = It(wt({}, e), { xmlMode: "foreign" })); var n = "<".concat(t.name), s = Oa(t.attribs, e); return s && (n += " ".concat(s)), t.children.length === 0 && (e.xmlMode ? e.selfClosingTags !== !1 : e.selfClosingTags && xr.has(t.name)) ? (e.xmlMode || (n += " "), n += "/>") : (n += ">", t.children.length > 0 && (n += yu(t.children, e)), (e.xmlMode || !xr.has(t.name)) && (n += "</".concat(t.name, ">"))), n; }
function Ba(t) { return "<".concat(t.data, ">"); }
function Ha(t, e) { var a; var n = t.data || ""; return ((a = e.encodeEntities) !== null && a !== void 0 ? a : e.decodeEntities) !== !1 && !(!e.xmlMode && t.parent && La.has(t.parent.name)) && (n = e.xmlMode || e.encodeEntities !== "utf8" ? be(n) : Le(n)), n; }
function _a(t) { return "<![CDATA[".concat(t.children[0].data, "]]>"); }
function Ma(t) { return "<!--".concat(t.data, "-->"); }
function yr(t, e) { return ue(t, e); }
function Fa(t, e) { return nt(t) ? t.children.map(function (a) { return yr(a, e); }).join("") : ""; }
function qe(t) {
    return Array.isArray(t) ? t.map(qe).join("") : P(t) ? t.name === "br" ? "\n" : qe(t.children) : te(t) ? qe(t.children) : St(t) ? t.data : "";
}
function Dt(t) { return Array.isArray(t) ? t.map(Dt).join("") : nt(t) && !ge(t) ? Dt(t.children) : St(t) ? t.data : ""; }
function vu(t) { return Array.isArray(t) ? t.map(vu).join("") : nt(t) && (t.type === U.Tag || te(t)) ? vu(t.children) : St(t) ? t.data : ""; }
function Oe(t) { return nt(t) ? t.children : []; }
function vr(t) { return t.parent || null; }
function De(t) {
    var _b, _c;
    var e = vr(t);
    if (e != null)
        return Oe(e);
    var a = [t], n = t.prev, s = t.next;
    for (; n != null;)
        a.unshift(n), _b = n, n = _b.prev;
    for (; s != null;)
        a.push(s), _c = s, s = _c.next;
    return a;
}
function Ia(t, e) { var a; return (a = t.attribs) === null || a === void 0 ? void 0 : a[e]; }
function Va(t, e) { return t.attribs != null && Object.prototype.hasOwnProperty.call(t.attribs, e) && t.attribs[e] != null; }
function Ga(t) { return t.name; }
function wu(t) {
    var _b;
    var e = t.next;
    for (; e !== null && !P(e);)
        (_b = e, e = _b.next);
    return e;
}
function Su(t) {
    var _b;
    var e = t.prev;
    for (; e !== null && !P(e);)
        (_b = e, e = _b.prev);
    return e;
}
function Ct(t) { if (t.prev && (t.prev.next = t.next), t.next && (t.next.prev = t.prev), t.parent) {
    var e = t.parent.children, a = e.lastIndexOf(t);
    a >= 0 && e.splice(a, 1);
} t.next = null, t.prev = null, t.parent = null; }
function ja(t, e) { var a = e.prev = t.prev; a && (a.next = e); var n = e.next = t.next; n && (n.prev = e); var s = e.parent = t.parent; if (s) {
    var o = s.children;
    o[o.lastIndexOf(t)] = e, t.parent = null;
} }
function za(t, e) { if (Ct(e), e.next = null, e.parent = t, t.children.push(e) > 1) {
    var a = t.children[t.children.length - 2];
    a.next = e, e.prev = a;
}
else
    e.prev = null; }
function $a(t, e) { Ct(e); var a = t.parent, n = t.next; if (e.next = n, e.prev = t, t.next = e, e.parent = a, n) {
    if (n.prev = e, a) {
        var s = a.children;
        s.splice(s.lastIndexOf(n), 0, e);
    }
}
else
    a && a.children.push(e); }
function Qa(t, e) { if (Ct(e), e.parent = t, e.prev = null, t.children.unshift(e) !== 1) {
    var a = t.children[1];
    a.prev = e, e.next = a;
}
else
    e.next = null; }
function Tu(t, e) { Ct(e); var a = t.parent; if (a) {
    var n = a.children;
    n.splice(n.indexOf(t), 0, e);
} t.prev && (t.prev.next = e), e.parent = a, e.prev = t.prev, e.next = t, t.prev = e; }
function re(t, e, a, n) {
    if (a === void 0) { a = !0; }
    if (n === void 0) { n = 1 / 0; }
    return Ue(t, Array.isArray(e) ? e : [e], a, n);
}
function Ue(t, e, a, n) { var s = [], o = [Array.isArray(e) ? e : [e]], f = [0]; for (;;) {
    if (f[0] >= o[0].length) {
        if (f.length === 1)
            return s;
        o.shift(), f.shift();
        continue;
    }
    var h = o[0][f[0]++];
    if (t(h) && (s.push(h), --n <= 0))
        return s;
    a && nt(h) && h.children.length > 0 && (f.unshift(0), o.unshift(h.children));
} }
function Wa(t, e) { return e.find(t); }
function Re(t, e, a) {
    if (a === void 0) { a = !0; }
    var n = Array.isArray(e) ? e : [e];
    for (var s = 0; s < n.length; s++) {
        var o = n[s];
        if (P(o) && t(o))
            return o;
        if (a && nt(o) && o.children.length > 0) {
            var f = Re(t, o.children, !0);
            if (f)
                return f;
        }
    }
    return null;
}
function wr(t, e) { return (Array.isArray(e) ? e : [e]).some(function (a) { return P(a) && t(a) || nt(a) && wr(t, a.children); }); }
function Xa(t, e) { var a = [], n = [Array.isArray(e) ? e : [e]], s = [0]; for (;;) {
    if (s[0] >= n[0].length) {
        if (n.length === 1)
            return a;
        n.shift(), s.shift();
        continue;
    }
    var o = n[0][s[0]++];
    P(o) && t(o) && a.push(o), nt(o) && o.children.length > 0 && (s.unshift(0), n.unshift(o.children));
} }
var Pe = { tag_name: function (t) { return typeof t == "function" ? function (e) { return P(e) && t(e.name); } : t === "*" ? P : function (e) { return P(e) && e.name === t; }; }, tag_type: function (t) { return typeof t == "function" ? function (e) { return t(e.type); } : function (e) { return e.type === t; }; }, tag_contains: function (t) { return typeof t == "function" ? function (e) { return St(e) && t(e.data); } : function (e) { return St(e) && e.data === t; }; } };
function Au(t, e) { return typeof e == "function" ? function (a) { return P(a) && e(a.attribs[t]); } : function (a) { return P(a) && a.attribs[t] === e; }; }
function Ja(t, e) { return function (a) { return t(a) || e(a); }; }
function Sr(t) { var e = Object.keys(t).map(function (a) { var n = t[a]; return Object.prototype.hasOwnProperty.call(Pe, a) ? Pe[a](n) : Au(a, n); }); return e.length === 0 ? null : e.reduce(Ja); }
function Za(t, e) { var a = Sr(t); return a ? a(e) : !0; }
function Ka(t, e, a, n) {
    if (n === void 0) { n = 1 / 0; }
    var s = Sr(t);
    return s ? re(s, e, a, n) : [];
}
function Ya(t, e, a) {
    if (a === void 0) { a = !0; }
    return Array.isArray(e) || (e = [e]), Re(Au("id", t), e, a);
}
function Gt(t, e, a, n) {
    if (a === void 0) { a = !0; }
    if (n === void 0) { n = 1 / 0; }
    return re(Pe.tag_name(t), e, a, n);
}
function tn(t, e, a, n) {
    if (a === void 0) { a = !0; }
    if (n === void 0) { n = 1 / 0; }
    return re(Au("class", t), e, a, n);
}
function en(t, e, a, n) {
    if (a === void 0) { a = !0; }
    if (n === void 0) { n = 1 / 0; }
    return re(Pe.tag_type(t), e, a, n);
}
function un(t) { var e = t.length; for (; --e >= 0;) {
    var a = t[e];
    if (e > 0 && t.lastIndexOf(a, e - 1) >= 0) {
        t.splice(e, 1);
        continue;
    }
    for (var n = a.parent; n; n = n.parent)
        if (t.includes(n)) {
            t.splice(e, 1);
            break;
        }
} return t; }
var yt;
(function (t) { t[t.DISCONNECTED = 1] = "DISCONNECTED", t[t.PRECEDING = 2] = "PRECEDING", t[t.FOLLOWING = 4] = "FOLLOWING", t[t.CONTAINS = 8] = "CONTAINS", t[t.CONTAINED_BY = 16] = "CONTAINED_BY"; })(yt || (yt = {}));
function Tr(t, e) { var a = [], n = []; if (t === e)
    return 0; var s = nt(t) ? t : t.parent; for (; s;)
    a.unshift(s), s = s.parent; for (s = nt(e) ? e : e.parent; s;)
    n.unshift(s), s = s.parent; var o = Math.min(a.length, n.length), f = 0; for (; f < o && a[f] === n[f];)
    f++; if (f === 0)
    return yt.DISCONNECTED; var h = a[f - 1], p = h.children, m = a[f], v = n[f]; return p.indexOf(m) > p.indexOf(v) ? h === e ? yt.FOLLOWING | yt.CONTAINED_BY : yt.FOLLOWING : h === t ? yt.PRECEDING | yt.CONTAINS : yt.PRECEDING; }
function Eu(t) { return t = t.filter(function (e, a, n) { return !n.includes(e, a + 1); }), t.sort(function (e, a) { var n = Tr(e, a); return n & yt.PRECEDING ? -1 : n & yt.FOLLOWING ? 1 : 0; }), t; }
function Cu(t) { var e = Be(cn, t); return e ? e.name === "feed" ? rn(e) : an(e) : null; }
function rn(t) { var e; var a = t.children, n = { type: "atom", items: Gt("entry", a).map(function (f) { var h; var p = f.children, m = { media: Ar(p) }; lt(m, "id", "id", p), lt(m, "title", "title", p); var v = (h = Be("link", p)) === null || h === void 0 ? void 0 : h.attribs.href; v && (m.link = v); var k = Ut("summary", p) || Ut("content", p); k && (m.description = k); var T = Ut("updated", p); return T && (m.pubDate = new Date(T)), m; }) }; lt(n, "id", "id", a), lt(n, "title", "title", a); var s = (e = Be("link", a)) === null || e === void 0 ? void 0 : e.attribs.href; s && (n.link = s), lt(n, "description", "subtitle", a); var o = Ut("updated", a); return o && (n.updated = new Date(o)), lt(n, "author", "email", a, !0), n; }
function an(t) { var e, a; var n = (a = (e = Be("channel", t.children)) === null || e === void 0 ? void 0 : e.children) !== null && a !== void 0 ? a : [], s = { type: t.name.substr(0, 3), id: "", items: Gt("item", t.children).map(function (f) { var h = f.children, p = { media: Ar(h) }; lt(p, "id", "guid", h), lt(p, "title", "title", h), lt(p, "link", "link", h), lt(p, "description", "description", h); var m = Ut("pubDate", h) || Ut("dc:date", h); return m && (p.pubDate = new Date(m)), p; }) }; lt(s, "title", "title", n), lt(s, "link", "link", n), lt(s, "description", "description", n); var o = Ut("lastBuildDate", n); return o && (s.updated = new Date(o)), lt(s, "author", "managingEditor", n, !0), s; }
var nn = ["url", "type", "lang"], sn = ["fileSize", "bitrate", "framerate", "samplingrate", "channels", "duration", "height", "width"];
function Ar(t) { return Gt("media:content", t).map(function (e) {
    var e_4, _b, e_5, _c;
    var a = e.attribs, n = { medium: a.medium, isDefault: !!a.isDefault };
    try {
        for (var nn_1 = __values(nn), nn_1_1 = nn_1.next(); !nn_1_1.done; nn_1_1 = nn_1.next()) {
            var s = nn_1_1.value;
            a[s] && (n[s] = a[s]);
        }
    }
    catch (e_4_1) { e_4 = { error: e_4_1 }; }
    finally {
        try {
            if (nn_1_1 && !nn_1_1.done && (_b = nn_1.return)) _b.call(nn_1);
        }
        finally { if (e_4) throw e_4.error; }
    }
    try {
        for (var sn_1 = __values(sn), sn_1_1 = sn_1.next(); !sn_1_1.done; sn_1_1 = sn_1.next()) {
            var s = sn_1_1.value;
            a[s] && (n[s] = parseInt(a[s], 10));
        }
    }
    catch (e_5_1) { e_5 = { error: e_5_1 }; }
    finally {
        try {
            if (sn_1_1 && !sn_1_1.done && (_c = sn_1.return)) _c.call(sn_1);
        }
        finally { if (e_5) throw e_5.error; }
    }
    return a.expression && (n.expression = a.expression), n;
}); }
function Be(t, e) { return Gt(t, e, !0, 1)[0]; }
function Ut(t, e, a) {
    if (a === void 0) { a = !1; }
    return Dt(Gt(t, e, a, 1)).trim();
}
function lt(t, e, a, n, s) {
    if (s === void 0) { s = !1; }
    var o = Ut(a, n, s);
    o && (t[e] = o);
}
function cn(t) { return t === "rss" || t === "feed" || t === "rdf:RDF"; }
function Er(t, e) { var a = new ee(void 0, e); return new ce(a, e).end(t), a.root; }
var E;
(function (t) { t.Attribute = "attribute", t.Pseudo = "pseudo", t.PseudoElement = "pseudo-element", t.Tag = "tag", t.Universal = "universal", t.Adjacent = "adjacent", t.Child = "child", t.Descendant = "descendant", t.Parent = "parent", t.Sibling = "sibling", t.ColumnCombinator = "column-combinator"; })(E || (E = {}));
var V;
(function (t) { t.Any = "any", t.Element = "element", t.End = "end", t.Equals = "equals", t.Exists = "exists", t.Hyphen = "hyphen", t.Not = "not", t.Start = "start"; })(V || (V = {}));
var Cr = /^[^\\#]?(?:\\(?:[\da-f]{1,6}\s?|.)|[\w\-\u00b0-\uFFFF])+/, on = /\\([\da-f]{1,6}\s?|(\s)|.)/gi, ln = new Map([[126, V.Element], [94, V.Start], [36, V.End], [42, V.Any], [33, V.Not], [124, V.Hyphen]]), fn = new Set(["has", "not", "matches", "is", "where", "host", "host-context"]);
function jt(t) { switch (t.type) {
    case E.Adjacent:
    case E.Child:
    case E.Descendant:
    case E.Parent:
    case E.Sibling:
    case E.ColumnCombinator: return !0;
    default: return !1;
} }
var dn = new Set(["contains", "icontains"]);
function hn(t, e, a) { var n = parseInt(e, 16) - 65536; return n !== n || a ? e : n < 0 ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, n & 1023 | 56320); }
function me(t) { return t.replace(on, hn); }
function Nu(t) { return t === 39 || t === 34; }
function Nr(t) { return t === 32 || t === 9 || t === 10 || t === 12 || t === 13; }
function Rt(t) { var e = [], a = kr(e, "".concat(t), 0); if (a < t.length)
    throw new Error("Unmatched selector: ".concat(t.slice(a))); return e; }
function kr(t, e, a) { var n = []; function s(T) { var A = e.slice(a + T).match(Cr); if (!A)
    throw new Error("Expected name, found ".concat(e.slice(a))); var _b = __read(A, 1), L = _b[0]; return a += T + L.length, me(L); } function o(T) { for (a += T; a < e.length && Nr(e.charCodeAt(a));)
    a++; } function f() { a += 1; var T = a, A = 1; for (; A > 0 && a < e.length; a++)
    e.charCodeAt(a) === 40 && !h(a) ? A++ : e.charCodeAt(a) === 41 && !h(a) && A--; if (A)
    throw new Error("Parenthesis not matched"); return me(e.slice(T, a - 1)); } function h(T) { var A = 0; for (; e.charCodeAt(--T) === 92;)
    A++; return (A & 1) === 1; } function p() { if (n.length > 0 && jt(n[n.length - 1]))
    throw new Error("Did not expect successive traversals."); } function m(T) { if (n.length > 0 && n[n.length - 1].type === E.Descendant) {
    n[n.length - 1].type = T;
    return;
} p(), n.push({ type: T }); } function v(T, A) { n.push({ type: E.Attribute, name: T, action: A, value: s(1), namespace: null, ignoreCase: "quirks" }); } function k() { if (n.length && n[n.length - 1].type === E.Descendant && n.pop(), n.length === 0)
    throw new Error("Empty sub-selector"); t.push(n); } if (o(0), e.length === a)
    return a; t: for (; a < e.length;) {
    var T = e.charCodeAt(a);
    switch (T) {
        case 32:
        case 9:
        case 10:
        case 12:
        case 13: {
            (n.length === 0 || n[0].type !== E.Descendant) && (p(), n.push({ type: E.Descendant })), o(1);
            break;
        }
        case 62: {
            m(E.Child), o(1);
            break;
        }
        case 60: {
            m(E.Parent), o(1);
            break;
        }
        case 126: {
            m(E.Sibling), o(1);
            break;
        }
        case 43: {
            m(E.Adjacent), o(1);
            break;
        }
        case 46: {
            v("class", V.Element);
            break;
        }
        case 35: {
            v("id", V.Equals);
            break;
        }
        case 91: {
            o(1);
            var A = void 0, L = null;
            e.charCodeAt(a) === 124 ? A = s(1) : e.startsWith("*|", a) ? (L = "*", A = s(2)) : (A = s(0), e.charCodeAt(a) === 124 && e.charCodeAt(a + 1) !== 61 && (L = A, A = s(1))), o(0);
            var D = V.Exists, it = ln.get(e.charCodeAt(a));
            if (it) {
                if (D = it, e.charCodeAt(a + 1) !== 61)
                    throw new Error("Expected `=`");
                o(2);
            }
            else
                e.charCodeAt(a) === 61 && (D = V.Equals, o(1));
            var ct = "", x = null;
            if (D !== "exists") {
                if (Nu(e.charCodeAt(a))) {
                    var w = e.charCodeAt(a), g = a + 1;
                    for (; g < e.length && (e.charCodeAt(g) !== w || h(g));)
                        g += 1;
                    if (e.charCodeAt(g) !== w)
                        throw new Error("Attribute value didn't end");
                    ct = me(e.slice(a + 1, g)), a = g + 1;
                }
                else {
                    var w = a;
                    for (; a < e.length && (!Nr(e.charCodeAt(a)) && e.charCodeAt(a) !== 93 || h(a));)
                        a += 1;
                    ct = me(e.slice(w, a));
                }
                o(0);
                var H = e.charCodeAt(a) | 32;
                H === 115 ? (x = !1, o(1)) : H === 105 && (x = !0, o(1));
            }
            if (e.charCodeAt(a) !== 93)
                throw new Error("Attribute selector didn't terminate");
            a += 1;
            var ut = { type: E.Attribute, name: A, action: D, value: ct, namespace: L, ignoreCase: x };
            n.push(ut);
            break;
        }
        case 58: {
            if (e.charCodeAt(a + 1) === 58) {
                n.push({ type: E.PseudoElement, name: s(2).toLowerCase(), data: e.charCodeAt(a) === 40 ? f() : null });
                continue;
            }
            var A = s(1).toLowerCase(), L = null;
            if (e.charCodeAt(a) === 40)
                if (fn.has(A)) {
                    if (Nu(e.charCodeAt(a + 1)))
                        throw new Error("Pseudo-selector ".concat(A, " cannot be quoted"));
                    if (L = [], a = kr(L, e, a + 1), e.charCodeAt(a) !== 41)
                        throw new Error("Missing closing parenthesis in :".concat(A, " (").concat(e, ")"));
                    a += 1;
                }
                else {
                    if (L = f(), dn.has(A)) {
                        var D = L.charCodeAt(0);
                        D === L.charCodeAt(L.length - 1) && Nu(D) && (L = L.slice(1, -1));
                    }
                    L = me(L);
                }
            n.push({ type: E.Pseudo, name: A, data: L });
            break;
        }
        case 44: {
            k(), n = [], o(1);
            break;
        }
        default: {
            if (e.startsWith("/*", a)) {
                var D = e.indexOf("*/", a + 2);
                if (D < 0)
                    throw new Error("Comment was not terminated");
                a = D + 2, n.length === 0 && o(0);
                break;
            }
            var A = null, L = void 0;
            if (T === 42)
                a += 1, L = "*";
            else if (T === 124) {
                if (L = "", e.charCodeAt(a + 1) === 124) {
                    m(E.ColumnCombinator), o(2);
                    break;
                }
            }
            else if (Cr.test(e.slice(a)))
                L = s(0);
            else
                break t;
            e.charCodeAt(a) === 124 && e.charCodeAt(a + 1) !== 124 && (A = L, e.charCodeAt(a + 1) === 42 ? (L = "*", a += 2) : L = s(1)), n.push(L === "*" ? { type: E.Universal, namespace: A } : { type: E.Tag, name: L, namespace: A });
        }
    }
} return k(), a; }
var _u = Vt(Pt(), 1);
var Nt = Vt(Pt(), 1);
var qr = new Map([[E.Universal, 50], [E.Tag, 30], [E.Attribute, 1], [E.Pseudo, 0]]);
function xe(t) { return !qr.has(t.type); }
var pn = new Map([[V.Exists, 10], [V.Equals, 8], [V.Not, 7], [V.Start, 6], [V.End, 6], [V.Any, 5]]);
function ku(t) { var e = t.map(Or); for (var a = 1; a < t.length; a++) {
    var n = e[a];
    if (!(n < 0))
        for (var s = a - 1; s >= 0 && n < e[s]; s--) {
            var o = t[s + 1];
            t[s + 1] = t[s], t[s] = o, e[s + 1] = e[s], e[s] = n;
        }
} }
function Or(t) { var e, a; var n = (e = qr.get(t.type)) !== null && e !== void 0 ? e : -1; return t.type === E.Attribute ? (n = (a = pn.get(t.action)) !== null && a !== void 0 ? a : 4, t.action === V.Equals && t.name === "id" && (n = 9), t.ignoreCase && (n >>= 1)) : t.type === E.Pseudo && (t.data ? t.name === "has" || t.name === "contains" ? n = 0 : Array.isArray(t.data) ? (n = Math.min.apply(Math, __spreadArray([], __read(t.data.map(function (s) { return Math.min.apply(Math, __spreadArray([], __read(s.map(Or)), false)); })), false)), n < 0 && (n = 0)) : n = 2 : n = 3), n; }
var ye = Vt(Pt(), 1), gn = /[-[\]{}()*+?.,\\^$|#\s]/g;
function Dr(t) { return t.replace(gn, "\\$&"); }
var bn = new Set(["accept", "accept-charset", "align", "alink", "axis", "bgcolor", "charset", "checked", "clear", "codetype", "color", "compact", "declare", "defer", "dir", "direction", "disabled", "enctype", "face", "frame", "hreflang", "http-equiv", "lang", "language", "link", "media", "method", "multiple", "nohref", "noresize", "noshade", "nowrap", "readonly", "rel", "rev", "rules", "scope", "scrolling", "selected", "shape", "target", "text", "type", "valign", "valuetype", "vlink"]);
function zt(t, e) { return typeof t.ignoreCase == "boolean" ? t.ignoreCase : t.ignoreCase === "quirks" ? !!e.quirksMode : !e.xmlMode && bn.has(t.name); }
var Ur = { equals: function (t, e, a) { var n = a.adapter, s = e.name, o = e.value; return zt(e, a) ? (o = o.toLowerCase(), function (f) { var h = n.getAttributeValue(f, s); return h != null && h.length === o.length && h.toLowerCase() === o && t(f); }) : function (f) { return n.getAttributeValue(f, s) === o && t(f); }; }, hyphen: function (t, e, a) { var n = a.adapter, s = e.name, o = e.value, f = o.length; return zt(e, a) ? (o = o.toLowerCase(), function (p) { var m = n.getAttributeValue(p, s); return m != null && (m.length === f || m.charAt(f) === "-") && m.substr(0, f).toLowerCase() === o && t(p); }) : function (p) { var m = n.getAttributeValue(p, s); return m != null && (m.length === f || m.charAt(f) === "-") && m.substr(0, f) === o && t(p); }; }, element: function (t, e, a) { var n = a.adapter, s = e.name, o = e.value; if (/\s/.test(o))
        return ye.default.falseFunc; var f = new RegExp("(?:^|\\s)".concat(Dr(o), "(?:$|\\s)"), zt(e, a) ? "i" : ""); return function (p) { var m = n.getAttributeValue(p, s); return m != null && m.length >= o.length && f.test(m) && t(p); }; }, exists: function (t, _b, _c) {
        var e = _b.name;
        var a = _c.adapter;
        return function (n) { return a.hasAttrib(n, e) && t(n); };
    }, start: function (t, e, a) { var n = a.adapter, s = e.name, o = e.value, f = o.length; return f === 0 ? ye.default.falseFunc : zt(e, a) ? (o = o.toLowerCase(), function (h) { var p = n.getAttributeValue(h, s); return p != null && p.length >= f && p.substr(0, f).toLowerCase() === o && t(h); }) : function (h) { var p; return !!(!((p = n.getAttributeValue(h, s)) === null || p === void 0) && p.startsWith(o)) && t(h); }; }, end: function (t, e, a) { var n = a.adapter, s = e.name, o = e.value, f = -o.length; return f === 0 ? ye.default.falseFunc : zt(e, a) ? (o = o.toLowerCase(), function (h) { var p; return ((p = n.getAttributeValue(h, s)) === null || p === void 0 ? void 0 : p.substr(f).toLowerCase()) === o && t(h); }) : function (h) { var p; return !!(!((p = n.getAttributeValue(h, s)) === null || p === void 0) && p.endsWith(o)) && t(h); }; }, any: function (t, e, a) { var n = a.adapter, s = e.name, o = e.value; if (o === "")
        return ye.default.falseFunc; if (zt(e, a)) {
        var f_1 = new RegExp(Dr(o), "i");
        return function (p) { var m = n.getAttributeValue(p, s); return m != null && m.length >= o.length && f_1.test(m) && t(p); };
    } return function (f) { var h; return !!(!((h = n.getAttributeValue(f, s)) === null || h === void 0) && h.includes(o)) && t(f); }; }, not: function (t, e, a) { var n = a.adapter, s = e.name, o = e.value; return o === "" ? function (f) { return !!n.getAttributeValue(f, s) && t(f); } : zt(e, a) ? (o = o.toLowerCase(), function (f) { var h = n.getAttributeValue(f, s); return (h == null || h.length !== o.length || h.toLowerCase() !== o) && t(f); }) : function (f) { return n.getAttributeValue(f, s) !== o && t(f); }; } };
var mn = new Set([9, 10, 12, 13, 32]), Rr = 48, xn = 57;
function Pr(t) { if (t = t.trim().toLowerCase(), t === "even")
    return [2, 0]; if (t === "odd")
    return [2, 1]; var e = 0, a = 0, n = o(), s = f(); if (e < t.length && t.charAt(e) === "n" && (e++, a = n * (s != null ? s : 1), h(), e < t.length ? (n = o(), h(), s = f()) : n = s = 0), s === null || e < t.length)
    throw new Error("n-th rule couldn't be parsed ('".concat(t, "')")); return [a, n * s]; function o() { return t.charAt(e) === "-" ? (e++, -1) : (t.charAt(e) === "+" && e++, 1); } function f() { var p = e, m = 0; for (; e < t.length && t.charCodeAt(e) >= Rr && t.charCodeAt(e) <= xn;)
    m = m * 10 + (t.charCodeAt(e) - Rr), e++; return e === p ? null : m; } function h() { for (; e < t.length && mn.has(t.charCodeAt(e));)
    e++; } }
var Lu = Vt(Pt(), 1);
function Br(t) { var e = t[0], a = t[1] - 1; if (a < 0 && e <= 0)
    return Lu.default.falseFunc; if (e === -1)
    return function (o) { return o <= a; }; if (e === 0)
    return function (o) { return o === a; }; if (e === 1)
    return a < 0 ? Lu.default.trueFunc : function (o) { return o >= a; }; var n = Math.abs(e), s = (a % n + n) % n; return e > 1 ? function (o) { return o >= a && o % n === s; } : function (o) { return o <= a && o % n === s; }; }
function ae(t) { return Br(Pr(t)); }
var ft = Vt(Pt(), 1);
function He(t, e) { return function (a) { var n = e.getParent(a); return n != null && e.isTag(n) && t(a); }; }
var ne = { contains: function (t, e, _b) {
        var a = _b.adapter;
        return function (s) { return t(s) && a.getText(s).includes(e); };
    }, icontains: function (t, e, _b) {
        var a = _b.adapter;
        var n = e.toLowerCase();
        return function (o) { return t(o) && a.getText(o).toLowerCase().includes(n); };
    }, "nth-child": function (t, e, _b) {
        var a = _b.adapter, n = _b.equals;
        var s = ae(e);
        return s === ft.default.falseFunc ? ft.default.falseFunc : s === ft.default.trueFunc ? He(t, a) : function (f) { var h = a.getSiblings(f), p = 0; for (var m = 0; m < h.length && !n(f, h[m]); m++)
            a.isTag(h[m]) && p++; return s(p) && t(f); };
    }, "nth-last-child": function (t, e, _b) {
        var a = _b.adapter, n = _b.equals;
        var s = ae(e);
        return s === ft.default.falseFunc ? ft.default.falseFunc : s === ft.default.trueFunc ? He(t, a) : function (f) { var h = a.getSiblings(f), p = 0; for (var m = h.length - 1; m >= 0 && !n(f, h[m]); m--)
            a.isTag(h[m]) && p++; return s(p) && t(f); };
    }, "nth-of-type": function (t, e, _b) {
        var a = _b.adapter, n = _b.equals;
        var s = ae(e);
        return s === ft.default.falseFunc ? ft.default.falseFunc : s === ft.default.trueFunc ? He(t, a) : function (f) { var h = a.getSiblings(f), p = 0; for (var m = 0; m < h.length; m++) {
            var v = h[m];
            if (n(f, v))
                break;
            a.isTag(v) && a.getName(v) === a.getName(f) && p++;
        } return s(p) && t(f); };
    }, "nth-last-of-type": function (t, e, _b) {
        var a = _b.adapter, n = _b.equals;
        var s = ae(e);
        return s === ft.default.falseFunc ? ft.default.falseFunc : s === ft.default.trueFunc ? He(t, a) : function (f) { var h = a.getSiblings(f), p = 0; for (var m = h.length - 1; m >= 0; m--) {
            var v = h[m];
            if (n(f, v))
                break;
            a.isTag(v) && a.getName(v) === a.getName(f) && p++;
        } return s(p) && t(f); };
    }, root: function (t, e, _b) {
        var a = _b.adapter;
        return function (n) { var s = a.getParent(n); return (s == null || !a.isTag(s)) && t(n); };
    }, scope: function (t, e, a, n) { var s = a.equals; return !n || n.length === 0 ? ne.root(t, e, a) : n.length === 1 ? function (o) { return s(n[0], o) && t(o); } : function (o) { return n.includes(o) && t(o); }; }, hover: qu("isHovered"), visited: qu("isVisited"), active: qu("isActive") };
function qu(t) { return function (a, n, _b) {
    var s = _b.adapter;
    var o = s[t];
    return typeof o != "function" ? ft.default.falseFunc : function (h) { return o(h) && a(h); };
}; }
var ve = { empty: function (t, _b) {
        var e = _b.adapter;
        return !e.getChildren(t).some(function (a) { return e.isTag(a) || e.getText(a) !== ""; });
    }, "first-child": function (t, _b) {
        var e = _b.adapter, a = _b.equals;
        if (e.prevElementSibling)
            return e.prevElementSibling(t) == null;
        var n = e.getSiblings(t).find(function (s) { return e.isTag(s); });
        return n != null && a(t, n);
    }, "last-child": function (t, _b) {
        var e = _b.adapter, a = _b.equals;
        var n = e.getSiblings(t);
        for (var s = n.length - 1; s >= 0; s--) {
            if (a(t, n[s]))
                return !0;
            if (e.isTag(n[s]))
                break;
        }
        return !1;
    }, "first-of-type": function (t, _b) {
        var e = _b.adapter, a = _b.equals;
        var n = e.getSiblings(t), s = e.getName(t);
        for (var o = 0; o < n.length; o++) {
            var f = n[o];
            if (a(t, f))
                return !0;
            if (e.isTag(f) && e.getName(f) === s)
                break;
        }
        return !1;
    }, "last-of-type": function (t, _b) {
        var e = _b.adapter, a = _b.equals;
        var n = e.getSiblings(t), s = e.getName(t);
        for (var o = n.length - 1; o >= 0; o--) {
            var f = n[o];
            if (a(t, f))
                return !0;
            if (e.isTag(f) && e.getName(f) === s)
                break;
        }
        return !1;
    }, "only-of-type": function (t, _b) {
        var e = _b.adapter, a = _b.equals;
        var n = e.getName(t);
        return e.getSiblings(t).every(function (s) { return a(t, s) || !e.isTag(s) || e.getName(s) !== n; });
    }, "only-child": function (t, _b) {
        var e = _b.adapter, a = _b.equals;
        return e.getSiblings(t).every(function (n) { return a(t, n) || !e.isTag(n); });
    } };
function Ou(t, e, a, n) { if (a === null) {
    if (t.length > n)
        throw new Error("Pseudo-class :".concat(e, " requires an argument"));
}
else if (t.length === n)
    throw new Error("Pseudo-class :".concat(e, " doesn't have any arguments")); }
var _e = { "any-link": ":is(a, area, link)[href]", link: ":any-link:not(:visited)", disabled: ":is(\n        :is(button, input, select, textarea, optgroup, option)[disabled],\n        optgroup[disabled] > option,\n        fieldset[disabled]:not(fieldset[disabled] legend:first-of-type *)\n    )", enabled: ":not(:disabled)", checked: ":is(:is(input[type=radio], input[type=checkbox])[checked], option:selected)", required: ":is(input, select, textarea)[required]", optional: ":is(input, select, textarea):not([required])", selected: "option:is([selected], select:not([multiple]):not(:has(> option[selected])) > :first-of-type)", checkbox: "[type=checkbox]", file: "[type=file]", password: "[type=password]", radio: "[type=radio]", reset: "[type=reset]", image: "[type=image]", submit: "[type=submit]", parent: ":not(:empty)", header: ":is(h1, h2, h3, h4, h5, h6)", button: ":is(button, input[type=button])", input: ":is(input, textarea, select, button)", text: "input:is(:not([type!='']), [type=text])" };
var vt = Vt(Pt(), 1);
var Ru = {};
function Pu(t, e) { return t === vt.default.falseFunc ? vt.default.falseFunc : function (a) { return e.isTag(a) && t(a); }; }
function Bu(t, e) { var a = e.getSiblings(t); if (a.length <= 1)
    return []; var n = a.indexOf(t); return n < 0 || n === a.length - 1 ? [] : a.slice(n + 1).filter(e.isTag); }
function Uu(t) { return { xmlMode: !!t.xmlMode, lowerCaseAttributeNames: !!t.lowerCaseAttributeNames, lowerCaseTags: !!t.lowerCaseTags, quirksMode: !!t.quirksMode, cacheResults: !!t.cacheResults, pseudos: t.pseudos, adapter: t.adapter, equals: t.equals }; }
var Du = function (t, e, a, n, s) { var o = s(e, Uu(a), n); return o === vt.default.trueFunc ? t : o === vt.default.falseFunc ? vt.default.falseFunc : function (f) { return o(f) && t(f); }; }, Me = { is: Du, matches: Du, where: Du, not: function (t, e, a, n, s) { var o = s(e, Uu(a), n); return o === vt.default.falseFunc ? t : o === vt.default.trueFunc ? vt.default.falseFunc : function (f) { return !o(f) && t(f); }; }, has: function (t, e, a, n, s) { var o = a.adapter, f = Uu(a); f.relativeSelector = !0; var h = e.some(function (v) { return v.some(xe); }) ? [Ru] : void 0, p = s(e, f, h); if (p === vt.default.falseFunc)
        return vt.default.falseFunc; var m = Pu(p, o); if (h && p !== vt.default.trueFunc) {
        var _b = p.shouldTestNextSiblings, v_1 = _b === void 0 ? !1 : _b;
        return function (k) { if (!t(k))
            return !1; h[0] = k; var T = o.getChildren(k), A = v_1 ? __spreadArray(__spreadArray([], __read(T), false), __read(Bu(k, o)), false) : T; return o.existsOne(m, A); };
    } return function (v) { return t(v) && o.existsOne(m, o.getChildren(v)); }; } };
function Hr(t, e, a, n, s) { var o; var f = e.name, h = e.data; if (Array.isArray(h)) {
    if (!(f in Me))
        throw new Error("Unknown pseudo-class :".concat(f, "(").concat(h, ")"));
    return Me[f](t, h, a, n, s);
} var p = (o = a.pseudos) === null || o === void 0 ? void 0 : o[f], m = typeof p == "string" ? p : _e[f]; if (typeof m == "string") {
    if (h != null)
        throw new Error("Pseudo ".concat(f, " doesn't have any arguments"));
    var v = Rt(m);
    return Me.is(t, v, a, n, s);
} if (typeof p == "function")
    return Ou(p, f, h, 1), function (v) { return p(v, h) && t(v); }; if (f in ne)
    return ne[f](t, h, a, n); if (f in ve) {
    var v_2 = ve[f];
    return Ou(v_2, f, h, 2), function (k) { return v_2(k, a, h) && t(k); };
} throw new Error("Unknown pseudo-class :".concat(f)); }
function Hu(t, e) { var a = e.getParent(t); return a && e.isTag(a) ? a : null; }
function _r(t, e, a, n, s) { var o = a.adapter, f = a.equals; switch (e.type) {
    case E.PseudoElement: throw new Error("Pseudo-elements are not supported by css-select");
    case E.ColumnCombinator: throw new Error("Column combinators are not yet supported by css-select");
    case E.Attribute: {
        if (e.namespace != null)
            throw new Error("Namespaced attributes are not yet supported by css-select");
        return (!a.xmlMode || a.lowerCaseAttributeNames) && (e.name = e.name.toLowerCase()), Ur[e.action](t, e, a);
    }
    case E.Pseudo: return Hr(t, e, a, n, s);
    case E.Tag: {
        if (e.namespace != null)
            throw new Error("Namespaced tag names are not yet supported by css-select");
        var h_1 = e.name;
        return (!a.xmlMode || a.lowerCaseTags) && (h_1 = h_1.toLowerCase()), function (m) { return o.getName(m) === h_1 && t(m); };
    }
    case E.Descendant: {
        if (a.cacheResults === !1 || typeof WeakSet == "undefined")
            return function (m) { var v = m; for (; v = Hu(v, o);)
                if (t(v))
                    return !0; return !1; };
        var h_2 = new WeakSet;
        return function (m) { var v = m; for (; v = Hu(v, o);)
            if (!h_2.has(v)) {
                if (o.isTag(v) && t(v))
                    return !0;
                h_2.add(v);
            } return !1; };
    }
    case "_flexibleDescendant": return function (p) { var m = p; do
        if (t(m))
            return !0;
    while (m = Hu(m, o)); return !1; };
    case E.Parent: return function (p) { return o.getChildren(p).some(function (m) { return o.isTag(m) && t(m); }); };
    case E.Child: return function (p) { var m = o.getParent(p); return m != null && o.isTag(m) && t(m); };
    case E.Sibling: return function (p) { var m = o.getSiblings(p); for (var v = 0; v < m.length; v++) {
        var k = m[v];
        if (f(p, k))
            break;
        if (o.isTag(k) && t(k))
            return !0;
    } return !1; };
    case E.Adjacent: return o.prevElementSibling ? function (p) { var m = o.prevElementSibling(p); return m != null && t(m); } : function (p) { var m = o.getSiblings(p), v; for (var k = 0; k < m.length; k++) {
        var T = m[k];
        if (f(p, T))
            break;
        o.isTag(T) && (v = T);
    } return !!v && t(v); };
    case E.Universal: {
        if (e.namespace != null && e.namespace !== "*")
            throw new Error("Namespaced universal selectors are not yet supported by css-select");
        return t;
    }
} }
function Mr(t, e, a) { var n = Fe(t, e, a); return Pu(n, e.adapter); }
function Fe(t, e, a) { var n = typeof t == "string" ? Rt(t) : t; return Ie(n, e, a); }
function Fr(t) { return t.type === E.Pseudo && (t.name === "scope" || Array.isArray(t.data) && t.data.some(function (e) { return e.some(Fr); })); }
var yn = { type: E.Descendant }, vn = { type: "_flexibleDescendant" }, wn = { type: E.Pseudo, name: "scope", data: null };
function Sn(t, _b, a) {
    var e_6, _c;
    var e = _b.adapter;
    var n = !!(a != null && a.every(function (s) { var o = e.isTag(s) && e.getParent(s); return s === Ru || o && e.isTag(o); }));
    try {
        for (var t_1 = __values(t), t_1_1 = t_1.next(); !t_1_1.done; t_1_1 = t_1.next()) {
            var s = t_1_1.value;
            if (!(s.length > 0 && xe(s[0]) && s[0].type !== E.Descendant))
                if (n && !s.some(Fr))
                    s.unshift(yn);
                else
                    continue;
            s.unshift(wn);
        }
    }
    catch (e_6_1) { e_6 = { error: e_6_1 }; }
    finally {
        try {
            if (t_1_1 && !t_1_1.done && (_c = t_1.return)) _c.call(t_1);
        }
        finally { if (e_6) throw e_6.error; }
    }
}
function Ie(t, e, a) { var n; t.forEach(ku), a = (n = e.context) !== null && n !== void 0 ? n : a; var s = Array.isArray(a), o = a && (Array.isArray(a) ? a : [a]); if (e.relativeSelector !== !1)
    Sn(t, e, o);
else if (t.some(function (p) { return p.length > 0 && xe(p[0]); }))
    throw new Error("Relative selectors are not allowed when the `relativeSelector` option is disabled"); var f = !1, h = t.map(function (p) { if (p.length >= 2) {
    var _b = __read(p, 2), m = _b[0], v = _b[1];
    m.type !== E.Pseudo || m.name !== "scope" || (s && v.type === E.Descendant ? p[1] = vn : (v.type === E.Adjacent || v.type === E.Sibling) && (f = !0));
} return Tn(p, e, o); }).reduce(An, Nt.default.falseFunc); return h.shouldTestNextSiblings = f, h; }
function Tn(t, e, a) { var n; return t.reduce(function (s, o) { return s === Nt.default.falseFunc ? Nt.default.falseFunc : _r(s, o, e, a, Ie); }, (n = e.rootFunc) !== null && n !== void 0 ? n : Nt.default.trueFunc); }
function An(t, e) { return e === Nt.default.falseFunc || t === Nt.default.trueFunc ? t : t === Nt.default.falseFunc || e === Nt.default.trueFunc ? e : function (n) { return t(n) || e(n); }; }
var Ir = function (t, e) { return t === e; }, En = { adapter: Tt, equals: Ir };
function Vr(t) { var e, a, n, s; var o = t != null ? t : En; return (e = o.adapter) !== null && e !== void 0 || (o.adapter = Tt), (a = o.equals) !== null && a !== void 0 || (o.equals = (s = (n = o.adapter) === null || n === void 0 ? void 0 : n.equals) !== null && s !== void 0 ? s : Ir), o; }
function Mu(t) { return function (a, n, s) { var o = Vr(n); return t(a, o, s); }; }
var Wi = Mu(Mr), Xi = Mu(Fe), Ve = Mu(Ie);
function Gr(t) { return function (a, n, s) { var o = Vr(s); typeof a != "function" && (a = Fe(a, o, n)); var f = Ge(n, o.adapter, a.shouldTestNextSiblings); return t(a, f, o); }; }
function Ge(t, e, a) {
    if (a === void 0) { a = !1; }
    return a && (t = Cn(t, e)), Array.isArray(t) ? e.removeSubsets(t) : e.getChildren(t);
}
function Cn(t, e) { var a = Array.isArray(t) ? t.slice(0) : [t], n = a.length; for (var s = 0; s < n; s++) {
    var o = Bu(a[s], e);
    a.push.apply(a, __spreadArray([], __read(o), false));
} return a; }
var Ji = Gr(function (t, e, a) { return t === _u.default.falseFunc || !e || e.length === 0 ? [] : a.adapter.findAll(t, e); }), Zi = Gr(function (t, e, a) { return t === _u.default.falseFunc || !e || e.length === 0 ? null : a.adapter.findOne(t, e); });
var ze = Vt(Pt(), 1);
var Nn = new Set(["first", "last", "eq", "gt", "nth", "lt", "even", "odd"]);
function ie(t) { return t.type !== "pseudo" ? !1 : Nn.has(t.name) ? !0 : t.name === "not" && Array.isArray(t.data) ? t.data.some(function (e) { return e.some(ie); }) : !1; }
function jr(t, e, a) { var n = e != null ? parseInt(e, 10) : NaN; switch (t) {
    case "first": return 1;
    case "nth":
    case "eq": return isFinite(n) ? n >= 0 ? n + 1 : 1 / 0 : 0;
    case "lt": return isFinite(n) ? n >= 0 ? Math.min(n, a) : 1 / 0 : 0;
    case "gt": return isFinite(n) ? 1 / 0 : 0;
    case "odd": return 2 * a;
    case "even": return 2 * a - 1;
    case "last":
    case "not": return 1 / 0;
} }
function zr(t) { for (; t.parent;)
    t = t.parent; return t; }
function je(t) {
    var e_7, _b;
    var e = [], a = [];
    try {
        for (var t_2 = __values(t), t_2_1 = t_2.next(); !t_2_1.done; t_2_1 = t_2.next()) {
            var n = t_2_1.value;
            n.some(ie) ? e.push(n) : a.push(n);
        }
    }
    catch (e_7_1) { e_7 = { error: e_7_1 }; }
    finally {
        try {
            if (t_2_1 && !t_2_1.done && (_b = t_2.return)) _b.call(t_2);
        }
        finally { if (e_7) throw e_7.error; }
    }
    return [a, e];
}
var kn = { type: E.Universal, namespace: null }, Ln = { type: E.Pseudo, name: "scope", data: null };
function Vu(t, e, a) {
    if (a === void 0) { a = {}; }
    return qn([t], e, a);
}
function qn(t, e, a) {
    if (a === void 0) { a = {}; }
    if (typeof e == "function")
        return t.some(e);
    var _b = __read(je(Rt(e)), 2), n = _b[0], s = _b[1];
    return n.length > 0 && t.some(Ve(n, a)) || s.some(function (o) { return $r(o, t, a).length > 0; });
}
function On(t, e, a, n) { var s = typeof a == "string" ? parseInt(a, 10) : NaN; switch (t) {
    case "first":
    case "lt": return e;
    case "last": return e.length > 0 ? [e[e.length - 1]] : e;
    case "nth":
    case "eq": return isFinite(s) && Math.abs(s) < e.length ? [s < 0 ? e[e.length + s] : e[s]] : [];
    case "gt": return isFinite(s) ? e.slice(s + 1) : [];
    case "even": return e.filter(function (o, f) { return f % 2 === 0; });
    case "odd": return e.filter(function (o, f) { return f % 2 === 1; });
    case "not": {
        var o_1 = new Set(Dn(a, e, n));
        return e.filter(function (f) { return !o_1.has(f); });
    }
} }
function Dn(t, e, a) { if (e.length === 0)
    return []; var _b = __read(je(t), 2), n = _b[0], s = _b[1], o; if (n.length) {
    var f = Iu(e, n, a);
    if (s.length === 0)
        return f;
    f.length && (o = new Set(f));
} for (var f = 0; f < s.length && (o == null ? void 0 : o.size) !== e.length; f++) {
    var h = s[f];
    if ((o ? e.filter(function (v) { return P(v) && !o.has(v); }) : e).length === 0)
        break;
    var m = $r(h, e, a);
    if (m.length)
        if (o)
            m.forEach(function (v) { return o.add(v); });
        else {
            if (f === s.length - 1)
                return m;
            o = new Set(m);
        }
} return typeof o != "undefined" ? o.size === e.length ? e : e.filter(function (f) { return o.has(f); }) : []; }
function $r(t, e, a) { var n; if (t.some(jt)) {
    var s = (n = a.root) !== null && n !== void 0 ? n : zr(e[0]), o = It(wt({}, a), { context: e, relativeSelector: !1 });
    return t.push(Ln), $e(s, t, o, !0, e.length);
} return $e(e, t, a, !1, e.length); }
function Gu(t, e, a, n) {
    if (a === void 0) { a = {}; }
    if (n === void 0) { n = 1 / 0; }
    if (typeof t == "function")
        return Qr(e, t);
    var _b = __read(je(Rt(t)), 2), s = _b[0], o = _b[1], f = o.map(function (h) { return $e(e, h, a, !0, n); });
    return s.length && f.push(Fu(e, s, a, n)), f.length === 0 ? [] : f.length === 1 ? f[0] : Eu(f.reduce(function (h, p) { return __spreadArray(__spreadArray([], __read(h), false), __read(p), false); }));
}
function $e(t, e, a, n, s) { var o = e.findIndex(ie), f = e.slice(0, o), h = e[o], p = e.length - 1 === o ? s : 1 / 0, m = jr(h.name, h.data, p); if (m === 0)
    return []; var k = (f.length === 0 && !Array.isArray(t) ? Oe(t).filter(P) : f.length === 0 ? (Array.isArray(t) ? t : [t]).filter(P) : n || f.some(jt) ? Fu(t, [f], a, m) : Iu(t, [f], a)).slice(0, m), T = On(h.name, k, h.data, a); if (T.length === 0 || e.length === o + 1)
    return T; var A = e.slice(o + 1), L = A.some(jt); if (L) {
    if (jt(A[0])) {
        var D = A[0].type;
        (D === E.Sibling || D === E.Adjacent) && (T = Ge(T, Tt, !0)), A.unshift(kn);
    }
    a = It(wt({}, a), { relativeSelector: !1, rootFunc: function (D) { return T.includes(D); } });
}
else
    a.rootFunc && a.rootFunc !== ze.trueFunc && (a = It(wt({}, a), { rootFunc: ze.trueFunc })); return A.some(ie) ? $e(T, A, a, !1, s) : L ? Fu(T, [A], a, s) : Iu(T, [A], a); }
function Fu(t, e, a, n) { var s = Ve(e, a, t); return Qr(t, s, n); }
function Qr(t, e, a) {
    if (a === void 0) { a = 1 / 0; }
    var n = Ge(t, Tt, e.shouldTestNextSiblings);
    return Ue(function (s) { return P(s) && e(s); }, n, !0, a);
}
function Iu(t, e, a) { var n = (Array.isArray(t) ? t : [t]).filter(P); if (n.length === 0)
    return n; var s = Ve(e, a); return s === ze.trueFunc ? n : n.filter(s); }
var Un = function (t, e, a) { return Gu(t, e, a); }, Zr = function (t, e, a) { return Gu(t, e, a, 1)[0] || null; }, Kr = /[\s ]+/g, Wr = new Set(["p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "table", "section", "article", "header", "footer", "blockquote", "pre", "dd", "dt", "hr"]), Rn = { containsOwn: function (t, e) { return zu(t).toLowerCase().includes(String(e).toLowerCase()); }, matches: function (t, e) { return Xr(e).test(ju(t)); }, matchesOwn: function (t, e) { return Xr(e).test(zu(t)); }, containsData: function (t, e) { return Dt(t).includes(e); }, "contains-ci": function (t, e) { return ju(t).toLowerCase().includes(String(e).toLowerCase()); } };
function Xr(t) { try {
    return new RegExp(t);
}
catch (e) {
    return /$^/;
} }
var Qe = { pseudos: Rn, xmlMode: !1, lowerCaseTags: !0 };
function We(t) { return String(t).replace(/:contains\(/g, ":contains-ci(").replace(/:eq\((\d+)\)/g, ":eq($1)"); }
function ju(t) { if (!t)
    return ""; if (t.type === "text")
    return t.data; var e = "", a = function (n) {
    var e_8, _b;
    try {
        for (var _c = __values(n.children || []), _d = _c.next(); !_d.done; _d = _c.next()) {
            var s = _d.value;
            s.type === "text" ? e += s.data : (s.type === "tag" || s.type === "script" || s.type === "style") && (s.name === "br" ? e += " " : s.type === "tag" && (Wr.has(s.name) && (e += " "), a(s), Wr.has(s.name) && (e += " ")));
        }
    }
    catch (e_8_1) { e_8 = { error: e_8_1 }; }
    finally {
        try {
            if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
        }
        finally { if (e_8) throw e_8.error; }
    }
}; return a(t), e.replace(Kr, " ").trim(); }
function zu(t) {
    var e_9, _b;
    var e = "";
    try {
        for (var _c = __values(t.children || []), _d = _c.next(); !_d.done; _d = _c.next()) {
            var a = _d.value;
            a.type === "text" && (e += a.data);
        }
    }
    catch (e_9_1) { e_9 = { error: e_9_1 }; }
    finally {
        try {
            if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
        }
        finally { if (e_9) throw e_9.error; }
    }
    return e.replace(Kr, " ").trim();
}
function Yr(t, e) { if (!e)
    return ""; try {
    return new URL(e, t || void 0).href;
}
catch (a) {
    return t ? "" : e;
} }
var $t = (function () {
    function t(e, a) {
        this.node = e, this.doc = a;
    }
    Object.defineProperty(t.prototype, "baseUri", {
        get: function () { return this.doc ? this.doc.__base : ""; },
        enumerable: false,
        configurable: true
    });
    t.prototype.select = function (e) { return At.of(Un(We(e), this.node, Qe), this.doc); };
    t.prototype.selectFirst = function (e) { var a = Zr(We(e), this.node, Qe); return a ? new t(a, this.doc) : null; };
    t.prototype.is = function (e) { return Vu(this.node, We(e), Qe); };
    t.prototype.text = function () { return ju(this.node); };
    t.prototype.ownText = function () { return zu(this.node); };
    t.prototype.wholeText = function () { return Dt(this.node); };
    t.prototype.data = function () { return (this.node.children || []).filter(function (e) { return e.type === "text"; }).map(function (e) { return e.data; }).join(""); };
    t.prototype.html = function () { return (this.node.children || []).map(function (e) { return ue(e, { decodeEntities: !1 }); }).join("").trim(); };
    t.prototype.outerHtml = function () { return ue(this.node, { decodeEntities: !1 }); };
    t.prototype.toString = function () { return this.outerHtml(); };
    t.prototype.tagName = function () { return this.node.name || ""; };
    t.prototype.nodeName = function () { return this.node.name || "#" + this.node.type; };
    t.prototype.id = function () { return this.attr("id"); };
    t.prototype.className = function () { return this.attr("class"); };
    t.prototype.classNames = function () { return this.className().split(/\s+/).filter(Boolean); };
    t.prototype.hasClass = function (e) { return this.classNames().includes(e); };
    t.prototype.attr = function (e, a) { if (a !== void 0)
        return this.node.attribs && (this.node.attribs[e] = String(a)), this; if (!this.node.attribs)
        return ""; if (e.startsWith("abs:"))
        return Yr(this.baseUri, this.node.attribs[e.slice(4)] || ""); var n = this.node.attribs[e]; return n == null ? "" : n; };
    t.prototype.absUrl = function (e) { return this.attr("abs:" + e); };
    t.prototype.hasAttr = function (e) { return !!(this.node.attribs && (e.startsWith("abs:") ? e.slice(4) : e) in this.node.attribs); };
    t.prototype.removeAttr = function (e) { return this.node.attribs && delete this.node.attribs[e], this; };
    t.prototype.attributes = function () { return Object.assign({}, this.node.attribs || {}); };
    t.prototype.dataset = function () {
        var e_10, _b;
        var e = {};
        try {
            for (var _c = __values(Object.entries(this.node.attribs || {})), _d = _c.next(); !_d.done; _d = _c.next()) {
                var _f = __read(_d.value, 2), a = _f[0], n = _f[1];
                a.startsWith("data-") && (e[a.slice(5)] = n);
            }
        }
        catch (e_10_1) { e_10 = { error: e_10_1 }; }
        finally {
            try {
                if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
            }
            finally { if (e_10) throw e_10.error; }
        }
        return e;
    };
    t.prototype.val = function () { return this.attr("value"); };
    t.prototype.parent = function () { var e = this.node.parent; return e && e.type !== "root" ? new t(e, this.doc) : null; };
    t.prototype.parents = function () { var e = [], a = this.node.parent; for (; a && a.type !== "root";)
        e.push(a), a = a.parent; return At.of(e, this.doc); };
    t.prototype.closest = function (e) { var a = this.node; for (; a && a.type !== "root";) {
        if (a.type === "tag" && Vu(a, We(e), Qe))
            return new t(a, this.doc);
        a = a.parent;
    } return null; };
    t.prototype.children = function () { return At.of((this.node.children || []).filter(P), this.doc); };
    t.prototype.child = function (e) { var a = (this.node.children || []).filter(P)[e]; return a ? new t(a, this.doc) : null; };
    t.prototype.childrenSize = function () { return (this.node.children || []).filter(P).length; };
    t.prototype.nextElementSibling = function () { var e = wu(this.node); return e ? new t(e, this.doc) : null; };
    t.prototype.previousElementSibling = function () { var e = Su(this.node); return e ? new t(e, this.doc) : null; };
    t.prototype.siblingElements = function () {
        var _this = this;
        return At.of(De(this.node).filter(function (e) { return e !== _this.node && P(e); }), this.doc);
    };
    t.prototype.elementSiblingIndex = function () { return De(this.node).filter(P).indexOf(this.node); };
    t.prototype.getElementsByTag = function (e) { return this.select(e); };
    t.prototype.getElementsByClass = function (e) { return this.select("." + e); };
    t.prototype.getElementById = function (e) { return this.selectFirst("#" + e); };
    t.prototype.remove = function () { return Ct(this.node), this; };
    t.prototype.empty = function () { return this.node.children = [], this; };
    t.prototype.textNodes = function () { return (this.node.children || []).filter(function (e) { return e.type === "text"; }).map(function (e) { return ({ text: function () { return e.data; }, toString: function () { return e.data; } }); }); };
    t.prototype.title = function () { var e = this.selectFirst("title"); return e ? e.text() : ""; };
    t.prototype.body = function () { return this.selectFirst("body") || this; };
    t.prototype.head = function () { return this.selectFirst("head") || this; };
    t.prototype.location = function () { return this.baseUri; };
    return t;
}()), Qu = Object.create(Array.prototype), At = { of: $u, prototype: Qu };
function $u(t, e) {
    var e_11, _b;
    var a = [];
    try {
        for (var _c = __values(t || []), _d = _c.next(); !_d.done; _d = _c.next()) {
            var n = _d.value;
            a.push(n instanceof $t ? n : new $t(n, e));
        }
    }
    catch (e_11_1) { e_11 = { error: e_11_1 }; }
    finally {
        try {
            if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
        }
        finally { if (e_11) throw e_11.error; }
    }
    return Object.setPrototypeOf(a, Qu), a;
}
var Jr = { size: function () { return this.length; }, isEmpty: function () { return this.length === 0; }, get: function (t) { return this[t] || null; }, first: function () { return this[0] || null; }, last: function () { return this[this.length - 1] || null; }, eq: function (t) { return At.of(this[t] ? [this[t]] : [], null); }, text: function () { return this.map(function (t) { return t.text(); }).filter(Boolean).join(" "); }, eachText: function () { return this.map(function (t) { return t.text(); }).filter(Boolean); }, html: function () {
        return this.map(function (t) { return t.html(); }).join("\n");
    }, outerHtml: function () {
        return this.map(function (t) { return t.outerHtml(); }).join("\n");
    }, toString: function () { return this.outerHtml(); }, attr: function (t, e) {
        var e_12, _b;
        if (e !== void 0)
            return this.forEach(function (a) { return a.attr(t, e); }), this;
        try {
            for (var _c = __values(this), _d = _c.next(); !_d.done; _d = _c.next()) {
                var a = _d.value;
                if (a.hasAttr(t))
                    return a.attr(t);
            }
        }
        catch (e_12_1) { e_12 = { error: e_12_1 }; }
        finally {
            try {
                if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
            }
            finally { if (e_12) throw e_12.error; }
        }
        return "";
    }, eachAttr: function (t) { return this.filter(function (e) { return e.hasAttr(t); }).map(function (e) { return e.attr(t); }); }, hasAttr: function (t) { return this.some(function (e) { return e.hasAttr(t); }); }, hasClass: function (t) { return this.some(function (e) { return e.hasClass(t); }); }, val: function () { return this.length ? this[0].val() : ""; }, select: function (t) {
        var e_13, _b, e_14, _c;
        var e = $u([]), a = new Set;
        try {
            for (var _d = __values(this), _f = _d.next(); !_f.done; _f = _d.next()) {
                var n = _f.value;
                try {
                    for (var _g = (e_14 = void 0, __values(n.select(t))), _h = _g.next(); !_h.done; _h = _g.next()) {
                        var s = _h.value;
                        a.has(s.node) || (a.add(s.node), e.push(s));
                    }
                }
                catch (e_14_1) { e_14 = { error: e_14_1 }; }
                finally {
                    try {
                        if (_h && !_h.done && (_c = _g.return)) _c.call(_g);
                    }
                    finally { if (e_14) throw e_14.error; }
                }
            }
        }
        catch (e_13_1) { e_13 = { error: e_13_1 }; }
        finally {
            try {
                if (_f && !_f.done && (_b = _d.return)) _b.call(_d);
            }
            finally { if (e_13) throw e_13.error; }
        }
        return e;
    }, selectFirst: function (t) {
        var e_15, _b;
        try {
            for (var _c = __values(this), _d = _c.next(); !_d.done; _d = _c.next()) {
                var e = _d.value;
                var a = e.selectFirst(t);
                if (a)
                    return a;
            }
        }
        catch (e_15_1) { e_15 = { error: e_15_1 }; }
        finally {
            try {
                if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
            }
            finally { if (e_15) throw e_15.error; }
        }
        return null;
    }, is: function (t) { return this.some(function (e) { return e.is(t); }); }, not: function (t) { return At.of(this.filter(function (e) { return !e.is(t); }), null); }, parents: function () {
        var e_16, _b;
        var t = $u([]);
        try {
            for (var _c = __values(this), _d = _c.next(); !_d.done; _d = _c.next()) {
                var e = _d.value;
                t.push.apply(t, __spreadArray([], __read(e.parents()), false));
            }
        }
        catch (e_16_1) { e_16 = { error: e_16_1 }; }
        finally {
            try {
                if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
            }
            finally { if (e_16) throw e_16.error; }
        }
        return t;
    }, next: function () { return At.of(this.map(function (t) { return t.nextElementSibling(); }).filter(Boolean), null); }, prev: function () { return At.of(this.map(function (t) { return t.previousElementSibling(); }).filter(Boolean), null); }, remove: function () { return this.forEach(function (t) { return t.remove(); }), this; }, empty: function () { return this.forEach(function (t) { return t.empty(); }), this; }, removeAttr: function (t) { return this.forEach(function (e) { return e.removeAttr(t); }), this; } };
try {
    for (var _c = __values(Object.keys(Jr)), _d = _c.next(); !_d.done; _d = _c.next()) {
        var t = _d.value;
        Object.defineProperty(Qu, t, { value: Jr[t], writable: !0, configurable: !0 });
    }
}
catch (e_1_1) { e_1 = { error: e_1_1 }; }
finally {
    try {
        if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
    }
    finally { if (e_1) throw e_1.error; }
}
function Xe(t, e) { var a = Er(String(t == null ? "" : t), { decodeEntities: !0, lowerCaseAttributeNames: !0 }), n = new $t(a, null); n.doc = n, n.__base = e || ""; var s = Zr("base[href]", a); return s && s.attribs.href && (n.__base = Yr(n.__base, s.attribs.href)), n; }
function ta(t, e) { var a = new Set((e || ["p", "br", "b", "i", "em", "strong", "img", "div", "span"]).map(String)), n = Xe(t), s = function (o) {
    var e_17, _b, e_18, _c;
    try {
        for (var _d = __values((o.children || []).slice()), _f = _d.next(); !_f.done; _f = _d.next()) {
            var f = _f.value;
            if (f.type === "script" || f.type === "style" || f.type === "comment") {
                Ct(f);
                continue;
            }
            if (f.type === "tag" && (s(f), !a.has(f.name))) {
                var h = (f.children || []).slice();
                try {
                    for (var h_3 = (e_18 = void 0, __values(h)), h_3_1 = h_3.next(); !h_3_1.done; h_3_1 = h_3.next()) {
                        var p = h_3_1.value;
                        Tu(f, p);
                    }
                }
                catch (e_18_1) { e_18 = { error: e_18_1 }; }
                finally {
                    try {
                        if (h_3_1 && !h_3_1.done && (_c = h_3.return)) _c.call(h_3);
                    }
                    finally { if (e_18) throw e_18.error; }
                }
                Ct(f);
            }
        }
    }
    catch (e_17_1) { e_17 = { error: e_17_1 }; }
    finally {
        try {
            if (_f && !_f.done && (_b = _d.return)) _b.call(_d);
        }
        finally { if (e_17) throw e_17.error; }
    }
}; return s(n.node), ue(n.node.children, { decodeEntities: !1 }); }
var Je = "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36";
function Pn(t) { if (typeof Buffer != "undefined")
    return Buffer.from(t).toString("base64"); var e = ""; for (var a = 0; a < t.length; a++)
    e += String.fromCharCode(t[a]); return btoa(e); }
function ea(t) { return typeof TextEncoder != "undefined" ? new TextEncoder().encode(t) : Uint8Array.from(unescape(encodeURIComponent(t)), function (e) { return e.charCodeAt(0); }); }
var Wu = (function () {
    function Wu(e, a) {
        this.status = e.status | 0, this.ok = this.status >= 200 && this.status < 300, this.statusText = e.statusText || String(this.status), this.url = e.url || a.url, this.headers = e.headers || {}, this._raw = e, this.request = { url: a.url, headers: a.headers || {} };
    }
    Wu.prototype.header = function (e) { var a = Object.keys(this.headers).find(function (n) { return n.toLowerCase() === String(e).toLowerCase(); }); return a ? this.headers[a] : ""; };
    Wu.prototype.text = function (e) { if (e && this._raw.bytes && typeof TextDecoder != "undefined")
        try {
            return new TextDecoder(String(e).toLowerCase()).decode(this._raw.bytes);
        }
        catch (a) { } return this._raw.text == null ? "" : String(this._raw.text); };
    Wu.prototype.string = function (e) { return this.text(e); };
    Wu.prototype.html = function (e) { return Xe(this.text(e), this.url); };
    Wu.prototype.json = function () { try {
        return JSON.parse(this.text());
    }
    catch (e) {
        return null;
    } };
    Wu.prototype.base64 = function () { return Pn(this._raw.bytes || ea(this.text())); };
    Wu.prototype.blob = function () { var e = this; return { size: (this._raw.bytes || ea(this.text())).length, type: this.header("content-type"), base64: function () { return e.base64(); } }; };
    return Wu;
}());
function Bn(t) {
    var e_19, _b;
    var e = {};
    if (!t)
        return e;
    if (typeof t.forEach == "function" && !Array.isArray(t) && typeof t.entries == "function")
        return t.forEach(function (a, n) { e[n] = a; }), e;
    try {
        for (var _c = __values(Object.keys(t)), _d = _c.next(); !_d.done; _d = _c.next()) {
            var a = _d.value;
            e[a] = String(t[a]);
        }
    }
    catch (e_19_1) { e_19 = { error: e_19_1 }; }
    finally {
        try {
            if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
        }
        finally { if (e_19) throw e_19.error; }
    }
    return e;
}
function ra(t, e) { var a = function (f) { return ({ getItem: function (h) { var p = t.storageGet(f + h); return p == null ? null : p; }, setItem: function (h, p) { return t.storageSet(f + h, p == null ? null : String(p)); }, removeItem: function (h) { return t.storageSet(f + h, null); }, clear: function () { return t.storageClear && t.storageClear(f); } }); }, n = "__cookie__", s = {}; s.Response = { success: function (f, h) { return ({ code: 0, data: f === void 0 ? null : f, data2: h === void 0 ? null : h }); }, error: function (f) { return ({ code: 1, data: f == null ? "" : String(f) }); } }, s.fetch = function (h, p) {
    return __awaiter(this, void 0, void 0, function () { var m, D, v, k, T, D, A, L, D_1; return __generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                p = p || {};
                m = String(h);
                if (p.queries) {
                    D = Object.entries(p.queries).map(function (_b) {
                        var _c = __read(_b, 2), it = _c[0], ct = _c[1];
                        return encodeURIComponent(it) + "=" + encodeURIComponent(ct);
                    }).join("&");
                    D && (m += (m.includes("?") ? "&" : "?") + D);
                }
                v = Object.assign({ "User-Agent": Je }, Bn(p.headers)), k = t.storageGet(n);
                k && !Object.keys(v).some(function (D) { return D.toLowerCase() === "cookie"; }) && (v.Cookie = k);
                T = p.body;
                if (T != null && typeof T == "object") {
                    D = Object.keys(v).find(function (it) { return it.toLowerCase() === "content-type"; });
                    D && /json/i.test(v[D]) ? T = JSON.stringify(T) : (T = Object.entries(T).map(function (_b) {
                        var _c = __read(_b, 2), it = _c[0], ct = _c[1];
                        return encodeURIComponent(it) + "=" + encodeURIComponent(ct);
                    }).join("&"), D || (v["Content-Type"] = "application/x-www-form-urlencoded"));
                }
                A = { url: m, method: (p.method || (T != null ? "POST" : "GET")).toUpperCase(), headers: v, body: T, timeout: p.timeout };
                _b.label = 1;
            case 1:
                _b.trys.push([1, 3, , 4]);
                return [4, t.request(A)];
            case 2:
                L = _b.sent();
                return [3, 4];
            case 3:
                D_1 = _b.sent();
                L = { status: 0, url: m, headers: {}, text: "", error: String(D_1 && D_1.message || D_1) };
                return [3, 4];
            case 4: return [2, new Wu(L, A)];
        }
    }); });
}, s.Http = { get: function (f) { return ua(s, "GET", f); }, post: function (f) { return ua(s, "POST", f); } }, s.Html = { parse: function (f, h) { return Xe(f, h || ""); }, clean: function (f, h) { return ta(f, h); } }, s.localStorage = a("ls:"), s.cacheStorage = a("cs:"), s.localConfig = { getItem: function (f) { return t.config(f); } }, s.localCookie = { setCookie: function (f) { t.storageSet(n, String(f).split(";")[0]); }, getCookie: function () { return t.storageGet(n) || ""; } }, s.sleep = function (f) { return new Promise(function (h) { return setTimeout(h, Math.min(Number(f) || 0, 1e4)); }); }; var o = function () {
    var f = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        f[_i] = arguments[_i];
    }
    try {
        t.log && t.log(f.map(function (h) { return typeof h == "string" ? h : JSON.stringify(h); }).join(" "));
    }
    catch (h) { }
}; return s.Log = { log: o }, s.console = { log: o, error: o, warn: o, info: o }, s.log = o, s.UserAgent = { system: function () { return Je; }, chrome: function () { return Je; }, android: function () { return Je; }, ios: function () { return "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"; } }, s.Engine = { newBrowser: function () { throw new Error("Headless browser is not available in this app (" + (t.name || "host") + ")"); } }, s.Graphics = { createCanvas: function () { throw new Error("Graphics API is not available in this app"); }, createImage: function () { throw new Error("Graphics API is not available in this app"); } }, s.Script = { execute: function () { throw new Error("Script.execute is not available"); } }, s.Elements = At, s.Element = $t, s.__meta = e, s; }
function ua(t, e, a) { var n = { method: e, url: a, headers: {}, body: void 0, queries: void 0 }, s = { headers: function (o) { return Object.assign(n.headers, o || {}), s; }, header: function (o, f) { return n.headers[o] = f, s; }, params: function (o) { return n.queries = o, s; }, queries: function (o) { return n.queries = o, s; }, body: function (o) { return n.body = o, s; }, html: function (o) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, t.fetch(n.url, n)];
                case 1: return [2, (_b.sent()).html(o)];
            }
        }); });
    }, string: function (o) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, t.fetch(n.url, n)];
                case 1: return [2, (_b.sent()).text(o)];
            }
        }); });
    }, text: function (o) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, t.fetch(n.url, n)];
                case 1: return [2, (_b.sent()).text(o)];
            }
        }); });
    }, json: function () {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, t.fetch(n.url, n)];
                case 1: return [2, (_b.sent()).json()];
            }
        }); });
    } }; return s; }
function Qt(t, e) { if (!e)
    return ""; if (e = String(e).trim(), /^data:|^blob:/.test(e))
    return e; if (e.startsWith("//"))
    return "https:" + e; if (typeof URL == "undefined")
    return __abs(t, e); try {
    return new URL(e, t).href;
}
catch (a) {
    return e;
} }
var _ = function (t) { return t == null ? "" : String(t); }, Hn = function (t) { return t.filter(function (e, a) { return e && t.indexOf(e) === a; }); }, Ze = (function () {
    function class_1(e) {
        var a = e.meta, n = e.scripts, s = e.host;
        this.meta = a, this.host = s, this.env = e.env || ra(s, a), this.scripts = n, this.cache = {}, this.tokens = {};
    }
    Object.defineProperty(class_1.prototype, "base", {
        get: function () { return _(this.host.config("DOMAIN") || this.meta.source).replace(/\/+$/, ""); },
        enumerable: false,
        configurable: true
    });
    class_1.prototype.has = function (e) { return !!this.scripts[e]; };
    class_1.prototype.run = function (e) {
        var a = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            a[_i - 1] = arguments[_i];
        }
        return __awaiter(this, void 0, void 0, function () {
            var n, s, o, f;
            var _this = this;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        n = this.scripts[e];
                        if (!n)
                            throw new Error("script " + e + " missing");
                        s = function (h) { var p = _this.host.config(h); return p == null ? (_this.meta.configDefaults || {})[h] : p; };
                        return [4, n(this.env, s)];
                    case 1:
                        o = _b.sent();
                        if (typeof o != "function")
                            throw new Error(e + ": execute() not defined");
                        return [4, o.apply(void 0, __spreadArray([], __read(a.map(_)), false))];
                    case 2:
                        f = _b.sent();
                        if (!f)
                            throw new Error(e + ": empty result");
                        if (f.code !== 0)
                            throw new Error(e + ": " + _(f.data || "error"));
                        return [2, f];
                }
            });
        });
    };
    class_1.prototype.scriptFile = function (e) { return _(e).replace(/\.js$/, ""); };
    class_1.prototype.tabs = function () {
        return __awaiter(this, void 0, void 0, function () { var e, _b, a_1, a_2; return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    if (this.cache.tabs)
                        return [2, this.cache.tabs];
                    e = [];
                    _c.label = 1;
                case 1:
                    _c.trys.push([1, 4, , 5]);
                    _b = this.has("home");
                    if (!_b) return [3, 3];
                    return [4, this.run("home")];
                case 2:
                    _b = (e = (_c.sent()).data || []);
                    _c.label = 3;
                case 3:
                    _b;
                    return [3, 5];
                case 4:
                    a_1 = _c.sent();
                    this.host.log && this.host.log("home: " + a_1.message);
                    return [3, 5];
                case 5:
                    if (!(!e.length && this.has("genre"))) return [3, 9];
                    _c.label = 6;
                case 6:
                    _c.trys.push([6, 8, , 9]);
                    return [4, this.run("genre")];
                case 7:
                    e = ((_c.sent()).data || []).slice(0, 2);
                    return [3, 9];
                case 8:
                    a_2 = _c.sent();
                    return [3, 9];
                case 9: return [2, (this.cache.tabs = e.filter(function (a) { return a && a.script; }), this.cache.tabs)];
            }
        }); });
    };
    class_1.prototype.list = function (e, a, n) {
        return __awaiter(this, void 0, void 0, function () {
            var s, o, f, h, p;
            var _this = this;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        s = e + "|" + a;
                        n = Math.max(1, n | 0);
                        o = n === 1 ? "" : this.tokens[s + "|" + n];
                        if (n > 1 && o == null)
                            return [2, { items: [], hasNext: !1 }];
                        return [4, this.run(e, a, o)];
                    case 1:
                        f = _b.sent(), h = _(f.data2);
                        h && (this.tokens[s + "|" + (n + 1)] = h);
                        p = (f.data || []).filter(Boolean).map(function (m) { return ({ name: _(m.name).trim(), link: Qt(m.host || _this.base + "/", m.link), cover: Qt(m.host || _this.base + "/", m.cover), description: _(m.description), tag: _(m.tag) }); }).filter(function (m) { return m.name && m.link; });
                        return [2, { items: p, hasNext: !!h && p.length > 0 }];
                }
            });
        });
    };
    class_1.prototype.popular = function (e) {
        return __awaiter(this, void 0, void 0, function () { var a; return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, this.tabs()];
                case 1:
                    a = _b.sent();
                    return [2, a[0] ? this.list(this.scriptFile(a[0].script), _(a[0].input), e) : this.search("", e)];
            }
        }); });
    };
    class_1.prototype.latest = function (e) {
        return __awaiter(this, void 0, void 0, function () { var a, n; return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, this.tabs()];
                case 1:
                    a = _b.sent(), n = a[1] || a[0];
                    return [2, n ? this.list(this.scriptFile(n.script), _(n.input), e) : this.search("", e)];
            }
        }); });
    };
    class_1.prototype.search = function (e, a) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            return [2, this.has("search") ? this.list("search", e, a) : { items: [], hasNext: !1 }];
        }); });
    };
    class_1.prototype.detail = function (e) {
        return __awaiter(this, void 0, void 0, function () { var a, n; return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, this.run("detail", e)];
                case 1:
                    a = (_b.sent()).data || {}, n = [].concat(a.genres || [], a.tags || []).map(function (s) { return typeof s == "string" ? s : s && s.title; }).filter(Boolean);
                    return [2, { name: _(a.name).trim(), cover: Qt(a.host || this.base + "/", a.cover), author: _(a.author).trim(), description: aa(_(a.description)), detail: aa(_(a.detail)), ongoing: a.ongoing !== !1 && a.ongoing !== "false", genres: Hn(n.map(function (s) { return String(s).trim(); })), url: e, format: _(a.format) }];
            }
        }); });
    };
    class_1.prototype.chapters = function (e) {
        return __awaiter(this, void 0, void 0, function () {
            var a, n, n_1, n_1_1, s, _b, _c, e_20_1, _d;
            var e_20, _f;
            var _this = this;
            return __generator(this, function (_g) {
                switch (_g.label) {
                    case 0:
                        a = [];
                        if (!(this.meta.type === "novel" && this.has("page") && this.has("toc"))) return [3, 10];
                        return [4, this.run("page", e)];
                    case 1:
                        n = (_g.sent()).data || [e];
                        _g.label = 2;
                    case 2:
                        _g.trys.push([2, 7, 8, 9]);
                        n_1 = __values(n), n_1_1 = n_1.next();
                        _g.label = 3;
                    case 3:
                        if (!!n_1_1.done) return [3, 6];
                        s = n_1_1.value;
                        _c = (_b = a).concat;
                        return [4, this.run("toc", _(s))];
                    case 4:
                        a = _c.apply(_b, [(_g.sent()).data || []]);
                        _g.label = 5;
                    case 5:
                        n_1_1 = n_1.next();
                        return [3, 3];
                    case 6: return [3, 9];
                    case 7:
                        e_20_1 = _g.sent();
                        e_20 = { error: e_20_1 };
                        return [3, 9];
                    case 8:
                        try {
                            if (n_1_1 && !n_1_1.done && (_f = n_1.return)) _f.call(n_1);
                        }
                        finally { if (e_20) throw e_20.error; }
                        return [7];
                    case 9: return [3, 13];
                    case 10:
                        _d = this.has("toc");
                        if (!_d) return [3, 12];
                        return [4, this.run("toc", e)];
                    case 11:
                        _d = (a = (_g.sent()).data || []);
                        _g.label = 12;
                    case 12:
                        _d;
                        _g.label = 13;
                    case 13: return [2, a.filter(function (n) { return n && n.url && n.type !== "section"; }).map(function (n, s) { return ({ name: _(n.name).trim() || "#" + (s + 1), url: Qt(n.host || _this.base + "/", n.url), pay: !!(n.pay || n.lock) }); })];
                }
            });
        });
    };
    class_1.prototype.pages = function (e) {
        return __awaiter(this, void 0, void 0, function () {
            var a, _b, _c;
            var _this = this;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0:
                        if (!(this.has("chap") && this.meta.type === "comic")) return [3, 2];
                        return [4, this.run("chap", e)];
                    case 1:
                        _b = a = (_d.sent()).data;
                        return [3, 6];
                    case 2:
                        if (!this.has("page")) return [3, 4];
                        return [4, this.run("page", e)];
                    case 3:
                        _c = a = (_d.sent()).data;
                        return [3, 5];
                    case 4:
                        _c = a = [e];
                        _d.label = 5;
                    case 5:
                        _b = _c;
                        _d.label = 6;
                    case 6: return [2, (_b, typeof a == "string" && (a = a.split(/[\n,]+/)), (a || []).map(function (n) { return Qt(_this.base + "/", typeof n == "string" ? n : n && (n.link || n.url || n.data)); }).filter(Boolean))];
                }
            });
        });
    };
    class_1.prototype.content = function (e) {
        return __awaiter(this, void 0, void 0, function () { var a; return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, this.run("chap", e)];
                case 1:
                    a = _b.sent();
                    return [2, { html: _(a.data), title: _(a.data2) }];
            }
        }); });
    };
    class_1.prototype.videos = function (e) {
        return __awaiter(this, void 0, void 0, function () {
            var a, s, n, a_3, a_3_1, s, o, f, f_2, f_2_1, h, o_2, e_21_1;
            var e_21, _b, e_22, _c;
            var _this = this;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0:
                        a = [{ title: "Default", data: e }];
                        if (!this.has("chap")) return [3, 2];
                        return [4, this.run("chap", e)];
                    case 1:
                        s = (_d.sent()).data;
                        Array.isArray(s) && s.length && (a = s.map(function (o) { return typeof o == "string" ? { title: "Server", data: o } : { title: _(o.title || o.name || "Server"), data: _(o.data || o.url || o.link) }; }));
                        _d.label = 2;
                    case 2:
                        n = [];
                        _d.label = 3;
                    case 3:
                        _d.trys.push([3, 10, 11, 12]);
                        a_3 = __values(a), a_3_1 = a_3.next();
                        _d.label = 4;
                    case 4:
                        if (!!a_3_1.done) return [3, 9];
                        s = a_3_1.value;
                        _d.label = 5;
                    case 5:
                        _d.trys.push([5, 7, , 8]);
                        return [4, this.run("track", s.data)];
                    case 6:
                        o = (_d.sent()).data || {}, f = Array.isArray(o) ? o : [o];
                        try {
                            for (f_2 = (e_22 = void 0, __values(f)), f_2_1 = f_2.next(); !f_2_1.done; f_2_1 = f_2.next()) {
                                h = f_2_1.value;
                                !h || !h.data || h.type !== "webview" && n.push({ url: Qt(h.host || this.base + "/", h.data), quality: s.title + (h.quality ? " " + h.quality : ""), headers: h.headers || { Referer: this.base + "/" }, subtitles: (h.subtitles || (h.subtitle ? [{ data: h.subtitle, label: "Sub" }] : [])).map(function (p) { return ({ file: Qt(_this.base + "/", p.data || p.file), label: _(p.label || p.language || "Sub") }); }), mimeType: _(h.mimeType) });
                            }
                        }
                        catch (e_22_1) { e_22 = { error: e_22_1 }; }
                        finally {
                            try {
                                if (f_2_1 && !f_2_1.done && (_c = f_2.return)) _c.call(f_2);
                            }
                            finally { if (e_22) throw e_22.error; }
                        }
                        return [3, 8];
                    case 7:
                        o_2 = _d.sent();
                        this.host.log && this.host.log("track " + s.title + ": " + o_2.message);
                        return [3, 8];
                    case 8:
                        a_3_1 = a_3.next();
                        return [3, 4];
                    case 9: return [3, 12];
                    case 10:
                        e_21_1 = _d.sent();
                        e_21 = { error: e_21_1 };
                        return [3, 12];
                    case 11:
                        try {
                            if (a_3_1 && !a_3_1.done && (_b = a_3.return)) _b.call(a_3);
                        }
                        finally { if (e_21) throw e_21.error; }
                        return [7];
                    case 12: return [2, n];
                }
            });
        });
    };
    return class_1;
}());
function aa(t) {
    return String(t).replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\n{3,}/g, "\n\n").trim();
}
var kt = { id: "mtc", name: "Mê Truyện CV", source: "https://metruyencv.xyz", type: "novel", locale: "vi_VN", nsfw: !1, version: 2, config: {}, configDefaults: {}, itemType: 2, lnId: "kiritokmn.mtc", lnIcon: "", lnVersion: "1.0.2" }, na = { book: function (t, e) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            return [2, (function (a, n, s, o, f, h, p, m, v, k, T, A, L, D, it, ct) {
                    return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0: return [4, (function () {
                                    return __awaiter(this, void 0, void 0, function () { function H(r) { return r ? /^https?:\/\//i.test(r) ? r : r.indexOf("//") === 0 ? "https:" + r : r.charAt(0) === "/" ? x + r : x + "/" + r.replace(/^\/+/, "") : ""; } function w(r) { return r ? /^https?:\/\//i.test(r) ? r.replace(/^(https?:\/\/)(www\.)?[^\/?#]+/i, x) : H(r) : x; } function g(r) { return (r || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim(); } function G(r) { try {
                                        return decodeURIComponent(r || "");
                                    }
                                    catch (u) {
                                        return r || "";
                                    } } function S(r) { return Array.isArray(r) ? r[0] : r; } function j(r) { var u = {}; try {
                                        var i = (r || "").split("?")[1] || "";
                                        if (!i)
                                            return u;
                                        i.split("&").forEach(function (c) { if (c) {
                                            var l = c.split("="), d = G(l[0]).trim(), b = G(l.slice(1).join("="));
                                            d && (u.hasOwnProperty(d) ? (Array.isArray(u[d]) || (u[d] = [u[d]]), u[d].push(b)) : u[d] = b);
                                        } });
                                    }
                                    catch (c) { } return u; } function q(r) { var u = []; return r ? (Object.keys(r).forEach(function (i) { var c = r[i]; if (c != null) {
                                        if (Array.isArray(c)) {
                                            c.forEach(function (l) { l != null && u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(l))); });
                                            return;
                                        }
                                        u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(c)));
                                    } }), u.join("&")) : ""; } function R(r) { var u = w(r || "").match(/\/truyen\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function M(r) { var u = w(r || "").match(/\/truyen\/[^\/?#]+\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function dt(r) { var u = w(r || "").match(/\/the-loai\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function I(r) { return g((r || "").replace(/-/g, " ")); } function z(r) { var u = g(r).toLowerCase(); return u ? u.indexOf("hoàn thành") === -1 && u.indexOf("hoan thanh") === -1 && u.indexOf("hoan-thanh") === -1 && u.indexOf("/trang-thai/hoan-thanh/") === -1 && u.indexOf("full") === -1 && u.indexOf(" end") === -1 && u.indexOf("đã hoàn thành") === -1 : !0; } function rt(r, u) { var i = w(r || x), c = j(i), l = { s: S(c.s), post_type: S(c.post_type) || "wp-manga" }, d = dt(i); return l.s === void 0 && (l.s = ""), d && (l["genre[]"] = d), c.hasOwnProperty("genre[]") && (l["genre[]"] = c["genre[]"]), c.hasOwnProperty("status[0]") && (l["status[0]"] = c["status[0]"]), c.hasOwnProperty("m_orderby") && (l.m_orderby = c.m_orderby), c.hasOwnProperty("author") && (l.author = c.author), c.hasOwnProperty("release") && (l.release = c.release), c.hasOwnProperty("adult") && (l.adult = c.adult), /\/trang-thai\/hoan-thanh\/?$/i.test(i) && (l["status[0]"] = "end"), !l.s && !l["genre[]"] && !l["status[0]"] && !l.m_orderby && (l.m_orderby = "latest"), u && (l.paged = String(u)), x + "/?" + q(l); } function Bt(r) { return x + "/?" + q({ s: "", post_type: "wp-manga", "genre[]": r }); } function ht(r, u) { return { title: g(r), input: rt(u, 1), script: "book.js" }; } function pt(r) { if (!r)
                                        return ""; var u = r.attr("src"); return (!u || u.indexOf("data:image") === 0) && (u = r.attr("data-src") || r.attr("data-lazy-src") || r.attr("data-original") || u), H(u); } function $(r, u, i) { var c = R(r), l = c ? x + "/truyen/" + c + "/" : w(r), d = {}; u && (d.manga_id = u), i && (i.title && (d.title = i.title), i.cover && (d.cover = i.cover), i.statusText && (d.status = i.statusText), i.latestChapterSlug && (d.latest = i.latestChapterSlug)); var b = q(d); return b ? l + "?" + b : l; } function Ht(r, u, i) { var c = typeof r == "string" ? F(r) : r, l = c.slug || R(i), d = l && u ? x + "/truyen/" + l + "/" + u + "/" : w(i), b = {}; c.mangaId && (b.manga_id = c.mangaId), c.title && (b.title = c.title), c.cover && (b.cover = c.cover), c.statusText && (b.status = c.statusText), u && (b.chapter = u); var C = q(b); return C ? d + "?" + C : d; } function F(r) { var u = w(r || ""), i = j(u); return { url: u, slug: R(u), mangaId: g(S(i.manga_id) || ""), title: g(S(i.title) || ""), cover: S(i.cover) || "", statusText: g(S(i.status) || ""), latestChapterSlug: g(S(i.latest) || ""), chapterSlug: g(S(i.chapter) || M(u)) }; } function Q(r) { var u = r.select(".post-title a, h3 a").first(); if (!u)
                                        return null; var i = r.select(".except-summary").first(), c = r.select(".latest-chap a, .font-meta.chapter a, .chapter-item a, .list-chapter a").first(), l = g(u.text()), d = w(u.attr("href")), b = r.select(".trangthai, .summary-content, .mg_status").first(), C = b ? b.select("a").last() : null, X = g((C ? C.attr("href") + " " : "") + (b ? b.text() : "")), J = []; r.select(".genres-content-search a, .genres-content a").forEach(function (Z) { var K = g(Z.text()), Y = Z.attr("href"); !K || !Y || J.push(ht(K, Y)); }); var O = { title: l, rawLink: d, slug: R(d), mangaId: g(i ? i.attr("data-manga-id") : ""), cover: pt(r.select("img").first()), descriptionHtml: i && i.html() || "", descriptionText: g(i ? i.text() : ""), statusText: X, ongoing: z(X), genres: J, latestChapterSlug: g(c ? M(c.attr("href")) || c.attr("value") : ""), latestChapterName: g(c ? c.text() : ""), latestChapterUrl: c ? w(c.attr("href")) : "", host: x }; return O.link = $(O.rawLink, O.mangaId, O), O; } function st(r) { var u = []; return r.select(".row.c-tabs-item__content").forEach(function (i) { var c = Q(i); c && u.push(c); }), u.length === 0 && r.select(".page-item-detail").forEach(function (i) { var c = Q(i); c && u.push(c); }), u; } function Lt(r) { return { name: r.title, link: r.link, cover: r.cover, author: "N/A", description: r.descriptionText, host: x }; } function qt(r) { var u = r.select("#madara_goto_page").first(); if (!u)
                                        return ""; var i = parseInt(u.attr("placeholder") || "1", 10), c = parseInt(u.attr("max") || "0", 10); return !isNaN(i) && !isNaN(c) && i < c ? String(i + 1) : ""; } function gt(r, u) { var i; for (i = 0; i < r.length; i++)
                                        if (u.mangaId && r[i].mangaId === u.mangaId)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.slug && r[i].slug === u.slug)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.title && g(r[i].title).toLowerCase() === g(u.title).toLowerCase())
                                            return r[i]; return r.length ? r[0] : null; } function bt(r, u) { var i = { url: r.url, slug: u && u.slug ? u.slug : r.slug, mangaId: u && u.mangaId ? u.mangaId : r.mangaId, title: u && u.title ? u.title : r.title || I(r.slug), cover: u && u.cover ? u.cover : r.cover, statusText: u && u.statusText ? u.statusText : r.statusText, descriptionHtml: u && u.descriptionHtml ? u.descriptionHtml : "", descriptionText: u && u.descriptionText ? u.descriptionText : "", ongoing: u ? u.ongoing : z(r.statusText), genres: u && u.genres ? u.genres : [], latestChapterSlug: u && u.latestChapterSlug ? u.latestChapterSlug : r.latestChapterSlug, latestChapterName: u && u.latestChapterName ? u.latestChapterName : "", latestChapterUrl: u && u.latestChapterUrl ? u.latestChapterUrl : "", host: x }; return i.link = $(u && u.rawLink ? u.rawLink : r.url, i.mangaId, i), i; } function _t(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    u = F(r), i = u.title || I(u.slug), c = null;
                                                    if (!i) return [3, 2];
                                                    return [4, a(x, { queries: { s: i, post_type: "wp-manga" } })];
                                                case 1:
                                                    l = _b.sent();
                                                    l && l.ok && (c = gt(st(l.html()), u));
                                                    _b.label = 2;
                                                case 2: return [2, bt(u, c)];
                                            }
                                        }); });
                                    } function Mt(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l, d; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    if (!r)
                                                        return [2, ""];
                                                    return [4, a(ut + "?" + q({ action: "get_first_chapter_content", manga_id: r }))];
                                                case 1:
                                                    u = _b.sent();
                                                    if (!u || !u.ok)
                                                        return [2, ""];
                                                    i = u.json(), c = ot(i);
                                                    if (!c)
                                                        return [2, ""];
                                                    l = s.parse(c), d = l.select("#wp-manga-current-chap").first();
                                                    return [2, g(d ? d.attr("value") : "")];
                                            }
                                        }); });
                                    } function ot(r) { return r ? typeof r == "string" ? r : r.data && typeof r.data == "string" ? r.data : r.data && r.data.content ? r.data.content : r.data && r.data.data && r.data.data.content ? r.data.data.content : r.content ? r.content : "" : ""; } function Ft(r) { return (r || "").replace(/<!--[\s\S]*?-->/g, "").replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").trim(); } function W(r, u) {
                                        return __awaiter(this, void 0, void 0, function () { var i, c, l, d; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    i = rt(r || x, u || "1");
                                                    return [4, a(i)];
                                                case 1:
                                                    c = _b.sent();
                                                    if (!c || !c.ok)
                                                        return [2, null];
                                                    l = c.html(), d = [];
                                                    return [2, (st(l).forEach(function (b) { d.push(Lt(b)); }), o.success(d, qt(l)))];
                                            }
                                        }); });
                                    } var x, ut; return __generator(this, function (_b) {
                                        x = "https://metruyencv.xyz";
                                        try {
                                            CONFIG_URL && (x = CONFIG_URL.replace(/\/+$/, ""));
                                        }
                                        catch (r) { }
                                        ut = x + "/wp-admin/admin-ajax.php";
                                        return [2, typeof W == "function" ? W : void 0];
                                    }); });
                                })()];
                            case 1: return [2, _b.sent()];
                        }
                    }); });
                })(t.fetch, t.Http, t.Html, t.Response, t.localStorage, t.cacheStorage, t.localConfig, t.localCookie, t.sleep, t.Log, t.console, t.log, t.UserAgent, t.Engine, t.Graphics, t.Script)];
        }); });
    }, detail: function (t, e) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            return [2, (function (a, n, s, o, f, h, p, m, v, k, T, A, L, D, it, ct) {
                    return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0: return [4, (function () {
                                    return __awaiter(this, void 0, void 0, function () { function H(r) { return r ? /^https?:\/\//i.test(r) ? r : r.indexOf("//") === 0 ? "https:" + r : r.charAt(0) === "/" ? x + r : x + "/" + r.replace(/^\/+/, "") : ""; } function w(r) { return r ? /^https?:\/\//i.test(r) ? r.replace(/^(https?:\/\/)(www\.)?[^\/?#]+/i, x) : H(r) : x; } function g(r) { return (r || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim(); } function G(r) { try {
                                        return decodeURIComponent(r || "");
                                    }
                                    catch (u) {
                                        return r || "";
                                    } } function S(r) { return Array.isArray(r) ? r[0] : r; } function j(r) { var u = {}; try {
                                        var i = (r || "").split("?")[1] || "";
                                        if (!i)
                                            return u;
                                        i.split("&").forEach(function (c) { if (c) {
                                            var l = c.split("="), d = G(l[0]).trim(), b = G(l.slice(1).join("="));
                                            d && (u.hasOwnProperty(d) ? (Array.isArray(u[d]) || (u[d] = [u[d]]), u[d].push(b)) : u[d] = b);
                                        } });
                                    }
                                    catch (c) { } return u; } function q(r) { var u = []; return r ? (Object.keys(r).forEach(function (i) { var c = r[i]; if (c != null) {
                                        if (Array.isArray(c)) {
                                            c.forEach(function (l) { l != null && u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(l))); });
                                            return;
                                        }
                                        u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(c)));
                                    } }), u.join("&")) : ""; } function R(r) { var u = w(r || "").match(/\/truyen\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function M(r) { var u = w(r || "").match(/\/truyen\/[^\/?#]+\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function dt(r) { var u = w(r || "").match(/\/the-loai\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function I(r) { return g((r || "").replace(/-/g, " ")); } function z(r) { var u = g(r).toLowerCase(); return u ? u.indexOf("hoàn thành") === -1 && u.indexOf("hoan thanh") === -1 && u.indexOf("hoan-thanh") === -1 && u.indexOf("/trang-thai/hoan-thanh/") === -1 && u.indexOf("full") === -1 && u.indexOf(" end") === -1 && u.indexOf("đã hoàn thành") === -1 : !0; } function rt(r, u) { var i = w(r || x), c = j(i), l = { s: S(c.s), post_type: S(c.post_type) || "wp-manga" }, d = dt(i); return l.s === void 0 && (l.s = ""), d && (l["genre[]"] = d), c.hasOwnProperty("genre[]") && (l["genre[]"] = c["genre[]"]), c.hasOwnProperty("status[0]") && (l["status[0]"] = c["status[0]"]), c.hasOwnProperty("m_orderby") && (l.m_orderby = c.m_orderby), c.hasOwnProperty("author") && (l.author = c.author), c.hasOwnProperty("release") && (l.release = c.release), c.hasOwnProperty("adult") && (l.adult = c.adult), /\/trang-thai\/hoan-thanh\/?$/i.test(i) && (l["status[0]"] = "end"), !l.s && !l["genre[]"] && !l["status[0]"] && !l.m_orderby && (l.m_orderby = "latest"), u && (l.paged = String(u)), x + "/?" + q(l); } function Bt(r) { return x + "/?" + q({ s: "", post_type: "wp-manga", "genre[]": r }); } function ht(r, u) { return { title: g(r), input: rt(u, 1), script: "book.js" }; } function pt(r) { if (!r)
                                        return ""; var u = r.attr("src"); return (!u || u.indexOf("data:image") === 0) && (u = r.attr("data-src") || r.attr("data-lazy-src") || r.attr("data-original") || u), H(u); } function $(r, u, i) { var c = R(r), l = c ? x + "/truyen/" + c + "/" : w(r), d = {}; u && (d.manga_id = u), i && (i.title && (d.title = i.title), i.cover && (d.cover = i.cover), i.statusText && (d.status = i.statusText), i.latestChapterSlug && (d.latest = i.latestChapterSlug)); var b = q(d); return b ? l + "?" + b : l; } function Ht(r, u, i) { var c = typeof r == "string" ? F(r) : r, l = c.slug || R(i), d = l && u ? x + "/truyen/" + l + "/" + u + "/" : w(i), b = {}; c.mangaId && (b.manga_id = c.mangaId), c.title && (b.title = c.title), c.cover && (b.cover = c.cover), c.statusText && (b.status = c.statusText), u && (b.chapter = u); var C = q(b); return C ? d + "?" + C : d; } function F(r) { var u = w(r || ""), i = j(u); return { url: u, slug: R(u), mangaId: g(S(i.manga_id) || ""), title: g(S(i.title) || ""), cover: S(i.cover) || "", statusText: g(S(i.status) || ""), latestChapterSlug: g(S(i.latest) || ""), chapterSlug: g(S(i.chapter) || M(u)) }; } function Q(r) { var u = r.select(".post-title a, h3 a").first(); if (!u)
                                        return null; var i = r.select(".except-summary").first(), c = r.select(".latest-chap a, .font-meta.chapter a, .chapter-item a, .list-chapter a").first(), l = g(u.text()), d = w(u.attr("href")), b = r.select(".trangthai, .summary-content, .mg_status").first(), C = b ? b.select("a").last() : null, X = g((C ? C.attr("href") + " " : "") + (b ? b.text() : "")), J = []; r.select(".genres-content-search a, .genres-content a").forEach(function (Z) { var K = g(Z.text()), Y = Z.attr("href"); !K || !Y || J.push(ht(K, Y)); }); var O = { title: l, rawLink: d, slug: R(d), mangaId: g(i ? i.attr("data-manga-id") : ""), cover: pt(r.select("img").first()), descriptionHtml: i && i.html() || "", descriptionText: g(i ? i.text() : ""), statusText: X, ongoing: z(X), genres: J, latestChapterSlug: g(c ? M(c.attr("href")) || c.attr("value") : ""), latestChapterName: g(c ? c.text() : ""), latestChapterUrl: c ? w(c.attr("href")) : "", host: x }; return O.link = $(O.rawLink, O.mangaId, O), O; } function st(r) { var u = []; return r.select(".row.c-tabs-item__content").forEach(function (i) { var c = Q(i); c && u.push(c); }), u.length === 0 && r.select(".page-item-detail").forEach(function (i) { var c = Q(i); c && u.push(c); }), u; } function Lt(r) { return { name: r.title, link: r.link, cover: r.cover, author: "N/A", description: r.descriptionText, host: x }; } function qt(r) { var u = r.select("#madara_goto_page").first(); if (!u)
                                        return ""; var i = parseInt(u.attr("placeholder") || "1", 10), c = parseInt(u.attr("max") || "0", 10); return !isNaN(i) && !isNaN(c) && i < c ? String(i + 1) : ""; } function gt(r, u) { var i; for (i = 0; i < r.length; i++)
                                        if (u.mangaId && r[i].mangaId === u.mangaId)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.slug && r[i].slug === u.slug)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.title && g(r[i].title).toLowerCase() === g(u.title).toLowerCase())
                                            return r[i]; return r.length ? r[0] : null; } function bt(r, u) { var i = { url: r.url, slug: u && u.slug ? u.slug : r.slug, mangaId: u && u.mangaId ? u.mangaId : r.mangaId, title: u && u.title ? u.title : r.title || I(r.slug), cover: u && u.cover ? u.cover : r.cover, statusText: u && u.statusText ? u.statusText : r.statusText, descriptionHtml: u && u.descriptionHtml ? u.descriptionHtml : "", descriptionText: u && u.descriptionText ? u.descriptionText : "", ongoing: u ? u.ongoing : z(r.statusText), genres: u && u.genres ? u.genres : [], latestChapterSlug: u && u.latestChapterSlug ? u.latestChapterSlug : r.latestChapterSlug, latestChapterName: u && u.latestChapterName ? u.latestChapterName : "", latestChapterUrl: u && u.latestChapterUrl ? u.latestChapterUrl : "", host: x }; return i.link = $(u && u.rawLink ? u.rawLink : r.url, i.mangaId, i), i; } function _t(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    u = F(r), i = u.title || I(u.slug), c = null;
                                                    if (!i) return [3, 2];
                                                    return [4, a(x, { queries: { s: i, post_type: "wp-manga" } })];
                                                case 1:
                                                    l = _b.sent();
                                                    l && l.ok && (c = gt(st(l.html()), u));
                                                    _b.label = 2;
                                                case 2: return [2, bt(u, c)];
                                            }
                                        }); });
                                    } function Mt(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l, d; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    if (!r)
                                                        return [2, ""];
                                                    return [4, a(ut + "?" + q({ action: "get_first_chapter_content", manga_id: r }))];
                                                case 1:
                                                    u = _b.sent();
                                                    if (!u || !u.ok)
                                                        return [2, ""];
                                                    i = u.json(), c = ot(i);
                                                    if (!c)
                                                        return [2, ""];
                                                    l = s.parse(c), d = l.select("#wp-manga-current-chap").first();
                                                    return [2, g(d ? d.attr("value") : "")];
                                            }
                                        }); });
                                    } function ot(r) { return r ? typeof r == "string" ? r : r.data && typeof r.data == "string" ? r.data : r.data && r.data.content ? r.data.content : r.data && r.data.data && r.data.data.content ? r.data.data.content : r.content ? r.content : "" : ""; } function Ft(r) { return (r || "").replace(/<!--[\s\S]*?-->/g, "").replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").trim(); } function W(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0: return [4, _t(r)];
                                                case 1:
                                                    u = _b.sent();
                                                    return [2, o.success({ name: u.title || I(u.slug), cover: u.cover || "", host: x, author: "N/A", description: u.descriptionHtml || u.descriptionText || "", ongoing: u.ongoing !== !1, genres: u.genres || [] })];
                                            }
                                        }); });
                                    } var x, ut; return __generator(this, function (_b) {
                                        x = "https://metruyencv.xyz";
                                        try {
                                            CONFIG_URL && (x = CONFIG_URL.replace(/\/+$/, ""));
                                        }
                                        catch (r) { }
                                        ut = x + "/wp-admin/admin-ajax.php";
                                        return [2, typeof W == "function" ? W : void 0];
                                    }); });
                                })()];
                            case 1: return [2, _b.sent()];
                        }
                    }); });
                })(t.fetch, t.Http, t.Html, t.Response, t.localStorage, t.cacheStorage, t.localConfig, t.localCookie, t.sleep, t.Log, t.console, t.log, t.UserAgent, t.Engine, t.Graphics, t.Script)];
        }); });
    }, toc: function (t, e) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            return [2, (function (a, n, s, o, f, h, p, m, v, k, T, A, L, D, it, ct) {
                    return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0: return [4, (function () {
                                    return __awaiter(this, void 0, void 0, function () { function H(r) { return r ? /^https?:\/\//i.test(r) ? r : r.indexOf("//") === 0 ? "https:" + r : r.charAt(0) === "/" ? x + r : x + "/" + r.replace(/^\/+/, "") : ""; } function w(r) { return r ? /^https?:\/\//i.test(r) ? r.replace(/^(https?:\/\/)(www\.)?[^\/?#]+/i, x) : H(r) : x; } function g(r) { return (r || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim(); } function G(r) { try {
                                        return decodeURIComponent(r || "");
                                    }
                                    catch (u) {
                                        return r || "";
                                    } } function S(r) { return Array.isArray(r) ? r[0] : r; } function j(r) { var u = {}; try {
                                        var i = (r || "").split("?")[1] || "";
                                        if (!i)
                                            return u;
                                        i.split("&").forEach(function (c) { if (c) {
                                            var l = c.split("="), d = G(l[0]).trim(), b = G(l.slice(1).join("="));
                                            d && (u.hasOwnProperty(d) ? (Array.isArray(u[d]) || (u[d] = [u[d]]), u[d].push(b)) : u[d] = b);
                                        } });
                                    }
                                    catch (c) { } return u; } function q(r) { var u = []; return r ? (Object.keys(r).forEach(function (i) { var c = r[i]; if (c != null) {
                                        if (Array.isArray(c)) {
                                            c.forEach(function (l) { l != null && u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(l))); });
                                            return;
                                        }
                                        u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(c)));
                                    } }), u.join("&")) : ""; } function R(r) { var u = w(r || "").match(/\/truyen\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function M(r) { var u = w(r || "").match(/\/truyen\/[^\/?#]+\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function dt(r) { var u = w(r || "").match(/\/the-loai\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function I(r) { return g((r || "").replace(/-/g, " ")); } function z(r) { var u = g(r).toLowerCase(); return u ? u.indexOf("hoàn thành") === -1 && u.indexOf("hoan thanh") === -1 && u.indexOf("hoan-thanh") === -1 && u.indexOf("/trang-thai/hoan-thanh/") === -1 && u.indexOf("full") === -1 && u.indexOf(" end") === -1 && u.indexOf("đã hoàn thành") === -1 : !0; } function rt(r, u) { var i = w(r || x), c = j(i), l = { s: S(c.s), post_type: S(c.post_type) || "wp-manga" }, d = dt(i); return l.s === void 0 && (l.s = ""), d && (l["genre[]"] = d), c.hasOwnProperty("genre[]") && (l["genre[]"] = c["genre[]"]), c.hasOwnProperty("status[0]") && (l["status[0]"] = c["status[0]"]), c.hasOwnProperty("m_orderby") && (l.m_orderby = c.m_orderby), c.hasOwnProperty("author") && (l.author = c.author), c.hasOwnProperty("release") && (l.release = c.release), c.hasOwnProperty("adult") && (l.adult = c.adult), /\/trang-thai\/hoan-thanh\/?$/i.test(i) && (l["status[0]"] = "end"), !l.s && !l["genre[]"] && !l["status[0]"] && !l.m_orderby && (l.m_orderby = "latest"), u && (l.paged = String(u)), x + "/?" + q(l); } function Bt(r) { return x + "/?" + q({ s: "", post_type: "wp-manga", "genre[]": r }); } function ht(r, u) { return { title: g(r), input: rt(u, 1), script: "book.js" }; } function pt(r) { if (!r)
                                        return ""; var u = r.attr("src"); return (!u || u.indexOf("data:image") === 0) && (u = r.attr("data-src") || r.attr("data-lazy-src") || r.attr("data-original") || u), H(u); } function $(r, u, i) { var c = R(r), l = c ? x + "/truyen/" + c + "/" : w(r), d = {}; u && (d.manga_id = u), i && (i.title && (d.title = i.title), i.cover && (d.cover = i.cover), i.statusText && (d.status = i.statusText), i.latestChapterSlug && (d.latest = i.latestChapterSlug)); var b = q(d); return b ? l + "?" + b : l; } function Ht(r, u, i) { var c = typeof r == "string" ? F(r) : r, l = c.slug || R(i), d = l && u ? x + "/truyen/" + l + "/" + u + "/" : w(i), b = {}; c.mangaId && (b.manga_id = c.mangaId), c.title && (b.title = c.title), c.cover && (b.cover = c.cover), c.statusText && (b.status = c.statusText), u && (b.chapter = u); var C = q(b); return C ? d + "?" + C : d; } function F(r) { var u = w(r || ""), i = j(u); return { url: u, slug: R(u), mangaId: g(S(i.manga_id) || ""), title: g(S(i.title) || ""), cover: S(i.cover) || "", statusText: g(S(i.status) || ""), latestChapterSlug: g(S(i.latest) || ""), chapterSlug: g(S(i.chapter) || M(u)) }; } function Q(r) { var u = r.select(".post-title a, h3 a").first(); if (!u)
                                        return null; var i = r.select(".except-summary").first(), c = r.select(".latest-chap a, .font-meta.chapter a, .chapter-item a, .list-chapter a").first(), l = g(u.text()), d = w(u.attr("href")), b = r.select(".trangthai, .summary-content, .mg_status").first(), C = b ? b.select("a").last() : null, X = g((C ? C.attr("href") + " " : "") + (b ? b.text() : "")), J = []; r.select(".genres-content-search a, .genres-content a").forEach(function (Z) { var K = g(Z.text()), Y = Z.attr("href"); !K || !Y || J.push(ht(K, Y)); }); var O = { title: l, rawLink: d, slug: R(d), mangaId: g(i ? i.attr("data-manga-id") : ""), cover: pt(r.select("img").first()), descriptionHtml: i && i.html() || "", descriptionText: g(i ? i.text() : ""), statusText: X, ongoing: z(X), genres: J, latestChapterSlug: g(c ? M(c.attr("href")) || c.attr("value") : ""), latestChapterName: g(c ? c.text() : ""), latestChapterUrl: c ? w(c.attr("href")) : "", host: x }; return O.link = $(O.rawLink, O.mangaId, O), O; } function st(r) { var u = []; return r.select(".row.c-tabs-item__content").forEach(function (i) { var c = Q(i); c && u.push(c); }), u.length === 0 && r.select(".page-item-detail").forEach(function (i) { var c = Q(i); c && u.push(c); }), u; } function Lt(r) { return { name: r.title, link: r.link, cover: r.cover, author: "N/A", description: r.descriptionText, host: x }; } function qt(r) { var u = r.select("#madara_goto_page").first(); if (!u)
                                        return ""; var i = parseInt(u.attr("placeholder") || "1", 10), c = parseInt(u.attr("max") || "0", 10); return !isNaN(i) && !isNaN(c) && i < c ? String(i + 1) : ""; } function gt(r, u) { var i; for (i = 0; i < r.length; i++)
                                        if (u.mangaId && r[i].mangaId === u.mangaId)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.slug && r[i].slug === u.slug)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.title && g(r[i].title).toLowerCase() === g(u.title).toLowerCase())
                                            return r[i]; return r.length ? r[0] : null; } function bt(r, u) { var i = { url: r.url, slug: u && u.slug ? u.slug : r.slug, mangaId: u && u.mangaId ? u.mangaId : r.mangaId, title: u && u.title ? u.title : r.title || I(r.slug), cover: u && u.cover ? u.cover : r.cover, statusText: u && u.statusText ? u.statusText : r.statusText, descriptionHtml: u && u.descriptionHtml ? u.descriptionHtml : "", descriptionText: u && u.descriptionText ? u.descriptionText : "", ongoing: u ? u.ongoing : z(r.statusText), genres: u && u.genres ? u.genres : [], latestChapterSlug: u && u.latestChapterSlug ? u.latestChapterSlug : r.latestChapterSlug, latestChapterName: u && u.latestChapterName ? u.latestChapterName : "", latestChapterUrl: u && u.latestChapterUrl ? u.latestChapterUrl : "", host: x }; return i.link = $(u && u.rawLink ? u.rawLink : r.url, i.mangaId, i), i; } function _t(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    u = F(r), i = u.title || I(u.slug), c = null;
                                                    if (!i) return [3, 2];
                                                    return [4, a(x, { queries: { s: i, post_type: "wp-manga" } })];
                                                case 1:
                                                    l = _b.sent();
                                                    l && l.ok && (c = gt(st(l.html()), u));
                                                    _b.label = 2;
                                                case 2: return [2, bt(u, c)];
                                            }
                                        }); });
                                    } function Mt(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l, d; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    if (!r)
                                                        return [2, ""];
                                                    return [4, a(ut + "?" + q({ action: "get_first_chapter_content", manga_id: r }))];
                                                case 1:
                                                    u = _b.sent();
                                                    if (!u || !u.ok)
                                                        return [2, ""];
                                                    i = u.json(), c = ot(i);
                                                    if (!c)
                                                        return [2, ""];
                                                    l = s.parse(c), d = l.select("#wp-manga-current-chap").first();
                                                    return [2, g(d ? d.attr("value") : "")];
                                            }
                                        }); });
                                    } function ot(r) { return r ? typeof r == "string" ? r : r.data && typeof r.data == "string" ? r.data : r.data && r.data.content ? r.data.content : r.data && r.data.data && r.data.data.content ? r.data.data.content : r.content ? r.content : "" : ""; } function Ft(r) { return (r || "").replace(/<!--[\s\S]*?-->/g, "").replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").trim(); } function W(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, _b, c, l, d; return __generator(this, function (_c) {
                                            switch (_c.label) {
                                                case 0:
                                                    u = F(r), i = u.latestChapterSlug;
                                                    _b = i;
                                                    if (_b) return [3, 2];
                                                    return [4, Mt(u.mangaId)];
                                                case 1:
                                                    _b = (i = _c.sent());
                                                    _c.label = 2;
                                                case 2:
                                                    if (_b, !u.mangaId || !i)
                                                        return [2, o.success([])];
                                                    return [4, a(ut, { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8", "x-requested-with": "XMLHttpRequest" }, body: q({ action: "manga_get_reading_nav", manga: u.mangaId, chapter: i, volume_id: 0, style: "select", type: "manga" }) })];
                                                case 3:
                                                    c = _c.sent();
                                                    if (!c || !c.ok)
                                                        return [2, o.success([])];
                                                    l = s.parse(c.text()), d = [];
                                                    return [2, (l.select("option").forEach(function (b) { var C = g(b.attr("value") || M(b.attr("data-redirect"))); C && d.push({ name: g(b.text()), url: Ht(u, C, b.attr("data-redirect")), host: x }); }), d.reverse(), o.success(d))];
                                            }
                                        }); });
                                    } var x, ut; return __generator(this, function (_b) {
                                        x = "https://metruyencv.xyz";
                                        try {
                                            CONFIG_URL && (x = CONFIG_URL.replace(/\/+$/, ""));
                                        }
                                        catch (r) { }
                                        ut = x + "/wp-admin/admin-ajax.php";
                                        return [2, typeof W == "function" ? W : void 0];
                                    }); });
                                })()];
                            case 1: return [2, _b.sent()];
                        }
                    }); });
                })(t.fetch, t.Http, t.Html, t.Response, t.localStorage, t.cacheStorage, t.localConfig, t.localCookie, t.sleep, t.Log, t.console, t.log, t.UserAgent, t.Engine, t.Graphics, t.Script)];
        }); });
    }, chap: function (t, e) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            return [2, (function (a, n, s, o, f, h, p, m, v, k, T, A, L, D, it, ct) {
                    return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0: return [4, (function () {
                                    return __awaiter(this, void 0, void 0, function () { function H(r) { return r ? /^https?:\/\//i.test(r) ? r : r.indexOf("//") === 0 ? "https:" + r : r.charAt(0) === "/" ? x + r : x + "/" + r.replace(/^\/+/, "") : ""; } function w(r) { return r ? /^https?:\/\//i.test(r) ? r.replace(/^(https?:\/\/)(www\.)?[^\/?#]+/i, x) : H(r) : x; } function g(r) { return (r || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim(); } function G(r) { try {
                                        return decodeURIComponent(r || "");
                                    }
                                    catch (u) {
                                        return r || "";
                                    } } function S(r) { return Array.isArray(r) ? r[0] : r; } function j(r) { var u = {}; try {
                                        var i = (r || "").split("?")[1] || "";
                                        if (!i)
                                            return u;
                                        i.split("&").forEach(function (c) { if (c) {
                                            var l = c.split("="), d = G(l[0]).trim(), b = G(l.slice(1).join("="));
                                            d && (u.hasOwnProperty(d) ? (Array.isArray(u[d]) || (u[d] = [u[d]]), u[d].push(b)) : u[d] = b);
                                        } });
                                    }
                                    catch (c) { } return u; } function q(r) { var u = []; return r ? (Object.keys(r).forEach(function (i) { var c = r[i]; if (c != null) {
                                        if (Array.isArray(c)) {
                                            c.forEach(function (l) { l != null && u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(l))); });
                                            return;
                                        }
                                        u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(c)));
                                    } }), u.join("&")) : ""; } function R(r) { var u = w(r || "").match(/\/truyen\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function M(r) { var u = w(r || "").match(/\/truyen\/[^\/?#]+\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function dt(r) { var u = w(r || "").match(/\/the-loai\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function I(r) { return g((r || "").replace(/-/g, " ")); } function z(r) { var u = g(r).toLowerCase(); return u ? u.indexOf("hoàn thành") === -1 && u.indexOf("hoan thanh") === -1 && u.indexOf("hoan-thanh") === -1 && u.indexOf("/trang-thai/hoan-thanh/") === -1 && u.indexOf("full") === -1 && u.indexOf(" end") === -1 && u.indexOf("đã hoàn thành") === -1 : !0; } function rt(r, u) { var i = w(r || x), c = j(i), l = { s: S(c.s), post_type: S(c.post_type) || "wp-manga" }, d = dt(i); return l.s === void 0 && (l.s = ""), d && (l["genre[]"] = d), c.hasOwnProperty("genre[]") && (l["genre[]"] = c["genre[]"]), c.hasOwnProperty("status[0]") && (l["status[0]"] = c["status[0]"]), c.hasOwnProperty("m_orderby") && (l.m_orderby = c.m_orderby), c.hasOwnProperty("author") && (l.author = c.author), c.hasOwnProperty("release") && (l.release = c.release), c.hasOwnProperty("adult") && (l.adult = c.adult), /\/trang-thai\/hoan-thanh\/?$/i.test(i) && (l["status[0]"] = "end"), !l.s && !l["genre[]"] && !l["status[0]"] && !l.m_orderby && (l.m_orderby = "latest"), u && (l.paged = String(u)), x + "/?" + q(l); } function Bt(r) { return x + "/?" + q({ s: "", post_type: "wp-manga", "genre[]": r }); } function ht(r, u) { return { title: g(r), input: rt(u, 1), script: "book.js" }; } function pt(r) { if (!r)
                                        return ""; var u = r.attr("src"); return (!u || u.indexOf("data:image") === 0) && (u = r.attr("data-src") || r.attr("data-lazy-src") || r.attr("data-original") || u), H(u); } function $(r, u, i) { var c = R(r), l = c ? x + "/truyen/" + c + "/" : w(r), d = {}; u && (d.manga_id = u), i && (i.title && (d.title = i.title), i.cover && (d.cover = i.cover), i.statusText && (d.status = i.statusText), i.latestChapterSlug && (d.latest = i.latestChapterSlug)); var b = q(d); return b ? l + "?" + b : l; } function Ht(r, u, i) { var c = typeof r == "string" ? F(r) : r, l = c.slug || R(i), d = l && u ? x + "/truyen/" + l + "/" + u + "/" : w(i), b = {}; c.mangaId && (b.manga_id = c.mangaId), c.title && (b.title = c.title), c.cover && (b.cover = c.cover), c.statusText && (b.status = c.statusText), u && (b.chapter = u); var C = q(b); return C ? d + "?" + C : d; } function F(r) { var u = w(r || ""), i = j(u); return { url: u, slug: R(u), mangaId: g(S(i.manga_id) || ""), title: g(S(i.title) || ""), cover: S(i.cover) || "", statusText: g(S(i.status) || ""), latestChapterSlug: g(S(i.latest) || ""), chapterSlug: g(S(i.chapter) || M(u)) }; } function Q(r) { var u = r.select(".post-title a, h3 a").first(); if (!u)
                                        return null; var i = r.select(".except-summary").first(), c = r.select(".latest-chap a, .font-meta.chapter a, .chapter-item a, .list-chapter a").first(), l = g(u.text()), d = w(u.attr("href")), b = r.select(".trangthai, .summary-content, .mg_status").first(), C = b ? b.select("a").last() : null, X = g((C ? C.attr("href") + " " : "") + (b ? b.text() : "")), J = []; r.select(".genres-content-search a, .genres-content a").forEach(function (Z) { var K = g(Z.text()), Y = Z.attr("href"); !K || !Y || J.push(ht(K, Y)); }); var O = { title: l, rawLink: d, slug: R(d), mangaId: g(i ? i.attr("data-manga-id") : ""), cover: pt(r.select("img").first()), descriptionHtml: i && i.html() || "", descriptionText: g(i ? i.text() : ""), statusText: X, ongoing: z(X), genres: J, latestChapterSlug: g(c ? M(c.attr("href")) || c.attr("value") : ""), latestChapterName: g(c ? c.text() : ""), latestChapterUrl: c ? w(c.attr("href")) : "", host: x }; return O.link = $(O.rawLink, O.mangaId, O), O; } function st(r) { var u = []; return r.select(".row.c-tabs-item__content").forEach(function (i) { var c = Q(i); c && u.push(c); }), u.length === 0 && r.select(".page-item-detail").forEach(function (i) { var c = Q(i); c && u.push(c); }), u; } function Lt(r) { return { name: r.title, link: r.link, cover: r.cover, author: "N/A", description: r.descriptionText, host: x }; } function qt(r) { var u = r.select("#madara_goto_page").first(); if (!u)
                                        return ""; var i = parseInt(u.attr("placeholder") || "1", 10), c = parseInt(u.attr("max") || "0", 10); return !isNaN(i) && !isNaN(c) && i < c ? String(i + 1) : ""; } function gt(r, u) { var i; for (i = 0; i < r.length; i++)
                                        if (u.mangaId && r[i].mangaId === u.mangaId)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.slug && r[i].slug === u.slug)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.title && g(r[i].title).toLowerCase() === g(u.title).toLowerCase())
                                            return r[i]; return r.length ? r[0] : null; } function bt(r, u) { var i = { url: r.url, slug: u && u.slug ? u.slug : r.slug, mangaId: u && u.mangaId ? u.mangaId : r.mangaId, title: u && u.title ? u.title : r.title || I(r.slug), cover: u && u.cover ? u.cover : r.cover, statusText: u && u.statusText ? u.statusText : r.statusText, descriptionHtml: u && u.descriptionHtml ? u.descriptionHtml : "", descriptionText: u && u.descriptionText ? u.descriptionText : "", ongoing: u ? u.ongoing : z(r.statusText), genres: u && u.genres ? u.genres : [], latestChapterSlug: u && u.latestChapterSlug ? u.latestChapterSlug : r.latestChapterSlug, latestChapterName: u && u.latestChapterName ? u.latestChapterName : "", latestChapterUrl: u && u.latestChapterUrl ? u.latestChapterUrl : "", host: x }; return i.link = $(u && u.rawLink ? u.rawLink : r.url, i.mangaId, i), i; } function _t(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    u = F(r), i = u.title || I(u.slug), c = null;
                                                    if (!i) return [3, 2];
                                                    return [4, a(x, { queries: { s: i, post_type: "wp-manga" } })];
                                                case 1:
                                                    l = _b.sent();
                                                    l && l.ok && (c = gt(st(l.html()), u));
                                                    _b.label = 2;
                                                case 2: return [2, bt(u, c)];
                                            }
                                        }); });
                                    } function Mt(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l, d; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    if (!r)
                                                        return [2, ""];
                                                    return [4, a(ut + "?" + q({ action: "get_first_chapter_content", manga_id: r }))];
                                                case 1:
                                                    u = _b.sent();
                                                    if (!u || !u.ok)
                                                        return [2, ""];
                                                    i = u.json(), c = ot(i);
                                                    if (!c)
                                                        return [2, ""];
                                                    l = s.parse(c), d = l.select("#wp-manga-current-chap").first();
                                                    return [2, g(d ? d.attr("value") : "")];
                                            }
                                        }); });
                                    } function ot(r) { return r ? typeof r == "string" ? r : r.data && typeof r.data == "string" ? r.data : r.data && r.data.content ? r.data.content : r.data && r.data.data && r.data.data.content ? r.data.data.content : r.content ? r.content : "" : ""; } function Ft(r) { return (r || "").replace(/<!--[\s\S]*?-->/g, "").replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").trim(); } function W(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l, d, b, C; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    u = F(r), i = u.chapterSlug || M(r);
                                                    if (!u.mangaId || !i)
                                                        return [2, null];
                                                    return [4, a(ut + "?" + q({ postID: u.mangaId, chapter: i, "truyen-paged": 1, style: "paged", action: "chapter_navigate_page" }), { headers: { accept: "application/json, text/javascript, */*; q=0.01", "x-requested-with": "XMLHttpRequest" } })];
                                                case 1:
                                                    c = _b.sent();
                                                    if (!c || !c.ok)
                                                        return [2, null];
                                                    l = c.json(), d = ot(l);
                                                    if (!d)
                                                        return [2, null];
                                                    b = s.parse(d);
                                                    b.select("script").remove(), b.select("style").remove();
                                                    C = b.select(".text-left").html();
                                                    return [2, (C || (C = b.select(".reading-content").html()), C || (C = d), o.success(Ft(C)))];
                                            }
                                        }); });
                                    } var x, ut; return __generator(this, function (_b) {
                                        x = "https://metruyencv.xyz";
                                        try {
                                            CONFIG_URL && (x = CONFIG_URL.replace(/\/+$/, ""));
                                        }
                                        catch (r) { }
                                        ut = x + "/wp-admin/admin-ajax.php";
                                        return [2, typeof W == "function" ? W : void 0];
                                    }); });
                                })()];
                            case 1: return [2, _b.sent()];
                        }
                    }); });
                })(t.fetch, t.Http, t.Html, t.Response, t.localStorage, t.cacheStorage, t.localConfig, t.localCookie, t.sleep, t.Log, t.console, t.log, t.UserAgent, t.Engine, t.Graphics, t.Script)];
        }); });
    }, home: function (t, e) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            return [2, (function (a, n, s, o, f, h, p, m, v, k, T, A, L, D, it, ct) {
                    return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0: return [4, (function () {
                                    return __awaiter(this, void 0, void 0, function () { function H(r) { return r ? /^https?:\/\//i.test(r) ? r : r.indexOf("//") === 0 ? "https:" + r : r.charAt(0) === "/" ? x + r : x + "/" + r.replace(/^\/+/, "") : ""; } function w(r) { return r ? /^https?:\/\//i.test(r) ? r.replace(/^(https?:\/\/)(www\.)?[^\/?#]+/i, x) : H(r) : x; } function g(r) { return (r || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim(); } function G(r) { try {
                                        return decodeURIComponent(r || "");
                                    }
                                    catch (u) {
                                        return r || "";
                                    } } function S(r) { return Array.isArray(r) ? r[0] : r; } function j(r) { var u = {}; try {
                                        var i = (r || "").split("?")[1] || "";
                                        if (!i)
                                            return u;
                                        i.split("&").forEach(function (c) { if (c) {
                                            var l = c.split("="), d = G(l[0]).trim(), b = G(l.slice(1).join("="));
                                            d && (u.hasOwnProperty(d) ? (Array.isArray(u[d]) || (u[d] = [u[d]]), u[d].push(b)) : u[d] = b);
                                        } });
                                    }
                                    catch (c) { } return u; } function q(r) { var u = []; return r ? (Object.keys(r).forEach(function (i) { var c = r[i]; if (c != null) {
                                        if (Array.isArray(c)) {
                                            c.forEach(function (l) { l != null && u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(l))); });
                                            return;
                                        }
                                        u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(c)));
                                    } }), u.join("&")) : ""; } function R(r) { var u = w(r || "").match(/\/truyen\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function M(r) { var u = w(r || "").match(/\/truyen\/[^\/?#]+\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function dt(r) { var u = w(r || "").match(/\/the-loai\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function I(r) { return g((r || "").replace(/-/g, " ")); } function z(r) { var u = g(r).toLowerCase(); return u ? u.indexOf("hoàn thành") === -1 && u.indexOf("hoan thanh") === -1 && u.indexOf("hoan-thanh") === -1 && u.indexOf("/trang-thai/hoan-thanh/") === -1 && u.indexOf("full") === -1 && u.indexOf(" end") === -1 && u.indexOf("đã hoàn thành") === -1 : !0; } function rt(r, u) { var i = w(r || x), c = j(i), l = { s: S(c.s), post_type: S(c.post_type) || "wp-manga" }, d = dt(i); return l.s === void 0 && (l.s = ""), d && (l["genre[]"] = d), c.hasOwnProperty("genre[]") && (l["genre[]"] = c["genre[]"]), c.hasOwnProperty("status[0]") && (l["status[0]"] = c["status[0]"]), c.hasOwnProperty("m_orderby") && (l.m_orderby = c.m_orderby), c.hasOwnProperty("author") && (l.author = c.author), c.hasOwnProperty("release") && (l.release = c.release), c.hasOwnProperty("adult") && (l.adult = c.adult), /\/trang-thai\/hoan-thanh\/?$/i.test(i) && (l["status[0]"] = "end"), !l.s && !l["genre[]"] && !l["status[0]"] && !l.m_orderby && (l.m_orderby = "latest"), u && (l.paged = String(u)), x + "/?" + q(l); } function Bt(r) { return x + "/?" + q({ s: "", post_type: "wp-manga", "genre[]": r }); } function ht(r, u) { return { title: g(r), input: rt(u, 1), script: "book.js" }; } function pt(r) { if (!r)
                                        return ""; var u = r.attr("src"); return (!u || u.indexOf("data:image") === 0) && (u = r.attr("data-src") || r.attr("data-lazy-src") || r.attr("data-original") || u), H(u); } function $(r, u, i) { var c = R(r), l = c ? x + "/truyen/" + c + "/" : w(r), d = {}; u && (d.manga_id = u), i && (i.title && (d.title = i.title), i.cover && (d.cover = i.cover), i.statusText && (d.status = i.statusText), i.latestChapterSlug && (d.latest = i.latestChapterSlug)); var b = q(d); return b ? l + "?" + b : l; } function Ht(r, u, i) { var c = typeof r == "string" ? F(r) : r, l = c.slug || R(i), d = l && u ? x + "/truyen/" + l + "/" + u + "/" : w(i), b = {}; c.mangaId && (b.manga_id = c.mangaId), c.title && (b.title = c.title), c.cover && (b.cover = c.cover), c.statusText && (b.status = c.statusText), u && (b.chapter = u); var C = q(b); return C ? d + "?" + C : d; } function F(r) { var u = w(r || ""), i = j(u); return { url: u, slug: R(u), mangaId: g(S(i.manga_id) || ""), title: g(S(i.title) || ""), cover: S(i.cover) || "", statusText: g(S(i.status) || ""), latestChapterSlug: g(S(i.latest) || ""), chapterSlug: g(S(i.chapter) || M(u)) }; } function Q(r) { var u = r.select(".post-title a, h3 a").first(); if (!u)
                                        return null; var i = r.select(".except-summary").first(), c = r.select(".latest-chap a, .font-meta.chapter a, .chapter-item a, .list-chapter a").first(), l = g(u.text()), d = w(u.attr("href")), b = r.select(".trangthai, .summary-content, .mg_status").first(), C = b ? b.select("a").last() : null, X = g((C ? C.attr("href") + " " : "") + (b ? b.text() : "")), J = []; r.select(".genres-content-search a, .genres-content a").forEach(function (Z) { var K = g(Z.text()), Y = Z.attr("href"); !K || !Y || J.push(ht(K, Y)); }); var O = { title: l, rawLink: d, slug: R(d), mangaId: g(i ? i.attr("data-manga-id") : ""), cover: pt(r.select("img").first()), descriptionHtml: i && i.html() || "", descriptionText: g(i ? i.text() : ""), statusText: X, ongoing: z(X), genres: J, latestChapterSlug: g(c ? M(c.attr("href")) || c.attr("value") : ""), latestChapterName: g(c ? c.text() : ""), latestChapterUrl: c ? w(c.attr("href")) : "", host: x }; return O.link = $(O.rawLink, O.mangaId, O), O; } function st(r) { var u = []; return r.select(".row.c-tabs-item__content").forEach(function (i) { var c = Q(i); c && u.push(c); }), u.length === 0 && r.select(".page-item-detail").forEach(function (i) { var c = Q(i); c && u.push(c); }), u; } function Lt(r) { return { name: r.title, link: r.link, cover: r.cover, author: "N/A", description: r.descriptionText, host: x }; } function qt(r) { var u = r.select("#madara_goto_page").first(); if (!u)
                                        return ""; var i = parseInt(u.attr("placeholder") || "1", 10), c = parseInt(u.attr("max") || "0", 10); return !isNaN(i) && !isNaN(c) && i < c ? String(i + 1) : ""; } function gt(r, u) { var i; for (i = 0; i < r.length; i++)
                                        if (u.mangaId && r[i].mangaId === u.mangaId)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.slug && r[i].slug === u.slug)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.title && g(r[i].title).toLowerCase() === g(u.title).toLowerCase())
                                            return r[i]; return r.length ? r[0] : null; } function bt(r, u) { var i = { url: r.url, slug: u && u.slug ? u.slug : r.slug, mangaId: u && u.mangaId ? u.mangaId : r.mangaId, title: u && u.title ? u.title : r.title || I(r.slug), cover: u && u.cover ? u.cover : r.cover, statusText: u && u.statusText ? u.statusText : r.statusText, descriptionHtml: u && u.descriptionHtml ? u.descriptionHtml : "", descriptionText: u && u.descriptionText ? u.descriptionText : "", ongoing: u ? u.ongoing : z(r.statusText), genres: u && u.genres ? u.genres : [], latestChapterSlug: u && u.latestChapterSlug ? u.latestChapterSlug : r.latestChapterSlug, latestChapterName: u && u.latestChapterName ? u.latestChapterName : "", latestChapterUrl: u && u.latestChapterUrl ? u.latestChapterUrl : "", host: x }; return i.link = $(u && u.rawLink ? u.rawLink : r.url, i.mangaId, i), i; } function _t(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    u = F(r), i = u.title || I(u.slug), c = null;
                                                    if (!i) return [3, 2];
                                                    return [4, a(x, { queries: { s: i, post_type: "wp-manga" } })];
                                                case 1:
                                                    l = _b.sent();
                                                    l && l.ok && (c = gt(st(l.html()), u));
                                                    _b.label = 2;
                                                case 2: return [2, bt(u, c)];
                                            }
                                        }); });
                                    } function Mt(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l, d; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    if (!r)
                                                        return [2, ""];
                                                    return [4, a(ut + "?" + q({ action: "get_first_chapter_content", manga_id: r }))];
                                                case 1:
                                                    u = _b.sent();
                                                    if (!u || !u.ok)
                                                        return [2, ""];
                                                    i = u.json(), c = ot(i);
                                                    if (!c)
                                                        return [2, ""];
                                                    l = s.parse(c), d = l.select("#wp-manga-current-chap").first();
                                                    return [2, g(d ? d.attr("value") : "")];
                                            }
                                        }); });
                                    } function ot(r) { return r ? typeof r == "string" ? r : r.data && typeof r.data == "string" ? r.data : r.data && r.data.content ? r.data.content : r.data && r.data.data && r.data.data.content ? r.data.data.content : r.content ? r.content : "" : ""; } function Ft(r) { return (r || "").replace(/<!--[\s\S]*?-->/g, "").replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").trim(); } function W() {
                                        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
                                            return [2, o.success([{ title: "Trang chủ", input: rt(x, 1), script: "book.js" }, { title: "TOP", input: rt(x + "/?m_orderby=views", 1), script: "book.js" }, { title: "Truyện Full", input: x + "/?" + q({ s: "", post_type: "wp-manga", "status[0]": "end", m_orderby: "latest", paged: 1 }), script: "book.js" }])];
                                        }); });
                                    } var x, ut; return __generator(this, function (_b) {
                                        x = "https://metruyencv.xyz";
                                        try {
                                            CONFIG_URL && (x = CONFIG_URL.replace(/\/+$/, ""));
                                        }
                                        catch (r) { }
                                        ut = x + "/wp-admin/admin-ajax.php";
                                        return [2, typeof W == "function" ? W : void 0];
                                    }); });
                                })()];
                            case 1: return [2, _b.sent()];
                        }
                    }); });
                })(t.fetch, t.Http, t.Html, t.Response, t.localStorage, t.cacheStorage, t.localConfig, t.localCookie, t.sleep, t.Log, t.console, t.log, t.UserAgent, t.Engine, t.Graphics, t.Script)];
        }); });
    }, genre: function (t, e) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            return [2, (function (a, n, s, o, f, h, p, m, v, k, T, A, L, D, it, ct) {
                    return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0: return [4, (function () {
                                    return __awaiter(this, void 0, void 0, function () { function H(r) { return r ? /^https?:\/\//i.test(r) ? r : r.indexOf("//") === 0 ? "https:" + r : r.charAt(0) === "/" ? x + r : x + "/" + r.replace(/^\/+/, "") : ""; } function w(r) { return r ? /^https?:\/\//i.test(r) ? r.replace(/^(https?:\/\/)(www\.)?[^\/?#]+/i, x) : H(r) : x; } function g(r) { return (r || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim(); } function G(r) { try {
                                        return decodeURIComponent(r || "");
                                    }
                                    catch (u) {
                                        return r || "";
                                    } } function S(r) { return Array.isArray(r) ? r[0] : r; } function j(r) { var u = {}; try {
                                        var i = (r || "").split("?")[1] || "";
                                        if (!i)
                                            return u;
                                        i.split("&").forEach(function (c) { if (c) {
                                            var l = c.split("="), d = G(l[0]).trim(), b = G(l.slice(1).join("="));
                                            d && (u.hasOwnProperty(d) ? (Array.isArray(u[d]) || (u[d] = [u[d]]), u[d].push(b)) : u[d] = b);
                                        } });
                                    }
                                    catch (c) { } return u; } function q(r) { var u = []; return r ? (Object.keys(r).forEach(function (i) { var c = r[i]; if (c != null) {
                                        if (Array.isArray(c)) {
                                            c.forEach(function (l) { l != null && u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(l))); });
                                            return;
                                        }
                                        u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(c)));
                                    } }), u.join("&")) : ""; } function R(r) { var u = w(r || "").match(/\/truyen\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function M(r) { var u = w(r || "").match(/\/truyen\/[^\/?#]+\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function dt(r) { var u = w(r || "").match(/\/the-loai\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function I(r) { return g((r || "").replace(/-/g, " ")); } function z(r) { var u = g(r).toLowerCase(); return u ? u.indexOf("hoàn thành") === -1 && u.indexOf("hoan thanh") === -1 && u.indexOf("hoan-thanh") === -1 && u.indexOf("/trang-thai/hoan-thanh/") === -1 && u.indexOf("full") === -1 && u.indexOf(" end") === -1 && u.indexOf("đã hoàn thành") === -1 : !0; } function rt(r, u) { var i = w(r || x), c = j(i), l = { s: S(c.s), post_type: S(c.post_type) || "wp-manga" }, d = dt(i); return l.s === void 0 && (l.s = ""), d && (l["genre[]"] = d), c.hasOwnProperty("genre[]") && (l["genre[]"] = c["genre[]"]), c.hasOwnProperty("status[0]") && (l["status[0]"] = c["status[0]"]), c.hasOwnProperty("m_orderby") && (l.m_orderby = c.m_orderby), c.hasOwnProperty("author") && (l.author = c.author), c.hasOwnProperty("release") && (l.release = c.release), c.hasOwnProperty("adult") && (l.adult = c.adult), /\/trang-thai\/hoan-thanh\/?$/i.test(i) && (l["status[0]"] = "end"), !l.s && !l["genre[]"] && !l["status[0]"] && !l.m_orderby && (l.m_orderby = "latest"), u && (l.paged = String(u)), x + "/?" + q(l); } function Bt(r) { return x + "/?" + q({ s: "", post_type: "wp-manga", "genre[]": r }); } function ht(r, u) { return { title: g(r), input: rt(u, 1), script: "book.js" }; } function pt(r) { if (!r)
                                        return ""; var u = r.attr("src"); return (!u || u.indexOf("data:image") === 0) && (u = r.attr("data-src") || r.attr("data-lazy-src") || r.attr("data-original") || u), H(u); } function $(r, u, i) { var c = R(r), l = c ? x + "/truyen/" + c + "/" : w(r), d = {}; u && (d.manga_id = u), i && (i.title && (d.title = i.title), i.cover && (d.cover = i.cover), i.statusText && (d.status = i.statusText), i.latestChapterSlug && (d.latest = i.latestChapterSlug)); var b = q(d); return b ? l + "?" + b : l; } function Ht(r, u, i) { var c = typeof r == "string" ? F(r) : r, l = c.slug || R(i), d = l && u ? x + "/truyen/" + l + "/" + u + "/" : w(i), b = {}; c.mangaId && (b.manga_id = c.mangaId), c.title && (b.title = c.title), c.cover && (b.cover = c.cover), c.statusText && (b.status = c.statusText), u && (b.chapter = u); var C = q(b); return C ? d + "?" + C : d; } function F(r) { var u = w(r || ""), i = j(u); return { url: u, slug: R(u), mangaId: g(S(i.manga_id) || ""), title: g(S(i.title) || ""), cover: S(i.cover) || "", statusText: g(S(i.status) || ""), latestChapterSlug: g(S(i.latest) || ""), chapterSlug: g(S(i.chapter) || M(u)) }; } function Q(r) { var u = r.select(".post-title a, h3 a").first(); if (!u)
                                        return null; var i = r.select(".except-summary").first(), c = r.select(".latest-chap a, .font-meta.chapter a, .chapter-item a, .list-chapter a").first(), l = g(u.text()), d = w(u.attr("href")), b = r.select(".trangthai, .summary-content, .mg_status").first(), C = b ? b.select("a").last() : null, X = g((C ? C.attr("href") + " " : "") + (b ? b.text() : "")), J = []; r.select(".genres-content-search a, .genres-content a").forEach(function (Z) { var K = g(Z.text()), Y = Z.attr("href"); !K || !Y || J.push(ht(K, Y)); }); var O = { title: l, rawLink: d, slug: R(d), mangaId: g(i ? i.attr("data-manga-id") : ""), cover: pt(r.select("img").first()), descriptionHtml: i && i.html() || "", descriptionText: g(i ? i.text() : ""), statusText: X, ongoing: z(X), genres: J, latestChapterSlug: g(c ? M(c.attr("href")) || c.attr("value") : ""), latestChapterName: g(c ? c.text() : ""), latestChapterUrl: c ? w(c.attr("href")) : "", host: x }; return O.link = $(O.rawLink, O.mangaId, O), O; } function st(r) { var u = []; return r.select(".row.c-tabs-item__content").forEach(function (i) { var c = Q(i); c && u.push(c); }), u.length === 0 && r.select(".page-item-detail").forEach(function (i) { var c = Q(i); c && u.push(c); }), u; } function Lt(r) { return { name: r.title, link: r.link, cover: r.cover, author: "N/A", description: r.descriptionText, host: x }; } function qt(r) { var u = r.select("#madara_goto_page").first(); if (!u)
                                        return ""; var i = parseInt(u.attr("placeholder") || "1", 10), c = parseInt(u.attr("max") || "0", 10); return !isNaN(i) && !isNaN(c) && i < c ? String(i + 1) : ""; } function gt(r, u) { var i; for (i = 0; i < r.length; i++)
                                        if (u.mangaId && r[i].mangaId === u.mangaId)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.slug && r[i].slug === u.slug)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.title && g(r[i].title).toLowerCase() === g(u.title).toLowerCase())
                                            return r[i]; return r.length ? r[0] : null; } function bt(r, u) { var i = { url: r.url, slug: u && u.slug ? u.slug : r.slug, mangaId: u && u.mangaId ? u.mangaId : r.mangaId, title: u && u.title ? u.title : r.title || I(r.slug), cover: u && u.cover ? u.cover : r.cover, statusText: u && u.statusText ? u.statusText : r.statusText, descriptionHtml: u && u.descriptionHtml ? u.descriptionHtml : "", descriptionText: u && u.descriptionText ? u.descriptionText : "", ongoing: u ? u.ongoing : z(r.statusText), genres: u && u.genres ? u.genres : [], latestChapterSlug: u && u.latestChapterSlug ? u.latestChapterSlug : r.latestChapterSlug, latestChapterName: u && u.latestChapterName ? u.latestChapterName : "", latestChapterUrl: u && u.latestChapterUrl ? u.latestChapterUrl : "", host: x }; return i.link = $(u && u.rawLink ? u.rawLink : r.url, i.mangaId, i), i; } function _t(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    u = F(r), i = u.title || I(u.slug), c = null;
                                                    if (!i) return [3, 2];
                                                    return [4, a(x, { queries: { s: i, post_type: "wp-manga" } })];
                                                case 1:
                                                    l = _b.sent();
                                                    l && l.ok && (c = gt(st(l.html()), u));
                                                    _b.label = 2;
                                                case 2: return [2, bt(u, c)];
                                            }
                                        }); });
                                    } function Mt(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l, d; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    if (!r)
                                                        return [2, ""];
                                                    return [4, a(ut + "?" + q({ action: "get_first_chapter_content", manga_id: r }))];
                                                case 1:
                                                    u = _b.sent();
                                                    if (!u || !u.ok)
                                                        return [2, ""];
                                                    i = u.json(), c = ot(i);
                                                    if (!c)
                                                        return [2, ""];
                                                    l = s.parse(c), d = l.select("#wp-manga-current-chap").first();
                                                    return [2, g(d ? d.attr("value") : "")];
                                            }
                                        }); });
                                    } function ot(r) { return r ? typeof r == "string" ? r : r.data && typeof r.data == "string" ? r.data : r.data && r.data.content ? r.data.content : r.data && r.data.data && r.data.data.content ? r.data.data.content : r.content ? r.content : "" : ""; } function Ft(r) { return (r || "").replace(/<!--[\s\S]*?-->/g, "").replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").trim(); } function W() {
                                        return __awaiter(this, void 0, void 0, function () { var r, u, i; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0: return [4, a(x, { queries: { s: "", post_type: "wp-manga" } })];
                                                case 1:
                                                    r = _b.sent();
                                                    if (!r || !r.ok)
                                                        return [2, null];
                                                    u = r.html(), i = [];
                                                    return [2, (u.select("input[name='genre[]']").forEach(function (c) { var l = g(c.attr("value")), d = c.attr("id"), b = l, C = d ? u.select("label[for='" + d + "']").first() : null; C && (b = g(C.text())), !(!l || !b) && i.push({ title: b, input: Bt(l), script: "book.js" }); }), o.success(i))];
                                            }
                                        }); });
                                    } var x, ut; return __generator(this, function (_b) {
                                        x = "https://metruyencv.xyz";
                                        try {
                                            CONFIG_URL && (x = CONFIG_URL.replace(/\/+$/, ""));
                                        }
                                        catch (r) { }
                                        ut = x + "/wp-admin/admin-ajax.php";
                                        return [2, typeof W == "function" ? W : void 0];
                                    }); });
                                })()];
                            case 1: return [2, _b.sent()];
                        }
                    }); });
                })(t.fetch, t.Http, t.Html, t.Response, t.localStorage, t.cacheStorage, t.localConfig, t.localCookie, t.sleep, t.Log, t.console, t.log, t.UserAgent, t.Engine, t.Graphics, t.Script)];
        }); });
    }, search: function (t, e) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            return [2, (function (a, n, s, o, f, h, p, m, v, k, T, A, L, D, it, ct) {
                    return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0: return [4, (function () {
                                    return __awaiter(this, void 0, void 0, function () { function H(r) { return r ? /^https?:\/\//i.test(r) ? r : r.indexOf("//") === 0 ? "https:" + r : r.charAt(0) === "/" ? x + r : x + "/" + r.replace(/^\/+/, "") : ""; } function w(r) { return r ? /^https?:\/\//i.test(r) ? r.replace(/^(https?:\/\/)(www\.)?[^\/?#]+/i, x) : H(r) : x; } function g(r) { return (r || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim(); } function G(r) { try {
                                        return decodeURIComponent(r || "");
                                    }
                                    catch (u) {
                                        return r || "";
                                    } } function S(r) { return Array.isArray(r) ? r[0] : r; } function j(r) { var u = {}; try {
                                        var i = (r || "").split("?")[1] || "";
                                        if (!i)
                                            return u;
                                        i.split("&").forEach(function (c) { if (c) {
                                            var l = c.split("="), d = G(l[0]).trim(), b = G(l.slice(1).join("="));
                                            d && (u.hasOwnProperty(d) ? (Array.isArray(u[d]) || (u[d] = [u[d]]), u[d].push(b)) : u[d] = b);
                                        } });
                                    }
                                    catch (c) { } return u; } function q(r) { var u = []; return r ? (Object.keys(r).forEach(function (i) { var c = r[i]; if (c != null) {
                                        if (Array.isArray(c)) {
                                            c.forEach(function (l) { l != null && u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(l))); });
                                            return;
                                        }
                                        u.push(encodeURIComponent(i) + "=" + encodeURIComponent(String(c)));
                                    } }), u.join("&")) : ""; } function R(r) { var u = w(r || "").match(/\/truyen\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function M(r) { var u = w(r || "").match(/\/truyen\/[^\/?#]+\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function dt(r) { var u = w(r || "").match(/\/the-loai\/([^\/?#]+)(?:\/|$)/i); return u ? u[1] : ""; } function I(r) { return g((r || "").replace(/-/g, " ")); } function z(r) { var u = g(r).toLowerCase(); return u ? u.indexOf("hoàn thành") === -1 && u.indexOf("hoan thanh") === -1 && u.indexOf("hoan-thanh") === -1 && u.indexOf("/trang-thai/hoan-thanh/") === -1 && u.indexOf("full") === -1 && u.indexOf(" end") === -1 && u.indexOf("đã hoàn thành") === -1 : !0; } function rt(r, u) { var i = w(r || x), c = j(i), l = { s: S(c.s), post_type: S(c.post_type) || "wp-manga" }, d = dt(i); return l.s === void 0 && (l.s = ""), d && (l["genre[]"] = d), c.hasOwnProperty("genre[]") && (l["genre[]"] = c["genre[]"]), c.hasOwnProperty("status[0]") && (l["status[0]"] = c["status[0]"]), c.hasOwnProperty("m_orderby") && (l.m_orderby = c.m_orderby), c.hasOwnProperty("author") && (l.author = c.author), c.hasOwnProperty("release") && (l.release = c.release), c.hasOwnProperty("adult") && (l.adult = c.adult), /\/trang-thai\/hoan-thanh\/?$/i.test(i) && (l["status[0]"] = "end"), !l.s && !l["genre[]"] && !l["status[0]"] && !l.m_orderby && (l.m_orderby = "latest"), u && (l.paged = String(u)), x + "/?" + q(l); } function Bt(r) { return x + "/?" + q({ s: "", post_type: "wp-manga", "genre[]": r }); } function ht(r, u) { return { title: g(r), input: rt(u, 1), script: "book.js" }; } function pt(r) { if (!r)
                                        return ""; var u = r.attr("src"); return (!u || u.indexOf("data:image") === 0) && (u = r.attr("data-src") || r.attr("data-lazy-src") || r.attr("data-original") || u), H(u); } function $(r, u, i) { var c = R(r), l = c ? x + "/truyen/" + c + "/" : w(r), d = {}; u && (d.manga_id = u), i && (i.title && (d.title = i.title), i.cover && (d.cover = i.cover), i.statusText && (d.status = i.statusText), i.latestChapterSlug && (d.latest = i.latestChapterSlug)); var b = q(d); return b ? l + "?" + b : l; } function Ht(r, u, i) { var c = typeof r == "string" ? F(r) : r, l = c.slug || R(i), d = l && u ? x + "/truyen/" + l + "/" + u + "/" : w(i), b = {}; c.mangaId && (b.manga_id = c.mangaId), c.title && (b.title = c.title), c.cover && (b.cover = c.cover), c.statusText && (b.status = c.statusText), u && (b.chapter = u); var C = q(b); return C ? d + "?" + C : d; } function F(r) { var u = w(r || ""), i = j(u); return { url: u, slug: R(u), mangaId: g(S(i.manga_id) || ""), title: g(S(i.title) || ""), cover: S(i.cover) || "", statusText: g(S(i.status) || ""), latestChapterSlug: g(S(i.latest) || ""), chapterSlug: g(S(i.chapter) || M(u)) }; } function Q(r) { var u = r.select(".post-title a, h3 a").first(); if (!u)
                                        return null; var i = r.select(".except-summary").first(), c = r.select(".latest-chap a, .font-meta.chapter a, .chapter-item a, .list-chapter a").first(), l = g(u.text()), d = w(u.attr("href")), b = r.select(".trangthai, .summary-content, .mg_status").first(), C = b ? b.select("a").last() : null, X = g((C ? C.attr("href") + " " : "") + (b ? b.text() : "")), J = []; r.select(".genres-content-search a, .genres-content a").forEach(function (Z) { var K = g(Z.text()), Y = Z.attr("href"); !K || !Y || J.push(ht(K, Y)); }); var O = { title: l, rawLink: d, slug: R(d), mangaId: g(i ? i.attr("data-manga-id") : ""), cover: pt(r.select("img").first()), descriptionHtml: i && i.html() || "", descriptionText: g(i ? i.text() : ""), statusText: X, ongoing: z(X), genres: J, latestChapterSlug: g(c ? M(c.attr("href")) || c.attr("value") : ""), latestChapterName: g(c ? c.text() : ""), latestChapterUrl: c ? w(c.attr("href")) : "", host: x }; return O.link = $(O.rawLink, O.mangaId, O), O; } function st(r) { var u = []; return r.select(".row.c-tabs-item__content").forEach(function (i) { var c = Q(i); c && u.push(c); }), u.length === 0 && r.select(".page-item-detail").forEach(function (i) { var c = Q(i); c && u.push(c); }), u; } function Lt(r) { return { name: r.title, link: r.link, cover: r.cover, author: "N/A", description: r.descriptionText, host: x }; } function qt(r) { var u = r.select("#madara_goto_page").first(); if (!u)
                                        return ""; var i = parseInt(u.attr("placeholder") || "1", 10), c = parseInt(u.attr("max") || "0", 10); return !isNaN(i) && !isNaN(c) && i < c ? String(i + 1) : ""; } function gt(r, u) { var i; for (i = 0; i < r.length; i++)
                                        if (u.mangaId && r[i].mangaId === u.mangaId)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.slug && r[i].slug === u.slug)
                                            return r[i]; for (i = 0; i < r.length; i++)
                                        if (u.title && g(r[i].title).toLowerCase() === g(u.title).toLowerCase())
                                            return r[i]; return r.length ? r[0] : null; } function bt(r, u) { var i = { url: r.url, slug: u && u.slug ? u.slug : r.slug, mangaId: u && u.mangaId ? u.mangaId : r.mangaId, title: u && u.title ? u.title : r.title || I(r.slug), cover: u && u.cover ? u.cover : r.cover, statusText: u && u.statusText ? u.statusText : r.statusText, descriptionHtml: u && u.descriptionHtml ? u.descriptionHtml : "", descriptionText: u && u.descriptionText ? u.descriptionText : "", ongoing: u ? u.ongoing : z(r.statusText), genres: u && u.genres ? u.genres : [], latestChapterSlug: u && u.latestChapterSlug ? u.latestChapterSlug : r.latestChapterSlug, latestChapterName: u && u.latestChapterName ? u.latestChapterName : "", latestChapterUrl: u && u.latestChapterUrl ? u.latestChapterUrl : "", host: x }; return i.link = $(u && u.rawLink ? u.rawLink : r.url, i.mangaId, i), i; } function _t(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    u = F(r), i = u.title || I(u.slug), c = null;
                                                    if (!i) return [3, 2];
                                                    return [4, a(x, { queries: { s: i, post_type: "wp-manga" } })];
                                                case 1:
                                                    l = _b.sent();
                                                    l && l.ok && (c = gt(st(l.html()), u));
                                                    _b.label = 2;
                                                case 2: return [2, bt(u, c)];
                                            }
                                        }); });
                                    } function Mt(r) {
                                        return __awaiter(this, void 0, void 0, function () { var u, i, c, l, d; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    if (!r)
                                                        return [2, ""];
                                                    return [4, a(ut + "?" + q({ action: "get_first_chapter_content", manga_id: r }))];
                                                case 1:
                                                    u = _b.sent();
                                                    if (!u || !u.ok)
                                                        return [2, ""];
                                                    i = u.json(), c = ot(i);
                                                    if (!c)
                                                        return [2, ""];
                                                    l = s.parse(c), d = l.select("#wp-manga-current-chap").first();
                                                    return [2, g(d ? d.attr("value") : "")];
                                            }
                                        }); });
                                    } function ot(r) { return r ? typeof r == "string" ? r : r.data && typeof r.data == "string" ? r.data : r.data && r.data.content ? r.data.content : r.data && r.data.data && r.data.data.content ? r.data.data.content : r.content ? r.content : "" : ""; } function Ft(r) { return (r || "").replace(/<!--[\s\S]*?-->/g, "").replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").trim(); } function W(r, u) {
                                        return __awaiter(this, void 0, void 0, function () { var i, c, l, d; return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    i = rt(x + "/?" + q({ s: r || "", post_type: "wp-manga" }), u || "1");
                                                    return [4, a(i)];
                                                case 1:
                                                    c = _b.sent();
                                                    if (!c || !c.ok)
                                                        return [2, null];
                                                    l = c.html(), d = [];
                                                    return [2, (st(l).forEach(function (b) { d.push(Lt(b)); }), o.success(d, qt(l)))];
                                            }
                                        }); });
                                    } var x, ut; return __generator(this, function (_b) {
                                        x = "https://metruyencv.xyz";
                                        try {
                                            CONFIG_URL && (x = CONFIG_URL.replace(/\/+$/, ""));
                                        }
                                        catch (r) { }
                                        ut = x + "/wp-admin/admin-ajax.php";
                                        return [2, typeof W == "function" ? W : void 0];
                                    }); });
                                })()];
                            case 1: return [2, _b.sent()];
                        }
                    }); });
                })(t.fetch, t.Http, t.Html, t.Response, t.localStorage, t.cacheStorage, t.localConfig, t.localCookie, t.sleep, t.Log, t.console, t.log, t.UserAgent, t.Engine, t.Graphics, t.Script)];
        }); });
    } };
function ia(t) { return new Ze({ meta: kt, scripts: na, host: t }); }
var _n = require("@libs/fetch").fetchApi, we = null;
try {
    we = require("@libs/storage");
}
catch (t) {
    we = null;
}
var Xu = {}, Ke = we && we.storage ? we.storage : { get: function (t) { return Xu[t]; }, set: function (t, e) { Xu[t] = e; }, delete: function (t) { delete Xu[t]; } }, Ju = (function () {
    function class_2() {
        var _this = this;
        this.id = kt.lnId, this.name = kt.name, this.icon = kt.lnIcon, this.site = kt.source, this.version = kt.lnVersion, this.filters = void 0, this.webStorageUtilized = !1, this.engine = ia({ name: "LNReader", request: function (e) { return __awaiter(_this, void 0, void 0, function () {
                var a, n, s;
                var _b;
                return __generator(this, function (_c) {
                    switch (_c.label) {
                        case 0:
                            a = { method: e.method, headers: e.headers };
                            e.body != null && e.method !== "GET" && (a.body = e.body);
                            return [4, _n(e.url, a)];
                        case 1:
                            n = _c.sent(), s = {};
                            try {
                                n.headers.forEach(function (o, f) { s[f] = o; });
                            }
                            catch (o) { }
                            _b = { status: n.status, url: n.url || e.url, headers: s };
                            return [4, n.text()];
                        case 2: return [2, (_b.text = _c.sent(), _b)];
                    }
                });
            }); }, storageGet: function (e) { var a = Ke.get("vb_" + e); return a == null ? null : String(a); }, storageSet: function (e, a) { a == null ? Ke.delete && Ke.delete("vb_" + e) : Ke.set("vb_" + e, String(a)); }, config: function (e) { return null; }, log: function (e) { return console.log(e); } });
    }
    class_2.prototype.popularNovels = function (e, a) {
        return __awaiter(this, void 0, void 0, function () { var _b; return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    if (!(a && a.showLatestNovels)) return [3, 2];
                    return [4, this.engine.latest(e)];
                case 1:
                    _b = _c.sent();
                    return [3, 4];
                case 2: return [4, this.engine.popular(e)];
                case 3:
                    _b = _c.sent();
                    _c.label = 4;
                case 4: return [2, (_b).items.map(function (s) { return ({ name: s.name, path: s.link, cover: s.cover }); })];
            }
        }); });
    };
    class_2.prototype.searchNovels = function (e, a) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, this.engine.search(e, a)];
                case 1: return [2, (_b.sent()).items.map(function (s) { return ({ name: s.name, path: s.link, cover: s.cover }); })];
            }
        }); });
    };
    class_2.prototype.parseNovel = function (e) {
        return __awaiter(this, void 0, void 0, function () { var a, n; return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, this.engine.detail(e)];
                case 1:
                    a = _b.sent();
                    return [4, this.engine.chapters(e)];
                case 2:
                    n = _b.sent();
                    return [2, { path: e, name: a.name || "Untitled", cover: a.cover, summary: a.description, author: a.author, status: a.ongoing ? "Ongoing" : "Completed", genres: a.genres.join(","), chapters: n.map(function (s, o) { return ({ name: s.name, path: s.url, chapterNumber: o + 1 }); }) }];
            }
        }); });
    };
    class_2.prototype.parseChapter = function (e) {
        return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, this.engine.content(e)];
                case 1: return [2, (_b.sent()).html];
            }
        }); });
    };
    class_2.prototype.resolveUrl = function (e, a) { return /^https?:/i.test(e) ? e : kt.source.replace(/\/+$/, "") + "/" + String(e).replace(/^\/+/, ""); };
    return class_2;
}()), Mn = new Ju;
